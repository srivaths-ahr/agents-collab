# RemotePorts test kit (Windows)

Measures whether the browser can see remote-access tools (AnyDesk, TeamViewer,
VNC, Splashtop) listening on this machine, and how long the scan takes.
Nothing is installed and nothing leaves the machine. Results go to ONE local
file which you send back.

## You need
- Node.js 20 or newer (https://nodejs.org). Check with: `node --version`
- Chrome, Edge and/or Firefox.

## Steps
1. Unzip this folder anywhere, open a terminal (cmd or PowerShell) in it.
2. Run:  `node serve.mjs`
   It prints a URL like `http://127.0.0.1:8787/harness.html?runs=8&label=SCENARIO`
   and the path of the results file. Leave it running.
3. For EACH scenario below, in EACH browser, open the URL with `SCENARIO`
   replaced by the scenario name. Wait until the tab title says **DONE** and
   a table appears (about 10 seconds). Then move on.
4. When finished press Ctrl+C in the terminal and send back the file
   **harness-report.jsonl** from this folder. No screenshots are needed.

Scenarios (use these exact labels):
- `clean`            nothing remote-access related running
- `anydesk-idle`     AnyDesk open, no session connected
- `anydesk-session`  AnyDesk with a live session connected from another machine
- `teamviewer-idle`  TeamViewer open, no session
- `teamviewer-session`  TeamViewer with a live session
- `rdp-enabled`      Remote Desktop switched on in Windows settings (optional)

Example URL: `http://127.0.0.1:8787/harness.html?runs=8&label=anydesk-session`

If a browser shows a permission prompt about "local network" access, choose
Allow once and note it in your message; that prompt itself is a result.

## Optional, no browser
`node --test live.test.mjs` runs the same scan from Node and prints a table.
Paste the output if you run it.
