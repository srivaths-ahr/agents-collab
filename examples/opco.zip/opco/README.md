# Risk-adaptive device collection — POC

New session or agent? Read `context.md`, then `task.md` and `clarifications.md`; the runbook is in `PLAN.md`.

Offline replay that shows what a risk-adaptive collection policy would do to the
15,000 desktop payloads: latency, recognition, signal retention, risk coverage,
guardrails and fallback. Deck: `demo-presentation.html`. Collector config: `features.js`.

No production change, no live learning, no fraud labels (risk = governed rule-based score).

## Layout

| Path | What |
|---|---|
| `py/adaptive/` | Python, standard library only (no installs). Ingest, value stats, policy build, network model, replay, gates, report |
| `py/adaptive/config/adapter.json` | **Where fields live in a raw payload.** The only file that should need editing for real data |
| `py/adaptive/config/policy_build.json` | Required checks, tier thresholds, sensitive events, 5% baseline |
| `py/adaptive/config/gates.json` | Pass/fail thresholds (placeholders) |
| `py/adaptive/rules/risk_rules.json` | Rule-based risk score; shared by Python replay and the JS evaluator |
| `policy-js/` | Vanilla JS (ES modules + JSDoc, no deps): `decide`, `loadPolicy`, `createEscalation`, `validate`, and `createRun` / `featuresForDecision` to drive the collector through its `features.js` config |
| `py/adaptive/verify.py` | Server-side check that a payload matches the decision it claims |
| `py/adaptive/scenarios.py` | What-if runs on the same data |
| `PLAN.md` | Phase plan, status, demo plan, open decisions |
| `out/` | `demo.html` (presentation), `report.html` (evidence), `policy-<version>.json`, `metrics.json`, `gates.json`, `scenarios.json`, `records.jsonl` |

## Run

```sh
cd py
python3 -m adaptive fixtures --n 3000              # synthetic payloads -> ../data/fixtures
python3 -m adaptive run-all --data ../data/fixtures --out ../out
python3 -m adaptive run-all --data ../data/raw --out ../out   # real payloads (*.json or *.jsonl)
python3 -m unittest discover -s tests -t .

cd ../policy-js && npm test    # parity with Python (golden cases written by run-all), overlay, validation, timing
npm run bench:chrome            # decide / escalation / overlay timing inside headless Chrome
```

Presentation page: `run-all` writes `out/demo.html` for that run. To show several runs in one page
(switcher bottom-left): `python3 -m adaptive demo --run ../out:Synthetic --run ../out-real:Real --out ../out/demo.html`.
Opens straight from disk; `#s-race` jumps to a slide, `?still=1` disables animation, `?live=run&sim=webdriver`
runs the live slide on load.

`run-all` also runs the what-if scenarios (tuning sweep, rolling release, kill switch, rule added after
release, server-side verification, visit timelines) into `out/scenarios.json` and the report; skip them
with `--no-scenarios`.

`run-all` refreshes `policy-js/test/fixtures/` (policy + golden cases); pass `--no-golden` to keep them.

## Assumed raw payload shape (until a sample arrives)

```json
{"payloadId": "...", "receivedAt": 1756684800000,
 "data": {"navigator": {"browserName": "Chrome", ...}, "wdi": {"ec": {"wdi1": "..."}}, ...},
 "collectTime": {"navigator.browserName": {"offset": 1.2, "duration": 0.3}, ...}}
```
Error values such as `"NOT_AVAILABLE"` / `"TIMEOUT"` map to statuses via `statusValues` in `adapter.json`.
Nested timing (same tree as `data`) is supported with `"timingLayout": "nested"`.
