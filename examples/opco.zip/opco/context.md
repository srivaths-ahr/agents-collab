# context.md

Architecture map for the opco POC. Read this first, then `task.md`, then `clarifications.md`.
`PLAN.md` has phase status and the runbook; `README.md` has the commands.

## What this project is

An **offline replay POC** for risk-adaptive device signal collection (deck: `demo-presentation.html`).
Today the desktop collector runs every check on every visit (~300 checks, 0.8–1.5 s). The POC builds a
governed policy that sends low-risk visits down a fast path (required + high-value checks, tuned waits)
and keeps the full scan whenever risk rises or a guardrail applies. It replays ~15,000 real desktop
payloads through that policy and reports latency, risk coverage, recognition, signal retention,
guardrails and fallback, as a reviewer report and a presentation page.

Boundary: no production change, no live learning, no backend fraud-decision change. **No fraud
labels exist**; "risk" is a rule-based score on the full scan. All real payloads come from one client;
ClientA / ClientB are a **synthetic split** for the network-model demo.

## Layout

```
opco/
  demo-presentation.html   # the deck; ALSO the source of CSS tokens for demo.html (read at build time)
  features.js              # collector config (CommonJS); the attribute catalogue is read from it live
  PLAN.md  README.md  context.md  task.md  clarifications.md
  data/raw/                # real payloads (*.json, one list-layout payload per file) — 6 samples now; gitignored
  data/fixtures/           # synthetic payloads from fixtures.py — gitignored
  out/                     # outputs of a run-all (synthetic run by default) — gitignored
  schemas/policy.schema.json
  py/                      # run everything from here: python3 -m adaptive ...
    adaptive/
      __main__.py          # CLI: fixtures | run-all | demo
      catalog.py           # features.js -> flat attribute list (runs node)
      model.py             # Visit: per-attribute arrays (status, offset, duration, value hash, size)
      ingest.py            # raw payload -> Visit via config/adapter.json; schema + runtime checks
      fixtures.py          # synthetic payload generator (marks payloads "synthetic": true)
      timing.py            # critical-path re-timing (simulate, contributions)
      value.py             # per-browser signal value of each check (training split only)
      risk.py              # rule engine over rules/risk_rules.json
      policy.py            # build (Python only) + validate/decide/Escalator (mirrored in JS)
      network.py           # synthetic client split, hardware-fingerprint clusters, time-ordered flags
      replay.py            # applies a policy to held-out visits -> per-visit records
      gates.py             # metrics summary + pass/fail gates (config/gates.json)
      verify.py            # server-side check that a payload matches its claimed decision
      scenarios.py         # what-ifs: sweep, rolling release, kill switch, new rule, verification, timelines
      pipeline.py          # run-all orchestration; writes out/*, refreshes policy-js golden fixtures
      report.py, report_extras.py   # out/report.html (evidence)
      demo.py, demo_template.html   # out/demo.html (presentation, deck styling, live slide)
      hashing.py           # FNV-1a + canonical JSON (byte-identical with policy-js/src/hash.js)
      config/adapter.json        # WHERE FIELDS LIVE IN A RAW PAYLOAD — the file to fit to real data
      config/policy_build.json   # required patterns, tier thresholds, sensitive events, baseline rate
      config/gates.json          # gate thresholds (placeholders)
      rules/risk_rules.json      # risk rules; "confirm": true = value shape not yet checked on real data
    tests/test_core.py     # stdlib unittest
  policy-js/               # vanilla JS, ES modules + JSDoc, no deps, no build step
    src/  hash.js rules.js validate.js evaluate.js escalate.js fallback.js overlay.js index.js
    test/*.test.mjs        # node:test; fixtures/ (policy.json, golden.json, catalog.json) written by run-all
    bench/                 # headless-Chrome timing (npm run bench:chrome)
```

Related, read-only: `/Users/srivaths/Projects/Tvishi/udi/udi-collector-js` (partial collector source:
EverCookie/WDI, RemotePorts, ClientHints; the orchestrator that runs checks is NOT in that checkout).

## Key components

- **Adapter (`ingest.py` + `config/adapter.json`)** — the only place that knows the raw payload layout.
  Two layouts, picked per file:
  - Compressed files (`.txt` / `.b64`, see `adapter.json` → `compressed`) are Base64 of Pako output
    (zlib / gzip / raw deflate) and are decoded first (`ingest.decode_compressed`; CLI
    `python3 -m adaptive decompress <files>` writes readable JSON to `data/decoded/`).
  - `list` (**real data**, collector 9.4.0 and 10.0.0): one file = one payload = a JSON list of
    `{name, data | error: {message: "600"…}, time}`; bare names map to `features.js` paths by leaf name
    (leaf names are unique); metadata comes from entries `wdi1`, `eventName`, `browserName`,
    `browserVersion`, `browserLocalTimeUTC` (timestamp), `collectionRunTime` (total, string); payload id
    = file name. 9.4.0 has **no offsets** (`time` only → elapsed mode); 10.0.0 adds `start`/`end`
    (→ exact offsets mode). Keep versions in separate folders.
  - `tree` (synthetic `fixtures.py`): nested values + flat `collectTime` `{offset, duration}` map.
- **Timing model (`timing.py`)** — two modes, chosen by `Visit.elapsed`:
  - *offsets* (exact): a check is *serial* if nothing else starts while it runs; skipping or shortening
    it moves strictly-later starts earlier; a concurrent check only drops its own end.
  - *elapsed* (real 9.4.0 data, **estimate**): visit time = prelude + slowest kept check, prelude =
    `collectionRunTime` − slowest check (held fixed). Understates savings: cheap checks keep times
    inflated by blocking from skipped work (see `clarifications.md` Q3, Q22).
  Either way, keeping every check reproduces the recorded time exactly (gate `identity`).
- **Policy (`policy.py` ↔ `policy-js`)** — buckets keyed `family:major` (e.g. `chrome:131`); each holds
  ordered `checks` `{attr, tier: required|high, waitMs}`. Guardrail order: invalid policy → full;
  sensitive event → deep; server-flagged → deep; unknown bucket → deep; 5% baseline (FNV of payload id)
  → deep; else fast. Escalation re-scores as each risk-rule input arrives. Required checks (all
  risk-rule inputs, `wdi.ec.*`, `product.*`, network-fingerprint attrs) keep their configured timeout.
- **Collector link (`policy-js/src/overlay.js`)** — turns a decision into a `features.js` override
  (checks off, waits shortened) and hands back the remaining config after an escalation.
- **Outputs** — `out/metrics.json`, `gates.json`, `scenarios.json`, `records.jsonl`, `policy-*.json`,
  `tiers.json`, `stats.json`, `report.html`, `demo.html`.

## Conventions

- **Python is standard library only** (no pandas/uv on the machine). JSON, not parquet/YAML.
- **JS is vanilla** (ES modules + JSDoc), never TypeScript; tests with `node:test`.
- **Anything mirrored must change on both sides**: `policy.validate/decide/Escalator` ↔
  `policy-js/src/{validate,evaluate,escalate}.js`; `risk.rule_fires` ↔ `rules.js`; `hashing.py` ↔
  `hash.js`; `catalog.build_catalog` leaf rules ↔ `overlay.forEachCheck`. Parity tests catch drift.
- Policy JSON must stay hash-stable across languages: integers for `waitMs`, no non-finite numbers.
- Report text says what the numbers are: replayed timings, no labels, synthetic clients.
- Config over code: real-data fitting goes in `config/*.json` and `rules/*.json` first.

## How to run tests

```
cd py && python3 -m unittest discover -s tests -t .        # Python (27 tests; one parses demo_template.html with node)
cd py && python3 -m adaptive run-all --data ../data/fixtures --out ../out   # end-to-end, refreshes JS golden files
cd policy-js && npm test                                    # JS (28 tests, parity with Python)
cd policy-js && npm run bench:chrome                        # timing in headless Chrome
```
Run `run-all` before `npm test` whenever Python policy logic or data changes (golden files come from it).

## Gotchas

- `decide(policy, ctx, validated)`: Python uses a sentinel — passing `None` means "already validated"
  (skip re-hashing). Omitting it re-validates every call (slow on 15k visits).
- `run-all` overwrites `policy-js/test/fixtures/`. Use `--no-golden` for one-off experiments.
- Fixtures include browser drift (Chrome 131 → 132 from day 30), so ~20% of synthetic held-out visits
  are "unknown browser" by design.
- Real demo data has no offsets → `schema.timing_mode == "elapsed"`, the `runtime_match` gate is `n/a`,
  and report/demo show an "Estimated timing" banner. With offsets (9.5.0+), `runtime_match_rate` < 0.95
  means offsets are not relative to one start; fix the adapter before anything else.
- Several risk-rule inputs (headless, automation artifacts, malware.*, extensions) are absent from 9.4.0
  data; those rules never fire there (Q20). `remotePorts` is a JSON string list (`"[]"` = clean).
- A handful of payloads can't build per-browser buckets (min 50 visits): use `--set minBucketSupport=1`
  for smoke tests only.
- `ingest.iter_raw` yields `(payload, source_id)` pairs.
- Never write run outputs inside a data folder: ingest reads every `.json` under `--data`.
- 10.0.0 data collects checks the opco `features.js` (9.5.0) disables (`extendedFonts`, `webGpuInfo`)
  and one it doesn't know (`wdi3`) — see Q23; get the matching `features.js` before quoting latency.
- A full `run-all` with scenarios takes ~30 s on 3k payloads; expect a few minutes on 15k
  (`--no-scenarios` for quick iterations).
- Real payloads may contain personal data (IP, location, identifiers). Never copy raw values into the
  repo, tests or published pages; anonymise any value used in a test.
- `data/`, `out*/`, `.bench-profile/` are gitignored; the project folder is not a git repo yet.
