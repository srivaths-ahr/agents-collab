"""What-if runs on the same data: tuning sweep, rolling release, kill switch,
a rule added after release, server-side verification, and per-visit timelines."""

import copy
from collections import Counter, defaultdict
from dataclasses import dataclass

from .gates import evaluate, pct, summarise
from .model import MISSING
from .policy import build
from .replay import recognition_slots, replay
from .timing import simulate
from .value import bucket_stats
from .verify import CRITICAL, client_view, verify

DAY_MS = 24 * 3600 * 1000
ROLLING_GATES = {"fast_p50", "lowrisk_reduction", "sensitive_deep", "flagged_deep", "risk_coverage",
                 "signal_retention", "recognition"}


@dataclass
class Context:
    ds: object
    rules: dict
    cfg: dict
    catalog: list
    flagged: dict


def build_and_replay(ctx, train, test, cfg=None, rules=None, stats=None):
    cfg = cfg or ctx.cfg
    rules = rules or ctx.rules
    stats = stats or bucket_stats(train, ctx.ds.index)
    policy, tiers = build(stats, ctx.catalog, rules, cfg, [v.payload_id for v in train])
    records = replay(test, ctx.ds.index, policy, rules, stats, ctx.flagged, recognition_slots(stats["*"], ctx.ds.index))
    metrics = summarise(records, rules["threshold"], cfg["sensitiveEvents"], {})
    return {"policy": policy, "tiers": tiers, "stats": stats, "records": records, "metrics": metrics}


def _row(m, records):
    fast = [r for r in records if r["path"] == "fast"]
    return {"fast_share": len(fast) / len(records) if records else 0.0,
            "fast_p50_ms": m["fast_p50_ms"], "adaptive_p50_ms": m["adaptive_p50_ms"],
            "lowrisk_p50_reduction": m["lowrisk_p50_reduction"], "signal_retention": m["signal_retention"],
            "attr_retention": m["attr_retention"], "risk_coverage": m["risk_coverage"],
            "recognition_fast": m["recognition_fast"]["match_rate"],
            "bytes_ratio": m["bytes_fast_mean"] / m["bytes_fast_full_mean"] if m["bytes_fast_full_mean"] else 1.0}


def sweep(ctx, train, test, stats, high_values=(0.05, 0.15, 0.3, 0.5, 0.8), cost_caps=(10, 40, 150)):
    """Latency vs retention trade-off across the two main tier settings."""
    rows = []
    for hv in high_values:
        for cap in cost_caps:
            cfg = {**ctx.cfg, "highValueMin": hv, "costCapMs": cap}
            res = build_and_replay(ctx, train, test, cfg=cfg, stats=stats)
            rows.append({"highValueMin": hv, "costCapMs": cap,
                         "current": hv == ctx.cfg["highValueMin"] and cap == ctx.cfg["costCapMs"],
                         **_row(res["metrics"], res["records"])})
    return rows


def windows(visits, days=10):
    if not visits:
        return []
    t0 = visits[0].ts
    out = defaultdict(list)
    for v in visits:
        out[(v.ts - t0) // (days * DAY_MS)].append(v)
    return [out[k] for k in sorted(out)]


def rolling_release(ctx, visits, days=10, train_windows=2):
    """Each window: build a candidate from the previous windows, shadow it, promote it only if its gates pass."""
    wins = windows(visits, days)
    rows, live = [], None
    for k in range(train_windows, len(wins)):
        train = [v for w in wins[k - train_windows:k] for v in w]
        shadow = wins[k]
        cand = build_and_replay(ctx, train, shadow)
        cand_gates = [g for g in evaluate(cand["metrics"]) if g["id"] in ROLLING_GATES]
        passed = all(g["passed"] for g in cand_gates)
        live_row = None
        if live is not None:
            live_records = replay(shadow, ctx.ds.index, live["policy"], ctx.rules, live["stats"], ctx.flagged,
                                  recognition_slots(live["stats"]["*"], ctx.ds.index))
            live_m = summarise(live_records, ctx.rules["threshold"], ctx.cfg["sensitiveEvents"], {})
            live_row = {**_row(live_m, live_records),
                        "unknown_share": sum(r["reason"] == "unknown_browser" for r in live_records) / len(shadow)}
        rows.append({
            "window": k + 1, "start_day": k * days, "visits": len(shadow),
            "buckets": sorted(cand["policy"]["buckets"]),
            "candidate": {**_row(cand["metrics"], cand["records"]),
                          "unknown_share": sum(r["reason"] == "unknown_browser" for r in cand["records"]) / len(shadow)},
            "live": live_row,
            "failed_gates": [g["label"] for g in cand_gates if not g["passed"]],
            "action": "promote" if passed else "hold",
        })
        if passed:
            live = cand
    return rows


def kill_switch(ctx, test, policy, stats):
    """Halfway through the held-out period the distributed policy is corrupted; clients fall back to full scan."""
    if not test:
        return {}
    mid = test[len(test) // 2].ts
    before = [v for v in test if v.ts < mid]
    after = [v for v in test if v.ts >= mid]
    bad = copy.deepcopy(policy)
    bad["version"] = policy["version"] + "-corrupt"  # hash no longer matches
    rec_slots = recognition_slots(stats["*"], ctx.ds.index)
    recs = replay(before, ctx.ds.index, policy, ctx.rules, stats, ctx.flagged, rec_slots) \
        + replay(after, ctx.ds.index, bad, ctx.rules, stats, ctx.flagged, rec_slots)
    daily = defaultdict(list)
    t0 = test[0].ts
    for r in recs:
        daily[(r["ts"] - t0) // DAY_MS].append(r)
    series = [{"day": d, "full_p50_ms": pct([r["latency_full"] for r in rs], 0.5),
               "adaptive_p50_ms": pct([r["latency"] for r in rs], 0.5),
               "fallback_share": sum(r["path"] == "full" for r in rs) / len(rs)} for d, rs in sorted(daily.items())]
    after_recs = [r for r in recs if r["ts"] >= mid]
    return {"switch_day": (mid - t0) // DAY_MS, "series": series,
            "after_fallback_share": sum(r["path"] == "full" for r in after_recs) / len(after_recs),
            "after_reasons": dict(Counter(r["reason"] for r in after_recs))}


NEW_RULE = {"id": "extensions.suspect", "tag": "environment", "weight": 40,
            "when": {"op": "equals", "attr": "browser.suspectExtensions", "value": ["ext-a", "ext-b"]}}


def new_rule(ctx, train, test, policy, stats, rule=NEW_RULE):
    """A rule is added on a check the fast path skips. Before rebuilding the policy those visits are
    missed; after rebuilding, the check becomes required and coverage returns, at a latency cost."""
    rules2 = {**ctx.rules, "version": ctx.rules["version"] + "+new", "rules": ctx.rules["rules"] + [rule]}
    attr = rule["when"]["attr"]
    rec_slots = recognition_slots(stats["*"], ctx.ds.index)
    # needs the new rule's input kept at ingest (pipeline passes it as extra_values)
    stale = replay(test, ctx.ds.index, policy, rules2, stats, ctx.flagged, rec_slots)
    stale_m = summarise(stale, rules2["threshold"], ctx.cfg["sensitiveEvents"], {})
    rebuilt = build_and_replay(ctx, train, test, rules=rules2, stats=stats)
    tier_before = Counter(t.get(attr, "—") for t in build(stats, ctx.catalog, ctx.rules, ctx.cfg, [])[1].values())
    return {"rule": rule, "attr": attr, "tier_before": dict(tier_before),
            "stale": {**_row(stale_m, stale), "misses": len(stale_m["risk_misses"]), "risky": stale_m["risky_visits"]},
            "rebuilt": {**_row(rebuilt["metrics"], rebuilt["records"]),
                        "misses": len(rebuilt["metrics"]["risk_misses"]), "risky": rebuilt["metrics"]["risky_visits"]}}


def verification(ctx, test, policy, records, n_tamper=60):
    """Run the server-side check on honest payloads and on four kinds of tampering."""
    index = ctx.ds.index
    registry = {policy["hash"]: policy}
    enabled = {index.slot[a.path] for a in ctx.catalog if a.collect and a.path in index.slot}
    plans = {name: ({index.slot[c["attr"]] for c in b["checks"] if c["attr"] in index.slot},
                    {index.slot[c["attr"]]: c["waitMs"] for c in b["checks"] if c["attr"] in index.slot})
             for name, b in policy["buckets"].items()}
    by_id = {v.payload_id: v for v in test}

    def server_ctx(v):
        return {"payloadId": v.payload_id, "eventName": v.event_name, "browserFamily": v.browser_family,
                "browserMajor": v.browser_major, "serverFlagged": ctx.flagged.get(v.payload_id) is not None}

    def fast_view(v):
        keep, waits = plans[v.bucket]
        _, _, lost = simulate(v, keep, waits)
        return client_view(v, keep, lost)

    honest = Counter()
    honest_critical = 0
    for r in records:
        v = by_id[r["payload_id"]]
        view = fast_view(v) if r["path"] == "fast" else v
        stamp = {"policyHash": policy["hash"] if r["path"] != "full" else None, "mode": r["path"] if r["path"] != "escalated" else "fast",
                 "reason": r["reason"], "escalated": r["path"] == "escalated"}
        f = verify(view, stamp, registry, index, server_ctx(v), enabled)
        honest.update(x.code for x in f)
        honest_critical += any(x.severity == CRITICAL for x in f)

    def attempt(name, visits, make):
        detected, codes = 0, Counter()
        for v in visits[:n_tamper]:
            view, stamp = make(v)
            f = verify(view, stamp, registry, index, server_ctx(v), enabled)
            codes.update(x.code for x in f if x.severity == CRITICAL)
            detected += any(x.severity == CRITICAL for x in f)
        n = min(n_tamper, len(visits))
        return {"name": name, "attempts": n, "detected": detected, "codes": dict(codes)}

    fast_ok = [by_id[r["payload_id"]] for r in records if r["path"] == "fast"]
    guarded = [by_id[r["payload_id"]] for r in records
               if r["reason"] in ("sensitive_journey", "server_flagged") and by_id[r["payload_id"]].bucket in plans]
    risky = [by_id[r["payload_id"]] for r in records
             if r["full_score"] >= ctx.rules["threshold"] and by_id[r["payload_id"]].bucket in plans]
    req_slot = index.slot[policy["required"][0]]

    def strip_required(v):
        view = fast_view(v)
        view.status[req_slot] = MISSING
        return view, {"policyHash": policy["hash"], "mode": "fast", "reason": "low_risk", "escalated": False}

    tamper = [
        attempt("Ran the fast path on a guarded visit", guarded,
                lambda v: (fast_view(v), {"policyHash": policy["hash"], "mode": "fast", "reason": "low_risk"})),
        attempt("Dropped a required check", fast_ok, strip_required),
        attempt("Suppressed an escalation", risky,
                lambda v: (fast_view(v), {"policyHash": policy["hash"], "mode": "fast", "reason": "low_risk"})),
        attempt("Used a policy the server never issued", fast_ok,
                lambda v: (fast_view(v), {"policyHash": "fnv1a32:deadbeef", "mode": "fast", "reason": "low_risk"})),
    ]
    return {"honest_visits": len(records), "honest_critical": honest_critical, "honest_findings": dict(honest),
            "tamper": tamper}


def timelines(ctx, test, policy, records):
    """Per-check timeline for one typical fast-path visit and one escalated visit."""
    index = ctx.ds.index
    by_id = {v.payload_id: v for v in test}
    fast = sorted((r for r in records if r["path"] == "fast"), key=lambda r: r["latency_full"] - r["latency"])
    picks = []
    if fast:
        picks.append(("Typical fast-path visit", fast[len(fast) // 2]))
    esc = [r for r in records if r["path"] == "escalated"]
    if esc:
        picks.append(("Escalated visit", esc[0]))
    out = []
    for title, r in picks:
        v = by_id[r["payload_id"]]
        b = policy["buckets"][v.bucket]
        keep = {index.slot[c["attr"]] for c in b["checks"] if c["attr"] in index.slot}
        waits = {index.slot[c["attr"]]: c["waitMs"] for c in b["checks"] if c["attr"] in index.slot}
        _, ends, lost = simulate(v, keep, waits)
        rows = []
        for s in range(len(v.status)):
            if v.status[s] == MISSING:
                continue
            d = float(v.duration[s])
            if d < 3:
                continue
            row = {"attr": index.paths[s], "start": float(v.offset[s]), "dur": d}
            if s in ends:
                d2 = min(d, waits.get(s, d))
                row.update(fast_start=ends[s] - d2, fast_dur=d2, cut=s in lost)
            rows.append(row)
        rows.sort(key=lambda x: (x["start"], -x["dur"]))
        out.append({"title": title, "payload_id": r["payload_id"], "bucket": r["bucket"], "path": r["path"],
                    "latency_full": r["latency_full"], "latency": r["latency"], "escalation": r["escalation"],
                    "hidden_small": sum(1 for s in range(len(v.status))
                                        if v.status[s] != MISSING and v.duration[s] < 3),
                    "rows": rows})
    return out
