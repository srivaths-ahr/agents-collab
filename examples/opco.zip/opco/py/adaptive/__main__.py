"""CLI.

python3 -m adaptive fixtures --n 2000 --out ../data/fixtures
python3 -m adaptive run-all --data ../data/raw --out ../out
"""

import argparse
import sys


def main(argv=None):
    ap = argparse.ArgumentParser(prog="adaptive")
    sub = ap.add_subparsers(dest="cmd", required=True)
    f = sub.add_parser("fixtures", help="generate synthetic payloads")
    f.add_argument("--n", type=int, default=2000)
    f.add_argument("--seed", type=int, default=7)
    f.add_argument("--out", default="../data/fixtures")
    r = sub.add_parser("run-all", help="ingest, build policy, replay, report")
    r.add_argument("--data", default="../data/raw")
    r.add_argument("--out", default="../out")
    r.add_argument("--no-golden", action="store_true", help="do not refresh policy-js test fixtures")
    r.add_argument("--no-scenarios", action="store_true", help="skip what-if runs (sweep, rolling release, ...)")
    r.add_argument("--set", action="append", default=[], metavar="KEY=VALUE",
                   help="override config/policy_build.json for this run, e.g. --set minBucketSupport=2")
    x = sub.add_parser("decompress", help="decode Base64 + Pako/zlib payload files into JSON for inspection")
    x.add_argument("files", nargs="+")
    x.add_argument("--out", default="../data/decoded")
    d = sub.add_parser("demo", help="build the presentation page from one or more run folders")
    d.add_argument("--run", action="append", required=True, metavar="FOLDER[:LABEL]",
                   help="a run-all output folder, optionally with a label, e.g. ../out-real:Real")
    d.add_argument("--out", default="../out/demo.html")
    args = ap.parse_args(argv)

    if args.cmd == "decompress":
        import json
        from pathlib import Path
        from .ingest import decode_compressed
        out = Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        for f in args.files:
            target = out / (Path(f).stem + ".json")
            target.write_text(json.dumps(decode_compressed(Path(f).read_text()), indent=1))
            print(f"{f} -> {target}")
        return 0

    if args.cmd == "demo":
        from .demo import build
        runs = [(r.rsplit(":", 1)[0], r.rsplit(":", 1)[1]) if ":" in r else (r, r.rstrip("/").split("/")[-1])
                for r in args.run]
        print(f"wrote {build(runs, args.out)}")
        return 0

    if args.cmd == "fixtures":
        from .fixtures import generate
        generate(args.n, args.seed, args.out)
        print(f"wrote {args.n} synthetic payloads to {args.out}/fixtures.jsonl")
        return 0

    from .pipeline import run
    import json
    overrides = {}
    for kv in args.set:
        k, v = kv.split("=", 1)
        try:
            overrides[k] = json.loads(v)
        except ValueError:
            overrides[k] = v
    metrics, gates = run(args.data, args.out, write_golden=not args.no_golden, with_scenarios=not args.no_scenarios,
                         cfg_overrides=overrides)
    print(f"visits: train {metrics['train_visits']}, test {metrics['test_visits']}; paths {metrics['paths']}")
    print(f"full p50 {metrics['full_p50_ms']:.0f} ms -> adaptive p50 {metrics['adaptive_p50_ms']:.0f} ms; "
          f"fast p50 {metrics['fast_p50_ms']:.0f} ms")
    for g in gates:
        tag = "n/a " if g["passed"] is None else "PASS" if g["passed"] else "FAIL"
        print(f"  [{tag}] {g['label']}: {g['actual']!r} {g['op']} {g['value']}")
    print(f"report: {args.out}/report.html")
    return 0


if __name__ == "__main__":
    sys.exit(main())
