"""Attribute catalogue read from the collector's features.js.

The config is executed with Node so the catalogue always matches the real
file; nothing is copied by hand.
"""

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path

DEFAULT_FEATURES = Path(__file__).resolve().parents[2] / "features.js"

# Top-level keys that are settings, not collector categories.
NON_CATEGORY_KEYS = {"version", "formSelector", "payloadCallback", "logger", "timeout", "observability"}
# Desktop scope: the mobile branch only holds overrides for mobile SDKs.
EXCLUDED_CATEGORIES = {"mobile"}
TIMEOUT_KEYS = ("timeout", "permissionTimeout", "spTimeout", "storageTimeout")


@dataclass(frozen=True)
class Attribute:
    path: str  # dotted path, e.g. "browser.canvasFingerprint"
    category: str
    collect: bool  # effective flag: false if any ancestor is disabled
    timeout_ms: int  # configured wait, or the global timeout


def load_features(path=DEFAULT_FEATURES):
    script = "console.log(JSON.stringify(require(process.argv[1])))"
    out = subprocess.run(["node", "-e", script, str(Path(path).resolve())],
                         check=True, capture_output=True, text=True).stdout
    return json.loads(out)


def _is_config_key(key):
    return key.endswith("Config") or key.endswith("Details")


def _has_collector_children(node):
    return any(isinstance(v, dict) and "collect" in v and not _is_config_key(k) for k, v in node.items())


def _own_timeout(node):
    for key in TIMEOUT_KEYS:
        if isinstance(node.get(key), (int, float)):
            return int(node[key])
    for key, value in node.items():
        if _is_config_key(key) and isinstance(value, dict):
            nested = _own_timeout(value)
            if nested is not None:
                return nested
    return None


def build_catalog(features=None):
    """Flatten features.js into leaf attributes (desktop scope)."""
    features = features if features is not None else load_features()
    global_timeout = int(features.get("timeout", 2000))
    attrs = []

    def walk(node, path, category, enabled, inherited_timeout):
        enabled = enabled and bool(node.get("collect", True))
        timeout = _own_timeout(node) or inherited_timeout
        if not _has_collector_children(node):
            attrs.append(Attribute(".".join(path), category, enabled, timeout))
            return
        for key, child in node.items():
            if isinstance(child, dict) and "collect" in child and not _is_config_key(key):
                walk(child, path + [key], category, enabled, timeout)

    for category, node in features.items():
        if category in NON_CATEGORY_KEYS or category in EXCLUDED_CATEGORIES or not isinstance(node, dict):
            continue
        walk(node, [category], category, True, global_timeout)
    return attrs


def collected(catalog):
    return [a for a in catalog if a.collect]
