"""Self-contained HTML report (inline SVG + a small tooltip script, no external assets)."""

import html
import json
from collections import Counter

PATH_LABELS = {"fast": "Fast path", "escalated": "Escalated mid-visit", "deep": "Guardrail: full scan",
               "full": "Fallback: full scan"}
PATH_ORDER = ["fast", "escalated", "deep", "full"]
PATH_COLOR = {"fast": "var(--series-1)", "escalated": "var(--series-2)", "deep": "var(--series-3)",
              "full": "var(--series-4)"}
REASON_LABELS = {"low_risk": "Low risk (fast path)", "sensitive_journey": "Sensitive journey",
                 "server_flagged": "Server-flagged device", "unknown_browser": "Unknown browser version",
                 "baseline_sample": "5% baseline sample", "risk_threshold": "Escalated: risk threshold",
                 "conflict": "Escalated: conflicting signals"}

CSS = """
:root{color-scheme:light;--page:#f9f9f7;--surface:#fcfcfb;--ink:#0b0b0b;--ink-2:#52514e;--muted:#898781;
--grid:#e1e0d9;--axis:#c3c2b7;--border:rgba(11,11,11,.10);--series-1:#2a78d6;--series-2:#eb6834;--series-3:#1baf7a;
--series-4:#eda100;--good:#0ca30c;--good-text:#006300;--critical:#d03b3b;--warning:#fab219;--banner:#fff6df}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;
--ink:#f0efec;--ink-2:#c3c2b7;--grid:#2c2c2a;--axis:#383835;--border:rgba(255,255,255,.10);--series-1:#3987e5;
--series-2:#d95926;--series-3:#199e70;--series-4:#c98500;--good-text:#0ca30c;--banner:#2e2610}}
:root[data-theme="dark"]{color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;--ink:#f0efec;--ink-2:#c3c2b7;
--grid:#2c2c2a;--axis:#383835;--border:rgba(255,255,255,.10);--series-1:#3987e5;--series-2:#d95926;--series-3:#199e70;
--series-4:#c98500;--good-text:#0ca30c;--banner:#2e2610}
*{box-sizing:border-box}body{margin:0;background:var(--page);color:var(--ink);
font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:1080px;margin:0 auto;padding:32px 16px 64px}
h1{font-size:28px;line-height:1.2;margin:0 0 6px}h2{font-size:20px;margin:40px 0 4px}h3{font-size:15px;margin:20px 0 8px}
.sub{color:var(--ink-2);margin:0 0 4px}.muted{color:var(--muted)}
.banner{background:var(--banner);border:1px solid var(--border);border-radius:8px;padding:10px 14px;margin:16px 0}
.card{background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:16px 18px;margin:12px 0}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin:16px 0}
.tile{background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:14px 16px}
.tile .v{font-size:28px;font-weight:600;line-height:1.2}.tile .l{color:var(--ink-2);font-size:13px}
.tile .d{font-size:13px;color:var(--muted)}
table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;padding:6px 8px;border-bottom:1px solid var(--grid)}
th{color:var(--ink-2);font-weight:600}td.n,th.n{text-align:right;font-variant-numeric:tabular-nums}
.scroll{overflow-x:auto}
.pass,.fail{font-weight:600;white-space:nowrap}.pass{color:var(--good-text)}.fail{color:var(--critical)}
.legend{display:flex;flex-wrap:wrap;gap:14px;font-size:13px;color:var(--ink-2);margin:6px 0 8px}
.legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:6px;vertical-align:-1px}
svg text{fill:var(--muted);font-size:12px}svg .lbl{fill:var(--ink-2)}svg .val{fill:var(--ink);font-weight:600}
svg [data-tip]{cursor:default}svg [data-tip]:hover,svg [data-tip]:focus{opacity:.8;outline:none}
#tip{position:fixed;pointer-events:none;background:var(--surface);color:var(--ink);border:1px solid var(--border);
border-radius:6px;padding:6px 9px;font-size:13px;box-shadow:0 2px 8px rgba(0,0,0,.12);display:none;max-width:280px}
details summary{cursor:pointer;color:var(--ink-2)}code{font-size:13px}
ul.caveats li{margin:4px 0}
"""

TIP_JS = """
const tip=document.getElementById('tip');
function show(e){const t=e.target.closest('[data-tip]');if(!t)return;tip.textContent='';
t.getAttribute('data-tip').split('\\n').forEach((line,i)=>{const d=document.createElement('div');
if(i===0)d.style.fontWeight='600';d.textContent=line;tip.appendChild(d)});tip.style.display='block';
const r=e.clientX!==undefined&&e.type!=='focusin'?{x:e.clientX,y:e.clientY}:(()=>{const b=t.getBoundingClientRect();return{x:b.right,y:b.top}})();
tip.style.left=Math.min(r.x+12,innerWidth-tip.offsetWidth-8)+'px';tip.style.top=(r.y+12)+'px'}
function hide(e){if(e.target.closest('[data-tip]'))tip.style.display='none'}
document.addEventListener('pointermove',show);document.addEventListener('focusin',show);
document.addEventListener('pointerout',hide);document.addEventListener('focusout',hide);
"""


def esc(x):
    return html.escape(str(x), quote=True)


def ms(x):
    return f"{x:,.0f} ms"


def pc(x, digits=1):
    return f"{x * 100:.{digits}f}%"


def hbars(rows, unit="ms", width=720, color="var(--series-1)", label_w=260, fmt=None):
    """Single-series horizontal bars. rows: [(label, value, tooltip)]."""
    fmt = fmt or (lambda v: f"{v:,.0f} {unit}")
    if not rows:
        return "<p class='muted'>No data.</p>"
    bar_h, gap = 18, 10
    vmax = max(v for _, v, _ in rows) or 1
    plot_w = width - label_w - 80
    h = len(rows) * (bar_h + gap) + 4
    out = [f'<svg viewBox="0 0 {width} {h}" width="100%" role="img" aria-label="bar chart">']
    out.append(f'<line x1="{label_w}" x2="{label_w}" y1="0" y2="{h}" stroke="var(--axis)" stroke-width="1"/>')
    for i, (label, v, tipt) in enumerate(rows):
        y = i * (bar_h + gap) + 2
        w = max(2.0, plot_w * v / vmax)
        out.append(f'<text class="lbl" x="{label_w - 8}" y="{y + 13}" text-anchor="end">{esc(label)}</text>')
        out.append(f'<path d="M{label_w},{y} h{w - 4:.1f} a4,4 0 0 1 4,4 v{bar_h - 8} a4,4 0 0 1 -4,4 h-{w - 4:.1f} z" '
                   f'fill="{color}" tabindex="0" data-tip="{esc(tipt)}"/>')
        out.append(f'<text class="val" x="{label_w + w + 6:.1f}" y="{y + 13}">{esc(fmt(v))}</text>')
    out.append("</svg>")
    return "".join(out)


def paired_bars(groups, series, width=720, label_w=150):
    """Two-series horizontal bars per group. groups: [(label, [v1, v2], [tip1, tip2])]."""
    bar_h, inner, gap = 14, 2, 14
    vmax = max((max(vs) for _, vs, _ in groups), default=1) or 1
    plot_w = width - label_w - 80
    gh = len(series) * (bar_h + inner) + gap
    h = len(groups) * gh + 4
    out = ['<div class="legend">' + "".join(f'<span><i style="background:{c}"></i>{esc(n)}</span>' for n, c in series)
           + "</div>", f'<svg viewBox="0 0 {width} {h}" width="100%" role="img" aria-label="grouped bar chart">',
           f'<line x1="{label_w}" x2="{label_w}" y1="0" y2="{h}" stroke="var(--axis)"/>']
    for gi, (label, vals, tips) in enumerate(groups):
        y0 = gi * gh + 2
        out.append(f'<text class="lbl" x="{label_w - 8}" y="{y0 + bar_h + 4}" text-anchor="end">{esc(label)}</text>')
        for si, ((name, color), v, tipt) in enumerate(zip(series, vals, tips)):
            y = y0 + si * (bar_h + inner)
            w = max(2.0, plot_w * v / vmax)
            out.append(f'<path d="M{label_w},{y} h{w - 4:.1f} a4,4 0 0 1 4,4 v{bar_h - 8} a4,4 0 0 1 -4,4 '
                       f'h-{w - 4:.1f} z" fill="{color}" tabindex="0" data-tip="{esc(tipt)}"/>')
            out.append(f'<text class="val" x="{label_w + w + 6:.1f}" y="{y + 11}">{v:,.0f} ms</text>')
    out.append("</svg>")
    return "".join(out)


def stacked_share(parts, width=720):
    """One 100% horizontal bar. parts: [(key, label, count, color)]."""
    total = sum(c for _, _, c, _ in parts) or 1
    h, x = 28, 0.0
    out = ['<div class="legend">' + "".join(
        f'<span><i style="background:{c}"></i>{esc(l)} · {n:,} ({pc(n / total)})</span>' for _, l, n, c in parts if n)
        + "</div>", f'<svg viewBox="0 0 {width} {h}" width="100%" role="img" aria-label="share of visits by path">']
    for key, label, n, color in parts:
        if not n:
            continue
        w = width * n / total
        out.append(f'<rect x="{x:.1f}" y="0" width="{max(0.0, w - 2):.1f}" height="{h}" rx="4" fill="{color}" '
                   f'tabindex="0" data-tip="{esc(label)}\n{n:,} visits ({pc(n / total)})"/>')
        x += w
    out.append("</svg>")
    return "".join(out)


def histogram(values, threshold, width=720, bins=None):
    bins = bins or [0, 1, 10, 20, 30, 40, 60, 80, 100, 1000]
    counts = [0] * (len(bins) - 1)
    for v in values:
        for i in range(len(bins) - 1):
            if bins[i] <= v < bins[i + 1]:
                counts[i] += 1
                break
    labels = ["0"] + [f"{bins[i]}–{bins[i + 1] - 1}" for i in range(1, len(bins) - 2)] + [f"{bins[-2]}+"]
    h, top, base = 200, 24, 170
    n = len(counts)
    slot = (width - 40) / n
    bw = min(24.0, slot * 0.6)
    cmax = max(counts) or 1
    out = [f'<svg viewBox="0 0 {width} {h}" width="100%" role="img" aria-label="risk score distribution">',
           f'<line x1="30" x2="{width - 10}" y1="{base}" y2="{base}" stroke="var(--axis)"/>']
    for i, c in enumerate(counts):
        x = 30 + i * slot + (slot - bw) / 2
        bh = max(0.0, (base - top) * c / cmax)
        risky = bins[i] >= threshold
        color = "var(--series-2)" if risky else "var(--series-1)"
        if c:
            out.append(f'<path d="M{x:.1f},{base} v-{max(bh - 4, 0):.1f} a4,4 0 0 1 4,-4 h{bw - 8:.1f} a4,4 0 0 1 4,4 '
                       f'v{max(bh - 4, 0):.1f} z" fill="{color}" tabindex="0" '
                       f'data-tip="Score {labels[i]}\n{c:,} visits{" · at or above threshold" if risky else ""}"/>')
            out.append(f'<text class="val" x="{x + bw / 2:.1f}" y="{base - bh - 4:.1f}" text-anchor="middle">{c:,}</text>')
        out.append(f'<text x="{x + bw / 2:.1f}" y="{base + 16}" text-anchor="middle">{esc(labels[i])}</text>')
    out.append("</svg>")
    legend = (f'<div class="legend"><span><i style="background:var(--series-1)"></i>Below threshold</span>'
              f'<span><i style="background:var(--series-2)"></i>At or above threshold ({threshold})</span></div>')
    return legend + "".join(out)


def table(headers, rows, numeric=()):
    head = "".join(f'<th class="{"n" if i in numeric else ""}">{esc(h)}</th>' for i, h in enumerate(headers))
    body = "".join("<tr>" + "".join(f'<td class="{"n" if i in numeric else ""}">{c}</td>' for i, c in enumerate(r))
                   + "</tr>" for r in rows)
    return f'<div class="scroll"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def tile(value, label, detail=""):
    return f'<div class="tile"><div class="v">{value}</div><div class="l">{esc(label)}</div>' \
           f'<div class="d">{detail}</div></div>'


def gate_value(g):
    a = g["actual"]
    if a is None:
        return "—"
    if g["unit"] == "ratio":
        return pc(a, 2)
    if g["unit"] == "ms":
        return ms(a)
    return "yes" if a else "no"


def render(metrics, gates, policy, tiers, stats, records, schema, synthetic=None, extras=None):
    m = metrics
    synthetic = synthetic if synthetic is not None else schema.get("synthetic_payloads", 0) > 0
    n_pass = sum(g["passed"] is True for g in gates)
    n_gates = sum(g["passed"] is not None for g in gates)
    parts = []
    parts.append(f"<h1>Risk-adaptive collection: replay report</h1>"
                 f"<p class='sub'>Policy <code>{esc(policy['version'])}</code> · <code>{esc(policy['hash'])}</code> · "
                 f"built {esc(policy['createdAt'])}</p>"
                 f"<p class='sub'>{m['train_visits']:,} visits to build the policy (earliest 70%), "
                 f"{m['test_visits']:,} held-out visits replayed (latest 30%).</p>")
    if synthetic:
        parts.append("<div class='banner'><strong>Synthetic fixtures.</strong> These numbers come from generated "
                     "payloads used to exercise the pipeline. They say nothing about real traffic yet.</div>")
    if schema.get("timing_mode") == "elapsed":
        parts.append("<div class='banner'><strong>Estimated timing.</strong> These payloads record each check's "
                     "time from its own launch but not when it started (no offsets), so adaptive collection time is "
                     "an estimate: the unexplained part of each visit is held fixed and checks keep their recorded "
                     "times even when the work blocking them is skipped. This tends to understate savings.</div>")
    parts.append("<div class='banner'>Capability demonstration only: offline replay, no production change, no live "
                 "learning. There are no fraud labels; “risk” is a governed rule-based score on the full scan. "
                 "ClientA / ClientB are a <strong>synthetic split</strong> of one client's traffic.</div>")

    # Headline tiles
    red = m["lowrisk_p50_reduction"]
    parts.append("<div class='tiles'>"
                 + tile(pc(red, 0) + " faster", "Low-risk visits, p50",
                        f"{ms(m['lowrisk_full_p50_ms'])} → {ms(m['lowrisk_adaptive_p50_ms'])}")
                 + tile(pc(m["risk_coverage"], 1), "Risky visits escalated or deep",
                        f"{m['risky_visits']:,} visits at or above threshold")
                 + tile(pc(min(m["sensitive_deep_rate"], m["flagged_deep_rate"]), 0), "Sensitive and flagged on full scan",
                        f"{m['sensitive_visits']:,} sensitive · {m['flagged_visits']:,} flagged")
                 + tile(pc(m["signal_retention"], 1), "Signal retained on the fast path",
                        f"value-weighted; {pc(m['attr_retention'], 0)} of attributes by count")
                 + tile(pc(1 - m["bytes_fast_mean"] / m["bytes_fast_full_mean"], 0) if m["bytes_fast_full_mean"] else "—",
                        "Smaller payload on the fast path",
                        f"{m['bytes_fast_full_mean']:,.0f} → {m['bytes_fast_mean']:,.0f} bytes per visit")
                 + "</div>")

    # Gates
    rows = []
    for g in gates:
        status = ("<span class='muted'>— n/a</span>" if g["passed"] is None else
                  "<span class='pass'>✓ Pass</span>" if g["passed"] else "<span class='fail'>✕ Fail</span>")
        target = f"{g['op']} {pc(g['value'], 0) if g['unit'] == 'ratio' else ms(g['value']) if g['unit'] == 'ms' else 'yes'}"
        rows.append([status, esc(g["label"]), gate_value(g), esc(target)])
    parts.append(f"<h2>Validation gates</h2><p class='sub'>{n_pass} of {n_gates} pass{" (" + str(len(gates) - n_gates) + " not applicable to this data)" if n_gates < len(gates) else ""}. Thresholds are placeholders "
                 f"in <code>py/adaptive/config/gates.json</code>.</p><div class='card'>"
                 + table(["Status", "Gate", "Actual", "Target"], rows, numeric=(2,)) + "</div>")

    # Paths
    counts = Counter(r["path"] for r in records)
    parts.append("<h2>How visits were handled</h2><p class='sub'>Every held-out visit, by the path the policy chose."
                 "</p><div class='card'>"
                 + stacked_share([(k, PATH_LABELS[k], counts.get(k, 0), PATH_COLOR[k]) for k in PATH_ORDER])
                 + "<h3>Reasons</h3>" + table(["Reason", "Visits", "Share"],
                                              [[esc(REASON_LABELS.get(k, k)), f"{v:,}", pc(v / len(records))]
                                               for k, v in sorted(m["reasons"].items(), key=lambda kv: -kv[1])],
                                              numeric=(1, 2)) + "</div>")

    # Latency
    groups = []
    trows = []
    for b, s in m["by_bucket"].items():
        groups.append((b, [s["full_p50_ms"], s["adaptive_p50_ms"]],
                       [f"{b} · full scan\np50 {ms(s['full_p50_ms'])}",
                        f"{b} · adaptive\np50 {ms(s['adaptive_p50_ms'])} · {pc(s['fast_share'], 0)} on fast path"]))
        trows.append([esc(b), f"{s['visits']:,}", pc(s["fast_share"], 0), ms(s["full_p50_ms"]),
                      ms(s["adaptive_p50_ms"]), ms(s["fast_p50_ms"]) if s["fast_p50_ms"] else "—"])
    parts.append("<h2>Latency</h2><p class='sub'>p50 collection time per browser version, today's full scan vs the "
                 "adaptive policy (all paths).</p><div class='card'>"
                 + paired_bars(groups, [("Full scan (today)", "var(--series-2)"), ("Adaptive", "var(--series-1)")])
                 + table(["Browser", "Visits", "Fast path", "Full p50", "Adaptive p50", "Fast-path p50"], trows,
                         numeric=(1, 2, 3, 4, 5))
                 + table(["", "p50", "p95"],
                         [["Full scan, all visits", ms(m["full_p50_ms"]), ms(m["full_p95_ms"])],
                          ["Adaptive, all visits", ms(m["adaptive_p50_ms"]), ms(m["adaptive_p95_ms"])],
                          ["Fast path only", ms(m["fast_p50_ms"]), ms(m["fast_p95_ms"])]], numeric=(1, 2))
                 + "</div>")

    # Where the time goes
    allstats = stats["*"]["attrs"]
    tier_by_attr = {}
    for b, t in tiers.items():
        for a, tier in t.items():
            tier_by_attr.setdefault(a, Counter())[tier] += 1
    dropped = []
    for a, s in allstats.items():
        tc = tier_by_attr.get(a, Counter())
        main_tier = tc.most_common(1)[0][0] if tc else "—"
        if main_tier in ("skip", "optional") and s["contrib_ms"] >= 2:
            dropped.append((a, s, main_tier))
    dropped.sort(key=lambda x: -x[1]["contrib_ms"])
    rows_svg = [(a, s["contrib_ms"], f"{a}\nadds {s['contrib_ms']:.0f} ms per visit on average\n"
                 f"available {pc(s['availability'], 0)} · distinctiveness {s['discrimination']:.2f} · "
                 f"stability {pc(s['stability'], 0)}\n{t} on most browsers") for a, s, t in dropped[:15]]
    tier_rows = []
    for b, t in sorted(tiers.items()):
        c = Counter(t.values())
        tier_rows.append([esc(b), f"{c['required']:,}", f"{c['high']:,}", f"{c['optional']:,}", f"{c['skip']:,}"])
    parts.append("<h2>Where the time goes</h2><p class='sub'>Checks left off the fast path, by how much each one "
                 "adds to the visit's total time on average (time saved if only that check is skipped).</p>"
                 "<div class='card'>" + hbars(rows_svg) + "<h3>Checks per tier and browser</h3>"
                 + table(["Browser", "Required", "High value", "Deep only", "Skipped (no signal)"], tier_rows,
                         numeric=(1, 2, 3, 4))
                 + "<p class='muted'>Required: risk-rule inputs, identity (wdi1), network fingerprint and product "
                   "metadata; they always run and keep their configured timeout. High value: distinctive and stable "
                   "for that browser, with a wait tuned to the observed p95. Deep only: collected on full scans. "
                   "Skipped: almost never returns a useful value on that browser.</p></div>")

    # Risk
    miss_rows = [[esc(r["payload_id"]), esc(r["bucket"]), f"{r['full_score']}", esc(", ".join(r["full_fired"])),
                  esc(", ".join(r["lost_rule_inputs"]) or "—")] for r in m["risk_misses"][:20]]
    parts.append("<h2>Risk coverage</h2><p class='sub'>Full-scan risk score of every held-out visit. Visits at or "
                 "above the threshold must leave the fast path (by escalation or a guardrail).</p><div class='card'>"
                 + histogram([r["full_score"] for r in records], policy["escalation"]["threshold"])
                 + (table(["Missed visit", "Browser", "Score", "Rules fired (full scan)", "Signal lost to a wait"],
                          miss_rows, numeric=(2,)) if miss_rows else
                    "<p>No misses: every visit at or above the threshold was escalated or ran the full scan.</p>")
                 + "</div>")

    # Recognition
    rf, rq = m["recognition_full"], m["recognition_fast"]
    parts.append("<h2>Recognition</h2><p class='sub'>Can the fast path still recognise a returning device? A "
                 f"fingerprint over {m['recognition_attrs']} stable, distinctive attributes, compared across "
                 "consecutive visits that share a wdi1.</p><div class='card'>"
                 + table(["Attribute set", "Visit pairs", "Same-device match", "Identities sharing a fingerprint"],
                         [["Full scan", f"{rf['pairs']:,}", pc(rf["match_rate"]), pc(rf["collision_rate"])],
                          ["Fast path", f"{rq['pairs']:,}", pc(rq["match_rate"]), pc(rq["collision_rate"])]],
                         numeric=(1, 2, 3)) + "</div>")

    # Network
    cl_rows = [[esc(c["cluster"]), esc(c["reason"].replace("_", " ")), f"{c['visits']:,}", f"{c['identities']:,}",
                esc(" + ".join(c["clients"])), f"{c['maxScore']}"] for c in m["network_clusters"][:15]]
    pc_rows = [[esc(k) + " <span class='muted'>(synthetic)</span>", f"{v['visits']:,}", f"{v['flaggedVisits']:,}",
                f"{v['crossClientClusters']:,}"] for k, v in sorted(m["network_per_client"].items())]
    parts.append("<h2>Network model (demo)</h2><p class='sub'>Devices linked by a hardware fingerprint across the "
                 "synthetic clients. A flag raised on one visit makes later visits from that identity run the full "
                 "scan. Only aggregates are shown; no client sees another's identities or events.</p><div class='card'>"
                 + table(["Client", "Visits", "Visits flagged before they started", "Shared clusters"], pc_rows,
                         numeric=(1, 2, 3))
                 + "<h3>Flagged clusters</h3>"
                 + (table(["Cluster", "Why", "Visits", "Identities (wdi1)", "Seen at", "Max score"], cl_rows,
                          numeric=(2, 3, 5)) if cl_rows else "<p class='muted'>No clusters flagged.</p>")
                 + "</div>")

    from .report_extras import render_extras
    parts.append(render_extras(extras, policy["escalation"]["threshold"]))

    # Data and caveats
    parts.append("<h2>Data and method</h2><div class='card'>"
                 + table(["", ""], [
                     ["Payloads ingested", f"{schema.get('payloads', 0):,}"],
                     ["Attributes seen", f"{schema.get('attributes_seen', 0):,}"],
                     ["Payload keys not in features.js", f"{len(schema.get('unknown_paths', [])):,}"],
                     ["Enabled in features.js but never seen", f"{len(schema.get('enabled_never_seen', [])):,}"],
                     ["Payloads without wdi1", f"{schema.get('missing_wdi1', 0):,}"],
                     ["Synthetic payloads (generated by fixtures.py)", f"{schema.get('synthetic_payloads', 0):,}"],
                     ["Rebuilt time matches collectionRunTime (±20 ms or 5%)",
                      pc(schema["runtime_match_rate"]) if schema.get("runtime_match_rate") is not None else "not reported"],
                     ["Policy size", f"{m['policy_bytes']:,} bytes"],
                     ["Collect-everything replay vs observed", f"max Δ {m['replay_identity_max_delta_ms']:.3f} ms"],
                 ])
                 + "<h3>Caveats</h3><ul class='caveats'>"
                   "<li>Latency is re-timed from recorded offsets and durations. Skipping a blocking check moves later "
                   "checks earlier; skipping a concurrent one removes only its own end time. Less main-thread "
                   "contention is not modelled, so savings are likely understated.</li>"
                   "<li>An escalated visit is timed as: the fast path so far, then every skipped check starting at the "
                   "moment of escalation with its recorded duration.</li>"
                   "<li>Risk is a rule-based score, not fraud ground truth. Rules marked <code>confirm</code> in "
                   "<code>risk_rules.json</code> assume value shapes that still need checking on real payloads.</li>"
                   "<li>Server flags are keyed on wdi1. A device that resets wdi1 on every visit is only caught when "
                   "its own signals escalate it.</li>"
                   "<li>Recognition uses wdi1 as the same-device reference, so wdi1 resets count against both "
                   "attribute sets equally.</li></ul>"
                 + "<details><summary>Schema gaps</summary><pre>"
                 + esc(json.dumps({k: schema.get(k) for k in ("unknown_paths", "enabled_never_seen",
                                                              "disabled_but_seen")}, indent=1)) + "</pre></details>"
                 + "</div>")

    return ("<!doctype html><html lang='en'><head><meta charset='utf-8'>"
            "<meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>Adaptive Collection Replay</title><style>{CSS}</style></head><body><main>"
            + "".join(parts) + f"</main><div id='tip' role='tooltip'></div><script>{TIP_JS}</script></body></html>")
