"""Policy build (Python only) plus decide/escalate, which mirror policy-js exactly."""

import fnmatch
import json
import math
from datetime import datetime, timezone
from pathlib import Path

from .hashing import fnv1a32, in_baseline_sample, policy_hash
from .risk import rule_fires, rule_inputs

SCHEMA = "adaptive-policy/1"
BUILD_CONFIG = Path(__file__).parent / "config" / "policy_build.json"
TIERS = ("required", "high")
OPS = ("truthy", "equals", "regex", "differs")


def load_build_config(path=BUILD_CONFIG):
    return json.loads(Path(path).read_text())


def required_attrs(paths, rules, cfg):
    req = set(rule_inputs(rules)) | set(cfg["networkFingerprint"])
    for p in paths:
        if any(fnmatch.fnmatchcase(p, pat) for pat in cfg["requiredPatterns"]):
            req.add(p)
    return sorted(req)


def classify_bucket(attr_stats, required, cfg):
    """attr path -> tier: required | high | optional | skip."""
    tiers = {}
    for path, s in attr_stats.items():
        if path in required:
            tiers[path] = "required"
        elif s["availability"] < cfg["skipBelowAvailability"]:
            tiers[path] = "skip"
        elif s["value"] >= cfg["highValueMin"] and (s["p95_ms"] <= cfg["costCapMs"] or s["value"] >= cfg["highValueOverride"]):
            tiers[path] = "high"
        else:
            tiers[path] = "optional"
    return tiers


def build(stats, catalog, rules, cfg, training_ids, version="0.1.0"):
    """stats: value.bucket_stats() on the training split. Returns (policy, tiers_by_bucket)."""
    timeouts = {a.path: a.timeout_ms for a in catalog}
    enabled = {a.path for a in catalog if a.collect}
    all_paths = sorted(p for p in stats["*"]["attrs"] if p in enabled)
    required = required_attrs(all_paths, rules, cfg)
    buckets, tiers_by_bucket = {}, {}
    for bucket, bs in sorted(stats.items()):
        if bucket == "*" or bs["n"] < cfg["minBucketSupport"]:
            continue
        attrs = {p: s for p, s in bs["attrs"].items() if p in enabled}
        tiers = classify_bucket(attrs, set(required), cfg)
        for p in required:  # required even if this bucket never saw it
            tiers.setdefault(p, "required")
        tiers_by_bucket[bucket] = tiers
        checks = []
        for p, tier in tiers.items():
            if tier not in TIERS:
                continue
            s = attrs.get(p)
            wait = timeouts.get(p, 2000)
            if tier == "high" and s and s["ok_p95_ms"] > 0:
                wait = min(wait, int(math.ceil(s["ok_p95_ms"] * cfg["waitMultiplier"])) + 1)
            cost = s["p50_ms"] if s else 0.0
            rank = 0 if tier == "required" else 1
            sort_key = cost if tier == "required" else -(s["value"] / max(cost, 0.05))
            checks.append(((rank, sort_key, p), {"attr": p, "tier": tier, "waitMs": int(wait)}))
        checks.sort(key=lambda c: c[0])
        buckets[bucket] = {"support": bs["n"], "checks": [c[1] for c in checks]}
    policy = {
        "schema": SCHEMA,
        "version": version,
        "createdAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "sourceDataHash": "fnv1a32:%08x" % fnv1a32("\n".join(sorted(training_ids))),
        "required": required,
        "guardrails": {
            "sensitiveEvents": list(cfg["sensitiveEvents"]),
            "baselineRate": cfg["baselineRate"],
            "minBucketSupport": cfg["minBucketSupport"],
        },
        "escalation": {"threshold": rules["threshold"], "rulesVersion": rules["version"],
                       "rules": [{k: r[k] for k in ("id", "weight", "when", "conflict") if k in r} for r in rules["rules"]]},
        "buckets": buckets,
    }
    policy["hash"] = policy_hash(policy)
    return policy, tiers_by_bucket


# ---- mirrored in policy-js -------------------------------------------------

def validate(policy):
    """Returns None if valid, else a reason string."""
    if not isinstance(policy, dict):
        return "not_object"
    if policy.get("schema") != SCHEMA:
        return "schema"
    for key in ("version", "hash", "sourceDataHash"):
        if not isinstance(policy.get(key), str):
            return f"field:{key}"
    try:
        if policy_hash(policy) != policy["hash"]:
            return "hash_mismatch"
    except (TypeError, ValueError):
        return "hash_error"
    req = policy.get("required")
    if not isinstance(req, list) or not all(isinstance(a, str) for a in req):
        return "field:required"
    g = policy.get("guardrails")
    if not isinstance(g, dict) or not isinstance(g.get("sensitiveEvents"), list) \
            or not _is_num(g.get("baselineRate")) or not 0 <= g["baselineRate"] <= 1:
        return "field:guardrails"
    e = policy.get("escalation")
    if not isinstance(e, dict) or not _is_num(e.get("threshold")) or not isinstance(e.get("rules"), list):
        return "field:escalation"
    for r in e["rules"]:
        w = r.get("when") if isinstance(r, dict) else None
        if not isinstance(w, dict) or w.get("op") not in OPS or not isinstance(w.get("attr"), str) \
                or not _is_num(r.get("weight")):
            return "field:escalation.rules"
    b = policy.get("buckets")
    if not isinstance(b, dict):
        return "field:buckets"
    for name, bucket in b.items():
        checks = bucket.get("checks") if isinstance(bucket, dict) else None
        if not isinstance(checks, list):
            return f"bucket:{name}"
        for c in checks:
            if not isinstance(c, dict) or not isinstance(c.get("attr"), str) or c.get("tier") not in TIERS \
                    or not isinstance(c.get("waitMs"), int) or isinstance(c.get("waitMs"), bool) or c["waitMs"] <= 0:
                return f"bucket:{name}:check"
        have = {c["attr"] for c in checks}
        if any(a not in have for a in req):
            return f"required_missing:{name}"
    return None


def _is_num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


_UNSET = object()


def decide(policy, ctx, validated=_UNSET):
    """ctx: payloadId, eventName, browserFamily, browserMajor, serverFlagged.

    validated: pass a cached validate() result (None means valid) to skip re-hashing per visit.
    """
    reason = validate(policy) if validated is _UNSET else validated
    if reason is not None:
        return {"mode": "full", "reason": f"policy_invalid:{reason}"}
    g = policy["guardrails"]
    bucket = f"{ctx.get('browserFamily')}:{ctx.get('browserMajor')}"
    if ctx.get("eventName") in g["sensitiveEvents"]:
        return {"mode": "deep", "reason": "sensitive_journey", "bucket": bucket}
    if ctx.get("serverFlagged"):
        return {"mode": "deep", "reason": "server_flagged", "bucket": bucket}
    if bucket not in policy["buckets"]:
        return {"mode": "deep", "reason": "unknown_browser", "bucket": bucket}
    if in_baseline_sample(str(ctx.get("payloadId", "")), g["baselineRate"]):
        return {"mode": "deep", "reason": "baseline_sample", "bucket": bucket}
    return {"mode": "fast", "reason": "low_risk", "bucket": bucket, "checks": policy["buckets"][bucket]["checks"]}


class Escalator:
    """Feeds signals as they arrive; escalates once score >= threshold or a conflict rule fires."""

    def __init__(self, policy):
        self.rules = policy["escalation"]["rules"]
        self.threshold = policy["escalation"]["threshold"]
        self.values = {}
        self.fired = []
        self.score = 0
        self.escalated = False

    def on_signal(self, attr, value):
        self.values[attr] = value
        conflict = False
        for r in self.rules:
            if r["id"] in self.fired:
                continue
            if rule_fires(r["when"], self.values):
                self.fired.append(r["id"])
                self.score += r["weight"]
                conflict = conflict or bool(r.get("conflict"))
        if not self.escalated and (self.score >= self.threshold or conflict):
            self.escalated = True
            return {"action": "escalate", "score": self.score, "fired": list(self.fired),
                    "reason": "conflict" if conflict and self.score < self.threshold else "risk_threshold"}
        return {"action": "escalated" if self.escalated else "continue", "score": self.score, "fired": list(self.fired)}
