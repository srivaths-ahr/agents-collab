"""Offline replay: apply a policy to each held-out visit and measure the outcome."""

from .hashing import fnv1a32
from .model import MISSING, OK
from .policy import Escalator, decide, validate
from .risk import score
from .timing import observed_latency, simulate


def recognition_slots(stats_all, index, min_stability=0.9, min_discrimination=0.2, min_availability=0.9):
    """Stable, discriminating attributes used to link visits of the same device."""
    out = []
    for path, s in stats_all["attrs"].items():
        if s["stability_pairs"] >= 5 and s["stability"] >= min_stability \
                and s["discrimination"] >= min_discrimination and s["availability"] >= min_availability:
            out.append(index.slot[path])
    return sorted(out)


def _fp(visit, slots, exclude=()):
    parts = [f"{s}:{visit.vhash[s]}" for s in slots if visit.status[s] == OK and s not in exclude]
    return "%08x" % fnv1a32("|".join(parts)) if parts else None


def replay(visits, index, policy, rules, stats, flagged_at_visit, rec_slots):
    validated = validate(policy)
    rule_slots = {a: index.slot[a] for a in {r["when"]["attr"] for r in rules["rules"]}
                  | {r["when"].get("other") for r in rules["rules"] if r["when"].get("other")} if a in index.slot}
    bucket_plan = {}
    for name, b in policy["buckets"].items():
        keep = {index.slot[c["attr"]] for c in b["checks"] if c["attr"] in index.slot}
        waits = {index.slot[c["attr"]]: c["waitMs"] for c in b["checks"] if c["attr"] in index.slot}
        bucket_plan[name] = (keep, waits)
    records = []
    for v in visits:
        full_lat = observed_latency(v)
        full_score, full_fired, _ = score(rules, v.rule_values)
        flagged = flagged_at_visit.get(v.payload_id)
        ctx = {"payloadId": v.payload_id, "eventName": v.event_name, "browserFamily": v.browser_family,
               "browserMajor": v.browser_major, "serverFlagged": flagged is not None}
        d = decide(policy, ctx, validated)
        weights = stats.get(v.bucket, stats["*"])["attrs"]
        present = [s for s in range(len(v.status)) if v.status[s] != MISSING]
        ok_slots = [s for s in present if v.status[s] == OK]
        bytes_full = sum(v.size[s] for s in present)
        rec = {"payload_id": v.payload_id, "ts": v.ts, "wdi1": v.wdi1, "bucket": v.bucket, "event": v.event_name,
               "client": v.client_id, "server_flag": flagged, "full_score": full_score,
               "full_fired": full_fired, "latency_full": full_lat, "bytes_full": bytes_full,
               "ok_n": len(ok_slots), "present_n": len(present)}
        plan = bucket_plan.get(v.bucket)
        if d["mode"] != "fast":
            rec.update(path=d["mode"], reason=d["reason"], latency=full_lat, bytes=bytes_full,
                       kept_ok_n=len(ok_slots), retention=1.0, escalation=None, lost_rule_inputs=[])
        else:
            keep, waits = plan
            lat, ends, lost = simulate(v, keep, waits)
            esc = Escalator(policy)
            arrivals = sorted((ends[s], a) for a, s in rule_slots.items()
                              if s in ends and s not in lost and a in v.rule_values)
            esc_at, esc_reason = None, None
            for t, a in arrivals:
                r = esc.on_signal(a, v.rule_values[a])
                if r["action"] == "escalate":
                    esc_at, esc_reason = t, r["reason"]
                    break
            kept_ok = [s for s in ok_slots if s in keep and s not in lost]
            total_w = sum(weights.get(index.paths[s], {}).get("value", 0.0) for s in ok_slots)
            kept_w = sum(weights.get(index.paths[s], {}).get("value", 0.0) for s in kept_ok)
            lost_inputs = sorted(a for a, s in rule_slots.items() if s in lost)
            if esc_at is not None:
                rest = [s for s in present if s not in keep or s in lost]
                lat = max([lat] + [esc_at + v.duration[s] for s in rest])
                rec.update(path="escalated", reason=esc_reason, latency=lat, bytes=bytes_full,
                           kept_ok_n=len(ok_slots), retention=1.0, escalation=round(esc_at, 2),
                           lost_rule_inputs=lost_inputs)
            else:
                rec.update(path="fast", reason="low_risk", latency=lat,
                           bytes=sum(v.size[s] for s in present if s in keep and s not in lost),
                           kept_ok_n=len(kept_ok), retention=(kept_w / total_w) if total_w else 1.0,
                           escalation=None, lost_rule_inputs=lost_inputs)
        # recognition fingerprints: full stable set vs what the bucket's fast path would carry
        rec["fp_full"] = _fp(v, rec_slots)
        if plan:
            keep, waits = plan
            _, _, lost_fast = simulate(v, keep, waits)
            rec["fp_fast"] = _fp(v, [s for s in rec_slots if s in keep], lost_fast)
        else:
            rec["fp_fast"] = rec["fp_full"]
        records.append(rec)
    return records
