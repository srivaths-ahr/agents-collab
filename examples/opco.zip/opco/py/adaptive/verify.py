"""Server-side check that a received payload matches the decision it claims.

The client sends a stamp with each payload: policy hash, mode, reason, and
whether it escalated. The server recomputes the decision from what it knows
(event, browser, its own flags) and checks the payload against it. Collecting
more than planned is allowed; collecting less, or skipping a guardrail, is not.
"""

import copy
from dataclasses import dataclass

from .model import MISSING, OK, TIMEOUT
from .policy import decide
from .risk import score

CRITICAL, WARNING, INFO = "critical", "warning", "info"
FULL_SCAN_MIN_COVERAGE = 0.98


@dataclass
class Finding:
    code: str
    severity: str
    detail: str = ""


def verify(visit, stamp, registry, index, ctx, enabled_slots):
    """visit: what the server received. stamp: {policyHash, mode, reason, escalated}.

    registry: {hash: policy} the server has issued. Returns a list of Finding.
    """
    findings = []
    policy = registry.get(stamp.get("policyHash"))
    present = {s for s in range(len(visit.status)) if visit.status[s] != MISSING}
    coverage = len(present & enabled_slots) / len(enabled_slots) if enabled_slots else 1.0

    if policy is None:
        if stamp.get("mode") != "full":
            findings.append(Finding("unknown_policy", CRITICAL, "policy hash was never issued"))
        elif coverage < FULL_SCAN_MIN_COVERAGE:
            findings.append(Finding("incomplete_full_scan", CRITICAL, f"coverage {coverage:.1%}"))
        return findings

    expected = decide(policy, ctx, validated=None)  # registry only holds policies the server issued
    claimed = stamp.get("mode")
    if claimed == "fast" and expected["mode"] != "fast":
        findings.append(Finding("skipped_guardrail", CRITICAL, f"server expected {expected['reason']}"))
    elif claimed != "fast" and expected["mode"] == "fast" and not stamp.get("escalated"):
        findings.append(Finding("extra_scrutiny", INFO, f"client ran {claimed} ({stamp.get('reason')})"))

    full_like = claimed != "fast" or stamp.get("escalated")
    if full_like:
        if coverage < FULL_SCAN_MIN_COVERAGE:
            findings.append(Finding("incomplete_full_scan", CRITICAL, f"coverage {coverage:.1%}"))
    else:
        checks = policy["buckets"].get(expected.get("bucket"), {}).get("checks", [])
        planned = {index.slot[c["attr"]] for c in checks if c["attr"] in index.slot}
        missing = [a for a in policy["required"] if a in index.slot and index.slot[a] not in present]
        if missing:
            findings.append(Finding("required_missing", CRITICAL, ", ".join(missing[:5])))
        extra = present - planned
        if extra:
            findings.append(Finding("unplanned_collection", WARNING, f"{len(extra)} checks outside the plan"))

    values = {a: visit.rule_values[a] for a in visit.rule_values if visit.status[index.slot[a]] == OK}
    s, fired, conflict = score({"rules": policy["escalation"]["rules"]}, values)
    risky = s >= policy["escalation"]["threshold"] or conflict
    if claimed == "fast" and not stamp.get("escalated") and risky:
        findings.append(Finding("missed_escalation", CRITICAL, f"score {s}: {', '.join(fired)}"))
    if stamp.get("escalated") and not risky:
        findings.append(Finding("unjustified_escalation", INFO, f"score {s}"))
    return findings


def client_view(visit, keep, lost):
    """What the server would receive from a fast-path visit: skipped checks absent, cut waits as timeouts."""
    v = copy.copy(visit)
    v.status = copy.copy(visit.status)
    v.rule_values = dict(visit.rule_values)
    for s in range(len(v.status)):
        if v.status[s] == MISSING:
            continue
        if s not in keep:
            v.status[s] = MISSING
        elif s in lost:
            v.status[s] = TIMEOUT
    return v
