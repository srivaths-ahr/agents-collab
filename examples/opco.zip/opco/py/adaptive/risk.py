"""Rule-based anomaly score. Mirrors policy-js/src/rules.js exactly."""

import json
import re
from pathlib import Path

from .hashing import canonical_json

RULES_PATH = Path(__file__).parent / "rules" / "risk_rules.json"


def load_rules(path=RULES_PATH):
    return json.loads(Path(path).read_text())


def rule_inputs(rules):
    attrs = []
    for r in rules["rules"]:
        w = r["when"]
        for a in (w["attr"], w.get("other")):
            if a and a not in attrs:
                attrs.append(a)
    return attrs


def _read(value, key):
    if key is None:
        return value
    for part in key.split("."):
        if not isinstance(value, dict) or part not in value:
            return None
        value = value[part]
    return value


def _same(a, b):
    # type-aware equality that matches JS (Python treats True == 1)
    return canonical_json(a) == canonical_json(b)


def _truthy(v):
    # JS truthiness, minus NaN handling (no NaN in JSON)
    return v not in (None, False, 0, "") and not (isinstance(v, float) and v == 0.0)


def rule_fires(when, values):
    """values: attr -> raw value, only for attributes collected with status ok."""
    if when["attr"] not in values:
        return False
    v = _read(values[when["attr"]], when.get("key"))
    op = when["op"]
    if op == "truthy":
        return _truthy(v)
    if op == "equals":
        return v is not None and _same(v, when["value"])
    if op == "regex":
        if not isinstance(v, str):
            return False
        flags = re.IGNORECASE if "i" in when.get("flags", "") else 0
        return re.search(when["pattern"], v, flags) is not None
    if op == "differs":
        if when["other"] not in values or v is None:
            return False
        other = values[when["other"]]
        if other is None or other == "":
            return False
        mapping = when.get("map", {})
        if isinstance(v, str) and v in mapping:
            v = mapping[v]
        return not _same(v, other)
    raise ValueError(f"unknown rule op {op}")


def score(rules, values):
    """Returns (score, fired rule ids, conflict)."""
    total, fired, conflict = 0, [], False
    for r in rules["rules"]:
        if rule_fires(r["when"], values):
            total += r["weight"]
            fired.append(r["id"])
            conflict = conflict or bool(r.get("conflict"))
    return total, fired, conflict
