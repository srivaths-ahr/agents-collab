"""Critical-path model built from per-attribute offset + duration.

A check is "serial" (blocks the main thread) when no other check starts
while it runs; skipping or shortening it moves every later start earlier by
the time saved. Concurrent checks only drop their own end time. With every
check kept and no waits, the result equals the observed latency exactly.
"""

from bisect import bisect_right

from .model import MISSING

# Elapsed mode (payloads without start offsets, e.g. real collector 9.4.0 exports):
# each check's time runs from its own launch to resolution, and launches are not recorded.
# Estimate: visit time = prelude + slowest kept check, where
#   prelude = collectionRunTime - slowest check overall (launch staggering, sync work, payload assembly).
# The prelude is held fixed (the policy cannot remove it) and kept checks keep their recorded times
# (they would usually finish sooner once blocking checks are skipped). Both choices understate savings
# from cheap work, but skipping the slowest check is credited in full even if it launched early,
# which can overstate savings. Calibrate against payloads with offsets before quoting numbers.


def prelude(visit):
    present = [visit.duration[s] for s in range(len(visit.status)) if visit.status[s] != MISSING]
    return max(0.0, (visit.run_time_ms or 0.0) - max(present, default=0.0))


def _simulate_elapsed(visit, keep, waits):
    base = prelude(visit)
    latency, ends, lost = base, {}, set()
    for s in range(len(visit.status)):
        if visit.status[s] == MISSING or (keep is not None and s not in keep):
            continue
        d = visit.duration[s]
        w = waits.get(s)
        if w is not None and d > w:
            d = float(w)
            lost.add(s)
        ends[s] = base + d
        latency = max(latency, ends[s])
    return latency, ends, lost

EPS = 0.01  # ms; offsets are stored as float32


def _items(visit):
    items = [(visit.offset[s], visit.duration[s], s) for s in range(len(visit.status)) if visit.status[s] != MISSING]
    items.sort()
    return items


def _serial_flags(items):
    """serial[i] is True if the next strictly-later start is at or after this check's end."""
    offsets = sorted({o for o, _, _ in items})
    next_start = {o: (offsets[i + 1] if i + 1 < len(offsets) else float("inf")) for i, o in enumerate(offsets)}
    return [next_start[o] >= o + d - EPS for o, d, _ in items]


def simulate(visit, keep=None, waits=None):
    """Re-pack the observed timeline.

    keep: set of slots to collect (None = all). waits: slot -> max wait ms.
    Returns (latency_ms, ends {slot: end_ms}, lost {slots cut by their wait}).
    """
    waits = waits or {}
    if visit.elapsed:
        return _simulate_elapsed(visit, keep, waits)
    items = _items(visit)
    serial = _serial_flags(items)
    # Time saved by a serial check only moves checks that start strictly later,
    # so savings from the current offset group are held in `pending` until it ends.
    shift, pending, group = 0.0, 0.0, None
    latency, ends, lost = 0.0, {}, set()
    for (o, d, s), is_serial in zip(items, serial):
        if o != group:
            shift, pending, group = shift + pending, 0.0, o
        if keep is not None and s not in keep:
            if is_serial:
                pending += d
            continue
        w = waits.get(s)
        d2 = d
        if w is not None and d > w:
            d2 = float(w)
            lost.add(s)
        end = (o - shift) + d2
        ends[s] = end
        latency = max(latency, end)
        if is_serial:
            pending += d - d2
    return latency, ends, lost


def observed_latency(visit):
    if visit.elapsed:
        return _simulate_elapsed(visit, None, {})[0]
    items = _items(visit)
    return max((o + d for o, d, _ in items), default=0.0)


def contributions(visit):
    """slot -> ms the visit would finish earlier if only that check were skipped."""
    if visit.elapsed:
        base = prelude(visit)
        ds = sorted(((visit.duration[s], s) for s in range(len(visit.status)) if visit.status[s] != MISSING),
                    reverse=True)
        out = {s: 0.0 for _, s in ds}
        if ds:
            second = ds[1][0] if len(ds) > 1 else 0.0
            out[ds[0][1]] = max(0.0, (base + ds[0][0]) - (base + second))
        return out
    items = _items(visit)
    if not items:
        return {}
    serial = _serial_flags(items)
    ends = [o + d for o, d, _ in items]
    full = max(ends)
    offsets = [o for o, _, _ in items]
    n = len(items)
    prefix = [0.0] * (n + 1)  # prefix[i] = max end of items[:i]
    for i in range(n):
        prefix[i + 1] = max(prefix[i], ends[i])
    suffix = [0.0] * (n + 1)  # suffix[i] = max end of items[i:]
    for i in range(n - 1, -1, -1):
        suffix[i] = max(suffix[i + 1], ends[i])
    top = sorted(range(n), key=lambda i: ends[i], reverse=True)[:2]
    out = {}
    for i, (o, d, s) in enumerate(items):
        if serial[i]:
            cut = bisect_right(offsets, o)  # items starting at or before o are not shifted
            before = max(prefix[i], max((ends[k] for k in range(i + 1, cut)), default=0.0))
            after = suffix[cut] - d if cut < n else 0.0
            without = max(before, after)
        else:
            without = ends[top[1]] if (len(top) > 1 and top[0] == i) else (full if top[0] != i else 0.0)
        out[s] = max(0.0, full - without)
    return out
