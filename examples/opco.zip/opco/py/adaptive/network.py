"""Cross-client network model (demo).

All real payloads come from one client, so visits are split into a
SYNTHETIC ClientA / ClientB (2:1, seeded). The model streams visits in time
order, links devices by a hardware fingerprint, and raises server flags that
only apply to later visits ("deep scan on the next visit"). Flags are keyed
on wdi1, the identifier available before collection starts.
"""

import random
from collections import defaultdict

from .hashing import fnv1a32
from .model import OK
from .risk import score

CLIENT_A, CLIENT_B = "ClientA", "ClientB"
IDENTITY_RESET_LIMIT = 4  # distinct wdi1 on one hardware fingerprint


def assign_clients(visits, seed=11, share_a=2 / 3):
    """Each identity (wdi1) belongs to one synthetic client; fill ClientA to ~2/3 of visits."""
    groups = defaultdict(list)
    for v in visits:
        groups[v.wdi1 or v.payload_id].append(v)
    keys = sorted(groups)
    random.Random(seed).shuffle(keys)
    target = round(len(visits) * share_a)
    filled = 0
    for k in keys:
        client = CLIENT_A if filled + len(groups[k]) <= target else CLIENT_B
        if client == CLIENT_A:
            filled += len(groups[k])
        for v in groups[k]:
            v.client_id = client


def hardware_fingerprint(visit, slots):
    parts = [f"{s}:{visit.vhash[s]}" for s in slots if visit.status[s] == OK]
    if len(parts) * 2 < len(slots):
        return None
    return "%08x" % fnv1a32("|".join(parts))


def stream(visits, index, rules, fingerprint_attrs):
    """Returns (flagged_at_visit {payload_id: reason or None}, clusters, per_client)."""
    slots = [index.slot[a] for a in fingerprint_attrs if a in index.slot]
    threshold = rules["threshold"]
    fp_wdi1 = defaultdict(set)
    fp_clients = defaultdict(set)
    fp_visits = defaultdict(int)
    fp_max = defaultdict(int)
    fp_flag = {}
    wdi1_flag = {}
    flagged_at_visit = {}
    for v in visits:  # time-ordered
        flagged_at_visit[v.payload_id] = wdi1_flag.get(v.wdi1) if v.wdi1 else None
        s, _, _ = score(rules, v.rule_values)
        fp = hardware_fingerprint(v, slots)
        if s >= threshold and v.wdi1:
            wdi1_flag.setdefault(v.wdi1, "risky_device")
        if fp is None:
            continue
        if v.wdi1:
            fp_wdi1[fp].add(v.wdi1)
        fp_clients[fp].add(v.client_id)
        fp_visits[fp] += 1
        fp_max[fp] = max(fp_max[fp], s)
        reason = fp_flag.get(fp)
        if reason is None:
            if len(fp_wdi1[fp]) >= IDENTITY_RESET_LIMIT:
                reason = "identity_resets"
            elif len(fp_clients[fp]) > 1 and len(fp_wdi1[fp]) >= 2 and fp_max[fp] >= threshold:
                reason = "cross_client_risk"
            if reason:
                fp_flag[fp] = reason
        if reason:
            for w in fp_wdi1[fp]:
                wdi1_flag.setdefault(w, reason)
    clusters = []
    for i, (fp, reason) in enumerate(sorted(fp_flag.items(), key=lambda kv: -fp_visits[kv[0]])):
        clusters.append({"cluster": f"C{i + 1:02d}", "reason": reason, "visits": fp_visits[fp],
                         "identities": len(fp_wdi1[fp]), "clients": sorted(fp_clients[fp]), "maxScore": fp_max[fp]})
    per_client = defaultdict(lambda: {"visits": 0, "flaggedVisits": 0, "crossClientClusters": 0})
    for v in visits:
        pc = per_client[v.client_id]
        pc["visits"] += 1
        pc["flaggedVisits"] += flagged_at_visit[v.payload_id] is not None
    for c in clusters:
        if len(c["clients"]) > 1:
            for cl in c["clients"]:
                per_client[cl]["crossClientClusters"] += 1
    return flagged_at_visit, clusters, dict(per_client)
