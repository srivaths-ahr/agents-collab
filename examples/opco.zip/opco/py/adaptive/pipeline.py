"""End-to-end run: ingest -> split -> value -> policy -> network -> replay -> gates -> report."""

import copy
import json
from pathlib import Path

from . import catalog as cat
from . import scenarios as sc
from .gates import evaluate, summarise
from .ingest import ingest
from .network import assign_clients, stream
from .policy import Escalator, build, decide, load_build_config, validate
from .replay import recognition_slots, replay
from .risk import load_rules
from .timing import observed_latency, simulate
from .value import bucket_stats

TRAIN_SHARE = 0.7
POLICY_JS_FIXTURES = Path(__file__).resolve().parents[2] / "policy-js" / "test" / "fixtures"


def sanity_checks(test, policy):
    # 1. Keeping every check with no waits reproduces observed latency exactly.
    worst = max((abs(simulate(v)[0] - observed_latency(v)) for v in test), default=0.0)
    # 2. Corrupted policies fall back to full scan.
    bad = copy.deepcopy(policy)
    bad["version"] += "-tampered"  # any edit breaks the content hash
    corrupt = [bad, {**policy, "schema": "x"}, None, {}]
    fallback_ok = all(decide(p, {"payloadId": v.payload_id, "browserFamily": v.browser_family,
                                 "browserMajor": v.browser_major, "eventName": v.event_name})["mode"] == "full"
                      for p in corrupt for v in test[:50])
    return {"replay_identity_max_delta_ms": worst, "replay_identity_ok": int(worst < 0.01),
            "fallback_ok": int(fallback_ok)}


def golden_cases(test, policy, rules, flagged, limit=500):
    """Decision + escalation cases for policy-js parity tests."""
    cases = []
    escalation_attrs = sorted({r["when"]["attr"] for r in rules["rules"]}
                              | {r["when"]["other"] for r in rules["rules"] if r["when"].get("other")})
    for v in test[:limit]:
        ctx = {"payloadId": v.payload_id, "eventName": v.event_name, "browserFamily": v.browser_family,
               "browserMajor": v.browser_major, "serverFlagged": flagged.get(v.payload_id) is not None}
        d = decide(policy, ctx)
        esc = Escalator(policy)
        signals = [[a, v.rule_values[a]] for a in escalation_attrs if a in v.rule_values]
        steps = [esc.on_signal(a, val) for a, val in signals]
        cases.append({"ctx": ctx, "decision": d, "signals": signals, "steps": steps})
    edge = [
        {"payloadId": "edge-sensitive", "eventName": "payee_add", "browserFamily": "chrome", "browserMajor": 131},
        {"payloadId": "edge-flagged", "eventName": "login", "browserFamily": "chrome", "browserMajor": 131,
         "serverFlagged": True},
        {"payloadId": "edge-unknown", "eventName": "login", "browserFamily": "opera", "browserMajor": 1},
    ]
    for ctx in edge:
        cases.append({"ctx": ctx, "decision": decide(policy, ctx), "signals": [], "steps": []})
    return cases


def run(data_dir, out_dir, write_golden=True, with_scenarios=True, cfg_overrides=None):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rules = load_rules()
    cfg = {**load_build_config(), **(cfg_overrides or {})}
    catalog = cat.build_catalog()
    ds = ingest(data_dir, rules, catalog=catalog, extra_values=[sc.NEW_RULE["when"]["attr"]])
    visits = ds.visits
    cut = int(len(visits) * TRAIN_SHARE)
    train, test = visits[:cut], visits[cut:]

    stats = bucket_stats(train, ds.index)
    policy, tiers = build(stats, catalog, rules, cfg, [v.payload_id for v in train])
    assert validate(policy) is None, validate(policy)

    assign_clients(visits)
    flagged, clusters, per_client = stream(visits, ds.index, rules, cfg["networkFingerprint"])
    rec_slots = recognition_slots(stats["*"], ds.index)
    records = replay(test, ds.index, policy, rules, stats, flagged, rec_slots)

    sanity = sanity_checks(test, policy)
    metrics = summarise(records, rules["threshold"], cfg["sensitiveEvents"], sanity)
    metrics.update({"runtime_match_rate": ds.schema.get("runtime_match_rate"),
                    "timing_mode": ds.schema.get("timing_mode"), "cfg_overrides": cfg_overrides or {},
                    "train_visits": len(train), "test_visits": len(test), "recognition_attrs": len(rec_slots),
                    "network_clusters": clusters, "network_per_client": per_client, "schema": ds.schema,
                    "policy_version": policy["version"], "policy_hash": policy["hash"],
                    "policy_bytes": len(json.dumps(policy, separators=(",", ":")))})
    gates = evaluate(metrics)

    (out / f"policy-{policy['version']}.json").write_text(json.dumps(policy, indent=1))
    (out / "tiers.json").write_text(json.dumps(tiers, indent=1, sort_keys=True))
    (out / "stats.json").write_text(json.dumps(stats))
    (out / "metrics.json").write_text(json.dumps(metrics, indent=1, default=str))
    (out / "gates.json").write_text(json.dumps(gates, indent=1, default=str))
    with (out / "records.jsonl").open("w") as f:
        for r in records:
            f.write(json.dumps(r, default=str) + "\n")
    if write_golden:
        POLICY_JS_FIXTURES.mkdir(parents=True, exist_ok=True)
        (POLICY_JS_FIXTURES / "policy.json").write_text(json.dumps(policy, indent=1))
        (POLICY_JS_FIXTURES / "golden.json").write_text(
            json.dumps(golden_cases(test, policy, rules, flagged), indent=1))
        (POLICY_JS_FIXTURES / "catalog.json").write_text(
            json.dumps(sorted(a.path for a in catalog if a.collect), indent=0))

    extras = {}
    if with_scenarios:
        ctx = sc.Context(ds, rules, cfg, catalog, flagged)
        extras = {
            "timelines": sc.timelines(ctx, test, policy, records),
            "verification": sc.verification(ctx, test, policy, records),
            "kill_switch": sc.kill_switch(ctx, test, policy, stats),
            "new_rule": sc.new_rule(ctx, train, test, policy, stats),
            "sweep": sc.sweep(ctx, train, test, stats),
            "rolling": sc.rolling_release(ctx, visits),
        }
        (out / "scenarios.json").write_text(json.dumps(extras, indent=1, default=str))

    from .report import render
    (out / "report.html").write_text(render(metrics, gates, policy, tiers, stats, records, ds.schema, extras=extras))
    from .demo import build as build_demo
    build_demo([(out, "This run")], out / "demo.html")
    return metrics, gates
