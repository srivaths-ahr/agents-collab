"""Per-browser signal value of each check, from training visits only."""

import math
from collections import Counter, defaultdict

from .model import MISSING, OK, TIMEOUT
from .timing import contributions

CONTRIB_SAMPLE = 400  # visits per bucket used for critical-path contribution


def _pct(sorted_vals, q):
    if not sorted_vals:
        return 0.0
    k = min(len(sorted_vals) - 1, max(0, int(math.ceil(q * len(sorted_vals))) - 1))
    return sorted_vals[k]


def entropy_norm(counter):
    n = sum(counter.values())
    if n <= 1 or len(counter) <= 1:
        return 0.0
    h = -sum((c / n) * math.log2(c / n) for c in counter.values())
    return h / math.log2(n)


def bucket_stats(visits, index):
    """Returns {bucket: {"n": int, "attrs": {path: stats}}} plus "*" for all visits."""
    groups = defaultdict(list)
    for v in visits:
        groups[v.bucket].append(v)
    groups["*"] = list(visits)
    return {b: _stats_for(vs, index) for b, vs in groups.items()}


def _stats_for(visits, index):
    n_slots = len(index)
    seen = [0] * n_slots
    ok = [0] * n_slots
    timeouts = [0] * n_slots
    durations = [[] for _ in range(n_slots)]
    ok_durations = [[] for _ in range(n_slots)]
    sizes = [0] * n_slots
    device_values = [Counter() for _ in range(n_slots)]
    stable = [0] * n_slots
    pairs = [0] * n_slots
    last_by_device = {}
    for v in visits:  # visits are time-ordered
        first_for_device = v.wdi1 not in last_by_device
        prev = last_by_device.get(v.wdi1)
        for s in range(n_slots):
            st = v.status[s]
            if st == MISSING:
                continue
            seen[s] += 1
            durations[s].append(v.duration[s])
            sizes[s] += v.size[s]
            if st == TIMEOUT:
                timeouts[s] += 1
            if st == OK:
                ok[s] += 1
                ok_durations[s].append(v.duration[s])
                if first_for_device:
                    device_values[s][v.vhash[s]] += 1
            # a flip between ok and not-ok counts as unstable
            if prev is not None and (st == OK or prev.status[s] == OK):
                pairs[s] += 1
                stable[s] += st == OK and prev.status[s] == OK and prev.vhash[s] == v.vhash[s]
        if v.wdi1:
            last_by_device[v.wdi1] = v
    contrib_sum = [0.0] * n_slots
    sample = visits[:: max(1, len(visits) // CONTRIB_SAMPLE)]
    for v in sample:
        for s, c in contributions(v).items():
            contrib_sum[s] += c
    attrs = {}
    for s, path in enumerate(index.paths):
        if not seen[s]:
            continue
        d = sorted(durations[s])
        okd = sorted(ok_durations[s])
        availability = ok[s] / seen[s]
        discrimination = entropy_norm(device_values[s])
        stability = stable[s] / pairs[s] if pairs[s] else 0.0
        attrs[path] = {
            "seen": seen[s],
            "availability": availability,
            "timeout_rate": timeouts[s] / seen[s],
            "discrimination": discrimination,
            "stability": stability,
            "stability_pairs": pairs[s],
            "value": availability * discrimination * (stability if pairs[s] >= 5 else 0.5),
            "p50_ms": _pct(d, 0.5),
            "p95_ms": _pct(d, 0.95),
            "ok_p95_ms": _pct(okd, 0.95),
            "contrib_ms": contrib_sum[s] / len(sample) if sample else 0.0,
            "mean_bytes": sizes[s] / seen[s],
        }
    return {"n": len(visits), "attrs": attrs}
