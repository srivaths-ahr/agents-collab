"""Raw decompressed payloads -> Visit records, plus a schema coverage report."""

import base64
import binascii
import json
import zlib
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from . import catalog as cat
from .hashing import value_hash
from .model import ERROR, MISSING, OK, TIMEOUT, UNAVAILABLE, AttrIndex, empty_visit
from .risk import rule_inputs

ADAPTER_PATH = Path(__file__).parent / "config" / "adapter.json"
STATUS_BY_NAME = {"unavailable": UNAVAILABLE, "timeout": TIMEOUT, "error": ERROR}
_ABSENT = object()


@dataclass
class Dataset:
    index: AttrIndex
    catalog: list
    visits: list
    schema: dict = field(default_factory=dict)


def load_adapter(path=ADAPTER_PATH):
    return json.loads(Path(path).read_text())


def get_path(obj, dotted, default=_ABSENT):
    for part in dotted.split("."):
        if not isinstance(obj, dict) or part not in obj:
            return default
        obj = obj[part]
    return obj


def _timing_entries(raw, adapter):
    root = get_path(raw, adapter["timingRoot"], {})
    if adapter["timingLayout"] == "flat":
        return root.items()
    # nested: same tree as values, leaves are {offset, duration}
    out = []

    def walk(node, path):
        if isinstance(node, dict) and adapter["durationKey"] in node:
            out.append((".".join(path), node))
            return
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, path + [k])

    walk(root, [])
    return out


def browser_bucket(name, version, families):
    fam = families.get(str(name or "").strip().lower(), "other")
    try:
        major = int(str(version).split(".")[0])
    except (TypeError, ValueError):
        major = 0
    return fam, major


def classify(value, adapter):
    if value is _ABSENT or value is None:
        return UNAVAILABLE
    if isinstance(value, str) and value in adapter["statusValues"]:
        return STATUS_BY_NAME[adapter["statusValues"][value]]
    return OK


def is_list_payload(raw, adapter):
    key = adapter["list"]["nameKey"]
    return isinstance(raw, list) and bool(raw) and all(isinstance(x, dict) and key in x for x in raw[:5])


def _record(visit, index, path, status, value, rule_attrs):
    slot = index.add(path)
    visit.ensure_size(len(index))
    visit.status[slot] = status
    if value is not _ABSENT:
        visit.size[slot] = len(json.dumps(value, separators=(",", ":")))
    if status == OK:
        visit.vhash[slot] = value_hash(value)
        if path in rule_attrs:
            visit.rule_values[path] = value
    return slot


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def list_to_visit(raw, source, index, adapter, rule_attrs, leaf_to_path):
    """Real export: [{name, data | error, time}]. 'time' is elapsed from the check's own launch, no offsets."""
    la = adapter["list"]
    by_name = {e[la["nameKey"]]: e for e in raw}
    meta = lambda key: by_name.get(la[key], {}).get(la["valueKey"])  # noqa: E731
    fam, major = browser_bucket(meta("browserName"), meta("browserVersion"), adapter["browserFamilies"])
    ts = _num(meta("timestamp")) or 0
    ts = int(ts * 1000) if la["timestampUnit"] == "s" else int(ts)
    visit = empty_visit(
        len(index), payload_id=source, ts=ts, wdi1=str(meta("wdi1") or ""), event_name=str(meta("eventName") or ""),
        browser_family=fam, browser_major=major, run_time_ms=_num(meta("runTime")),
    )
    has_offsets = all(la["startKey"] in e for e in raw if la["timeKey"] in e)
    visit.elapsed = not has_offsets
    for name, e in by_name.items():
        path = leaf_to_path.get(name, name)  # unknown names keep their bare name and show up in the schema report
        if la["errorKey"] in e:
            err = e[la["errorKey"]]
            code = str(err.get(la["errorCodeKey"]) if isinstance(err, dict) else err)
            status, value = STATUS_BY_NAME.get(la["errorCodes"].get(code, "error"), ERROR), _ABSENT
        else:
            value = e.get(la["valueKey"], _ABSENT)
            status = UNAVAILABLE if value is _ABSENT or value is None else OK
        slot = _record(visit, index, path, status, value, rule_attrs)
        visit.duration[slot] = _num(e.get(la["timeKey"])) or 0.0
        if has_offsets:
            visit.offset[slot] = _num(e.get(la["startKey"])) or 0.0
    return visit


def to_visit(raw, index, adapter, rule_attrs):
    families = adapter["browserFamilies"]
    adapter = adapter["tree"]
    fam, major = browser_bucket(get_path(raw, adapter["browserName"], None),
                                get_path(raw, adapter["browserVersion"], None), families)
    ts = get_path(raw, adapter["timestamp"], 0)
    ts = int(ts * 1000) if adapter["timestampUnit"] == "s" else int(ts)
    run_time = get_path(raw, adapter["runTime"], None)
    visit = empty_visit(
        len(index),
        payload_id=str(get_path(raw, adapter["payloadId"], "")),
        ts=ts,
        wdi1=str(get_path(raw, adapter["wdi1"], "") or ""),
        event_name=str(get_path(raw, adapter["eventName"], "") or ""),
        browser_family=fam,
        browser_major=major,
        run_time_ms=float(run_time) if isinstance(run_time, (int, float)) else None,
    )
    values_root = get_path(raw, adapter["valuesRoot"], {})
    for path, timing in _timing_entries(raw, adapter):
        value = get_path(values_root, path)
        slot = _record(visit, index, path, classify(value, adapter), value, rule_attrs)
        visit.offset[slot] = float(timing.get(adapter["offsetKey"], 0.0))
        visit.duration[slot] = float(timing.get(adapter["durationKey"], 0.0))
    return visit


def decode_compressed(text):
    """Base64 (standard or URL-safe) of Pako output: zlib (pako.deflate), gzip (pako.gzip) or raw deflate."""
    text = "".join(text.split())
    errors = []
    for b64 in (base64.b64decode, base64.urlsafe_b64decode):
        try:
            data = b64(text + "=" * (-len(text) % 4))
        except (binascii.Error, ValueError) as e:
            errors.append(f"{b64.__name__}: {e}")
            continue
        for wbits in (zlib.MAX_WBITS | 32, -zlib.MAX_WBITS):  # zlib/gzip auto-detect, then raw deflate
            try:
                return json.loads(zlib.decompress(data, wbits))
            except (zlib.error, ValueError) as e:
                errors.append(f"{b64.__name__}/wbits={wbits}: {e}")
    raise ValueError("not Base64 + Pako/zlib JSON: " + "; ".join(errors[:4]))


def iter_payload_files(data_dir, adapter=None):
    adapter = adapter or load_adapter()
    suffixes = {".json", ".jsonl", *adapter.get("compressed", {}).get("suffixes", [])}
    for p in sorted(Path(data_dir).rglob("*")):
        if p.is_file() and p.suffix in suffixes:
            yield p


def iter_raw(data_dir, adapter=None):
    """Yields (raw payload, source id). A file holding a list of {name, ...} entries is ONE payload."""
    adapter = adapter or load_adapter()
    compressed = set(adapter.get("compressed", {}).get("suffixes", []))
    for p in iter_payload_files(data_dir, adapter):
        if p.suffix in compressed:
            obj = decode_compressed(p.read_text())
            if is_list_payload(obj, adapter):
                yield obj, p.stem
            else:
                yield from ((item, f"{p.stem}:{n}") for n, item in enumerate(obj)) if isinstance(obj, list) \
                    else [(obj, p.stem)]
        elif p.suffix == ".jsonl":
            with p.open() as f:
                for n, line in enumerate(f):
                    if line.strip():
                        yield json.loads(line), f"{p.stem}:{n}"
        else:
            obj = json.loads(p.read_text())
            if is_list_payload(obj, adapter):
                yield obj, p.stem
            elif isinstance(obj, list):
                for n, item in enumerate(obj):
                    yield item, f"{p.stem}:{n}"
            else:
                yield obj, p.stem


def ingest(data_dir, rules, adapter=None, catalog=None, extra_values=()):
    """extra_values: attributes whose raw values are kept besides the rule inputs (for what-if rules)."""
    adapter = adapter or load_adapter()
    catalog = catalog if catalog is not None else cat.build_catalog()
    index = AttrIndex(a.path for a in catalog)
    rule_attrs = set(rule_inputs(rules)) | set(extra_values)
    leaf_to_path = {a.path.split(".")[-1]: a.path for a in catalog}  # leaf names are unique in features.js
    visits, synthetic = [], 0
    for raw, source in iter_raw(data_dir, adapter):
        if is_list_payload(raw, adapter):
            visits.append(list_to_visit(raw, source, index, adapter, rule_attrs, leaf_to_path))
        else:
            synthetic += raw.get("synthetic") is True  # set only by fixtures.py
            v = to_visit(raw, index, adapter, rule_attrs)
            v.payload_id = v.payload_id or source
            visits.append(v)
    for v in visits:
        v.ensure_size(len(index))
    visits.sort(key=lambda v: (v.ts, v.payload_id))
    schema = schema_report(index, catalog, visits)
    schema["synthetic_payloads"] = synthetic
    return Dataset(index, catalog, visits, schema)


def schema_report(index, catalog, visits):
    known = {a.path for a in catalog}
    enabled = {a.path for a in catalog if a.collect}
    seen = Counter()
    for v in visits:
        for slot, s in enumerate(v.status):
            if s != MISSING:
                seen[index.paths[slot]] += 1
    return {
        "payloads": len(visits),
        "attributes_seen": len(seen),
        "unknown_paths": sorted(p for p in seen if p not in known),
        "enabled_never_seen": sorted(p for p in enabled if p not in seen),
        "disabled_but_seen": sorted(p for p in seen if p in known and p not in enabled),
        "missing_wdi1": sum(1 for v in visits if not v.wdi1),
        "missing_ts": sum(1 for v in visits if not v.ts),
        **runtime_check(visits),
    }


RUNTIME_TOLERANCE_MS, RUNTIME_TOLERANCE_SHARE = 20.0, 0.05


def runtime_check(visits):
    """Does max(offset + duration) reproduce the collector's own product.collectionRunTime?

    Only meaningful for payloads with offsets. Elapsed-only payloads (no offsets) get prelude diagnostics
    instead: prelude = collectionRunTime - largest single check time.

    A visit matches when the two differ by at most 20 ms or 5%, whichever is larger. A low match rate
    means offsets are not relative to one collection start, and every latency number is suspect.
    """
    from .timing import observed_latency
    elapsed = [v for v in visits if v.elapsed and v.run_time_ms]
    prelude = sorted(v.run_time_ms - max(v.duration, default=0.0) for v in elapsed)
    out = {"timing_mode": "elapsed" if elapsed and len(elapsed) * 2 >= len(visits) else "offsets",
           "elapsed_visits": len(elapsed),
           "prelude_p50_ms": prelude[len(prelude) // 2] if prelude else None,
           "prelude_p95_ms": prelude[int(len(prelude) * .95)] if prelude else None,
           # one check's own elapsed time longer than the whole collection is impossible under the model
           "elapsed_inconsistent_share": sum(p < -1 for p in prelude) / len(prelude) if prelude else None}
    with_rt = [v for v in visits if v.run_time_ms and not v.elapsed]
    diffs = [abs(observed_latency(v) - v.run_time_ms) for v in with_rt]
    ok = sum(d <= max(RUNTIME_TOLERANCE_MS, RUNTIME_TOLERANCE_SHARE * v.run_time_ms) for d, v in zip(diffs, with_rt))
    diffs.sort()
    return {**out, "runtime_reported": len(with_rt),
            "runtime_match_rate": ok / len(with_rt) if with_rt else None,
            "runtime_abs_diff_p50_ms": diffs[len(diffs) // 2] if diffs else None}
