"""Compact in-memory visit model.

Each visit stores per-attribute status, offset, duration and a value hash in
fixed arrays indexed by AttrIndex, so 15k visits x ~300 attributes stay small.
Raw values are kept only for attributes that risk rules read.
"""

from array import array
from dataclasses import dataclass, field

# Status codes
OK, UNAVAILABLE, ERROR, TIMEOUT, MISSING = 0, 1, 2, 3, 4
STATUS_NAMES = {OK: "ok", UNAVAILABLE: "unavailable", ERROR: "error", TIMEOUT: "timeout", MISSING: "missing"}


class AttrIndex:
    """Stable attribute-path -> slot mapping. Grows when payloads carry unknown keys."""

    def __init__(self, paths=()):
        self.paths = []
        self.slot = {}
        for p in paths:
            self.add(p)

    def add(self, path):
        if path not in self.slot:
            self.slot[path] = len(self.paths)
            self.paths.append(path)
        return self.slot[path]

    def __len__(self):
        return len(self.paths)


@dataclass
class Visit:
    payload_id: str
    ts: int  # epoch ms
    wdi1: str
    event_name: str
    browser_family: str
    browser_major: int
    status: array  # 'b', per slot
    offset: array  # 'f', ms since collection start
    duration: array  # 'f', ms
    vhash: array  # 'q', value hash per slot (0 when not ok)
    size: array  # 'i', serialized value bytes per slot
    rule_values: dict = field(default_factory=dict)  # raw values for risk-rule inputs
    run_time_ms: float = None  # collector-reported total (product.collectionRunTime)
    client_id: str = ""  # synthetic, assigned by network.py
    elapsed: bool = False  # True: durations are elapsed-from-own-launch with no offsets (real 9.4.0 exports)

    @property
    def bucket(self):
        return f"{self.browser_family}:{self.browser_major}"

    def ensure_size(self, n):
        while len(self.status) < n:
            self.status.append(MISSING)
            self.offset.append(0.0)
            self.duration.append(0.0)
            self.vhash.append(0)
            self.size.append(0)


def empty_visit(n_slots, **meta):
    return Visit(
        status=array("b", [MISSING] * n_slots),
        offset=array("f", [0.0] * n_slots),
        duration=array("f", [0.0] * n_slots),
        vhash=array("q", [0] * n_slots),
        size=array("i", [0] * n_slots),
        **meta,
    )
