"""Summary metrics from replay records, and pass/fail gates."""

import json
import operator
from collections import Counter, defaultdict
from pathlib import Path

GATES_PATH = Path(__file__).parent / "config" / "gates.json"
OPS = {"<=": operator.le, ">=": operator.ge, "<": operator.lt, ">": operator.gt, "==": operator.eq}


def pct(values, q):
    vals = sorted(values)
    if not vals:
        return 0.0
    k = min(len(vals) - 1, max(0, round(q * (len(vals) - 1))))
    return vals[k]


def recognition(records, key):
    """Same-device match rate over consecutive visits sharing wdi1, and cross-wdi1 collision share."""
    last, pairs, match = {}, 0, 0
    for r in records:
        w = r["wdi1"]
        if w and w in last:
            pairs += 1
            match += r[key] is not None and r[key] == last[w][key]
        if w:
            last[w] = r
    by_fp = defaultdict(set)
    for r in records:
        if r[key] and r["wdi1"]:
            by_fp[r[key]].add(r["wdi1"])
    wdi1s = {r["wdi1"] for r in records if r["wdi1"]}
    colliding = set().union(*[ws for ws in by_fp.values() if len(ws) > 1]) if by_fp else set()
    return {"pairs": pairs, "match_rate": match / pairs if pairs else 0.0,
            "collision_rate": len(colliding) / len(wdi1s) if wdi1s else 0.0}


def summarise(records, threshold, sensitive_events, sanity):
    paths = Counter(r["path"] for r in records)
    reasons = Counter(r["reason"] for r in records)
    fast = [r for r in records if r["path"] == "fast"]
    low_risk = [r for r in records if r["full_score"] < threshold and r["path"] in ("fast", "escalated")]
    risky = [r for r in records if r["full_score"] >= threshold]
    sensitive = [r for r in records if r["event"] in sensitive_events]
    flagged = [r for r in records if r["server_flag"]]
    full_p50 = pct([r["latency_full"] for r in records], 0.5)
    lr_full = pct([r["latency_full"] for r in low_risk], 0.5)
    lr_adapt = pct([r["latency"] for r in low_risk], 0.5)
    rec_full = recognition(records, "fp_full")
    rec_fast = recognition(records, "fp_fast")
    misses = [r for r in risky if r["path"] == "fast"]
    by_bucket = defaultdict(list)
    for r in records:
        by_bucket[r["bucket"]].append(r)
    m = {
        "visits": len(records),
        "paths": dict(paths),
        "reasons": dict(reasons),
        "full_p50_ms": full_p50,
        "full_p95_ms": pct([r["latency_full"] for r in records], 0.95),
        "adaptive_p50_ms": pct([r["latency"] for r in records], 0.5),
        "adaptive_p95_ms": pct([r["latency"] for r in records], 0.95),
        "fast_p50_ms": pct([r["latency"] for r in fast], 0.5),
        "fast_p95_ms": pct([r["latency"] for r in fast], 0.95),
        "fast_full_p50_ms": pct([r["latency_full"] for r in fast], 0.5),
        "lowrisk_full_p50_ms": lr_full,
        "lowrisk_adaptive_p50_ms": lr_adapt,
        "lowrisk_p50_reduction": 1 - lr_adapt / lr_full if lr_full else 0.0,
        "risky_visits": len(risky),
        "risk_coverage": 1 - len(misses) / len(risky) if risky else 1.0,
        "risk_misses": [{k: r[k] for k in ("payload_id", "bucket", "full_score", "full_fired", "lost_rule_inputs")}
                        for r in misses],
        "sensitive_visits": len(sensitive),
        "sensitive_deep_rate": sum(r["path"] != "fast" for r in sensitive) / len(sensitive) if sensitive else 1.0,
        "flagged_visits": len(flagged),
        "flagged_deep_rate": sum(r["path"] != "fast" for r in flagged) / len(flagged) if flagged else 1.0,
        "signal_retention": sum(r["retention"] for r in fast) / len(fast) if fast else 1.0,
        "attr_retention": sum(r["kept_ok_n"] / r["ok_n"] for r in fast if r["ok_n"]) / len(fast) if fast else 1.0,
        "bytes_full_mean": sum(r["bytes_full"] for r in records) / len(records) if records else 0,
        "bytes_adaptive_mean": sum(r["bytes"] for r in records) / len(records) if records else 0,
        "bytes_fast_mean": sum(r["bytes"] for r in fast) / len(fast) if fast else 0,
        "bytes_fast_full_mean": sum(r["bytes_full"] for r in fast) / len(fast) if fast else 0,
        "recognition_full": rec_full,
        "recognition_fast": rec_fast,
        "recognition_drop": rec_full["match_rate"] - rec_fast["match_rate"],
        "by_bucket": {b: {"visits": len(rs), "fast_share": sum(r["path"] == "fast" for r in rs) / len(rs),
                          "full_p50_ms": pct([r["latency_full"] for r in rs], 0.5),
                          "adaptive_p50_ms": pct([r["latency"] for r in rs], 0.5),
                          "fast_p50_ms": pct([r["latency"] for r in rs if r["path"] == "fast"], 0.5)}
                      for b, rs in sorted(by_bucket.items(), key=lambda kv: -len(kv[1]))},
    }
    m.update(sanity)
    return m


def evaluate(metrics, path=GATES_PATH):
    gates = json.loads(Path(path).read_text())["gates"]
    out = []
    for g in gates:
        actual = metrics.get(g["metric"])
        if actual is None and g.get("optional"):
            out.append({**g, "actual": None, "passed": None})  # not applicable to this data (shown as n/a)
            continue
        passed = actual is not None and OPS[g["op"]](actual, g["value"])
        out.append({**g, "actual": actual, "passed": bool(passed)})
    return out
