"""Report sections for the what-if runs (scenarios.py)."""

from .report import esc, ms, pc, table


def timeline_svg(t, width=960, label_w=300, row_h=14, gap=4):
    """Per-check bars: full scan (muted) above, adaptive (blue, orange where a wait cut it) below."""
    rows = t["rows"]
    span = max([t["latency_full"], t["latency"]] + [r["start"] + r["dur"] for r in rows]) or 1
    plot_w = width - label_w - 20
    x = lambda ms_: label_w + plot_w * ms_ / span  # noqa: E731
    h = len(rows) * (row_h + gap) + 40
    out = [f'<svg viewBox="0 0 {width} {h}" width="100%" role="img" aria-label="per-check timeline">']
    for tick in range(0, int(span) + 1, 250):
        out.append(f'<line x1="{x(tick):.1f}" x2="{x(tick):.1f}" y1="0" y2="{h - 22}" stroke="var(--grid)"/>'
                   f'<text x="{x(tick):.1f}" y="{h - 8}" text-anchor="middle">{tick} ms</text>')
    for i, r in enumerate(rows):
        y = i * (row_h + gap) + 4
        out.append(f'<text class="lbl" x="{label_w - 8}" y="{y + 11}" text-anchor="end">{esc(r["attr"])}</text>')
        out.append(f'<rect x="{x(r["start"]):.1f}" y="{y}" width="{max(1.5, x(r["start"] + r["dur"]) - x(r["start"])):.1f}" '
                   f'height="{row_h / 2 - 1:.1f}" rx="2" fill="var(--axis)" tabindex="0" '
                   f'data-tip="{esc(r["attr"])}\nfull scan: {r["start"]:.0f}–{r["start"] + r["dur"]:.0f} ms"/>')
        if "fast_start" in r:
            color = "var(--series-2)" if r["cut"] else "var(--series-1)"
            note = "cut by its wait" if r["cut"] else "kept"
            out.append(f'<rect x="{x(r["fast_start"]):.1f}" y="{y + row_h / 2 + 1:.1f}" '
                       f'width="{max(1.5, x(r["fast_start"] + r["fast_dur"]) - x(r["fast_start"])):.1f}" '
                       f'height="{row_h / 2 - 1:.1f}" rx="2" fill="{color}" tabindex="0" '
                       f'data-tip="{esc(r["attr"])}\nfast path: {r["fast_start"]:.0f}–{r["fast_start"] + r["fast_dur"]:.0f} ms ({note})"/>')
    for val, label in ((t["latency_full"], "full scan ends"), (t["latency"], "this visit ends")):
        out.append(f'<line x1="{x(val):.1f}" x2="{x(val):.1f}" y1="0" y2="{h - 22}" stroke="var(--ink-2)" '
                   f'stroke-width="1.5"/>')
    if t.get("escalation") is not None:
        out.append(f'<line x1="{x(t["escalation"]):.1f}" x2="{x(t["escalation"]):.1f}" y1="0" y2="{h - 22}" '
                   f'stroke="var(--critical)" stroke-width="1.5"/>')
    out.append("</svg>")
    legend = ('<div class="legend"><span><i style="background:var(--axis)"></i>Full scan (today)</span>'
              '<span><i style="background:var(--series-1)"></i>Adaptive: kept</span>'
              '<span><i style="background:var(--series-2)"></i>Adaptive: cut by its wait</span>'
              + ('<span><i style="background:var(--critical)"></i>Escalation</span>' if t.get("escalation") is not None else "")
              + "</div>")
    return legend + "".join(out)


def line_chart(series, x_key, marker=None, width=900, height=220, y_fmt=lambda v: f"{v:,.0f} ms"):
    """series: [(name, color, [points])]; each point a dict with x_key and the series' value under 'y'."""
    xs = [p[x_key] for _, _, pts in series for p in pts]
    ys = [p["y"] for _, _, pts in series for p in pts]
    if not xs:
        return ""
    x0, x1 = min(xs), max(xs) or 1
    y1 = max(ys) * 1.1 or 1
    left, top, bottom = 56, 12, height - 28
    X = lambda v: left + (width - left - 16) * ((v - x0) / ((x1 - x0) or 1))  # noqa: E731
    Y = lambda v: bottom - (bottom - top) * v / y1  # noqa: E731
    out = ['<div class="legend">' + "".join(f'<span><i style="background:{c};height:2px;vertical-align:3px"></i>'
                                              f'{esc(n)}</span>' for n, c, _ in series) + "</div>",
           f'<svg viewBox="0 0 {width} {height}" width="100%" role="img" aria-label="line chart">']
    for frac in (0, 0.5, 1):
        v = y1 / 1.1 * frac
        out.append(f'<line x1="{left}" x2="{width - 16}" y1="{Y(v):.1f}" y2="{Y(v):.1f}" stroke="var(--grid)"/>'
                   f'<text x="{left - 6}" y="{Y(v) + 4:.1f}" text-anchor="end">{esc(y_fmt(v))}</text>')
    for v in sorted(set(xs))[:: max(1, len(set(xs)) // 10)]:
        out.append(f'<text x="{X(v):.1f}" y="{height - 8}" text-anchor="middle">day {v}</text>')
    if marker is not None:
        mx, mlabel = marker
        out.append(f'<line x1="{X(mx):.1f}" x2="{X(mx):.1f}" y1="{top}" y2="{bottom}" stroke="var(--critical)" '
                   f'stroke-width="1.5"/><text class="lbl" x="{X(mx) + 6:.1f}" y="{top + 12}">{esc(mlabel)}</text>')
    for name, color, pts in series:
        d = " ".join(f'{"M" if i == 0 else "L"}{X(p[x_key]):.1f},{Y(p["y"]):.1f}' for i, p in enumerate(pts))
        out.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="2" stroke-linejoin="round" '
                   f'stroke-linecap="round"/>')
        for p in pts:
            out.append(f'<circle cx="{X(p[x_key]):.1f}" cy="{Y(p["y"]):.1f}" r="4" fill="{color}" '
                       f'stroke="var(--surface)" stroke-width="2" tabindex="0" '
                       f'data-tip="{esc(name)}\nday {p[x_key]}: {esc(y_fmt(p["y"]))}"/>')
    out.append("</svg>")
    return "".join(out)


def render_extras(x, threshold):
    if not x:
        return ""
    parts = []

    tl = x.get("timelines") or []
    if tl:
        body = ""
        for t in tl:
            delta = t["latency_full"] - t["latency"]
            what = (f"finished {ms(delta)} sooner" if delta >= 0 else f"took {ms(-delta)} longer: it escalated at "
                    f"{ms(t['escalation'])} and then ran every skipped check")
            body += (f"<h3>{esc(t['title'])} · {esc(t['bucket'])}</h3><p class='sub'>Full scan {ms(t['latency_full'])}, "
                     f"this visit {ms(t['latency'])}: {what}. Showing checks of 3 ms or more "
                     f"({t['hidden_small']} shorter checks hidden).</p>" + timeline_svg(t))
        parts.append("<h2>One visit, check by check</h2><p class='sub'>Each row is one check. The grey bar is when it "
                     "ran in today's full scan; the coloured bar is when it would run under the policy. Rows with "
                     "no coloured bar are skipped.</p><div class='card'>" + body + "</div>")

    v = x.get("verification")
    if v:
        rows = [[esc(t["name"]), f"{t['attempts']:,}", f"{t['detected']:,}",
                 pc(t["detected"] / t["attempts"]) if t["attempts"] else "—",
                 esc(", ".join(f"{k} ({n})" for k, n in t["codes"].items()))] for t in v["tamper"]]
        parts.append("<h2>Server-side verification</h2><p class='sub'>The server recomputes each decision and checks "
                     "the payload against it. Collecting more than planned is allowed; collecting less, skipping a "
                     "guardrail, or suppressing an escalation is not.</p><div class='card'>"
                     f"<p>Honest payloads: <strong>{v['honest_visits']:,}</strong> checked, "
                     f"<strong>{v['honest_critical']:,}</strong> with a critical finding.</p>"
                     + table(["Tampering simulated", "Attempts", "Caught", "Rate", "Findings"], rows, numeric=(1, 2, 3))
                     + "</div>")

    n = x.get("new_rule")
    if n:
        s, r = n["stale"], n["rebuilt"]
        rows = [["Policy built before the rule", pc(s["risk_coverage"]), f"{s['misses']:,} of {s['risky']:,}",
                 ms(s["fast_p50_ms"]), pc(s["lowrisk_p50_reduction"], 0)],
                ["Policy rebuilt with the rule", pc(r["risk_coverage"]), f"{r['misses']:,} of {r['risky']:,}",
                 ms(r["fast_p50_ms"]), pc(r["lowrisk_p50_reduction"], 0)]]
        parts.append("<h2>Adding a rule after release</h2><p class='sub'>A new rule (<code>"
                     f"{esc(n['rule']['id'])}</code>) reads <code>{esc(n['attr'])}</code>, a check the current policy "
                     "leaves off the fast path. Until the policy is rebuilt, visits that only this rule would flag "
                     "stay on the fast path. Rebuilding makes the check required: coverage returns, latency pays for "
                     "it.</p><div class='card'>"
                     + table(["", "Risky visits escalated or deep", "Missed", "Fast-path p50", "Low-risk saving"],
                             rows, numeric=(1, 2, 3, 4))
                     + "<p class='muted'>Rule changes and policy rebuilds have to ship together; the release gates "
                       "catch the mismatch.</p></div>")

    sw = x.get("sweep")
    if sw:
        rows = []
        for r in sorted(sw, key=lambda r: (r["highValueMin"], r["costCapMs"])):
            mark = " <strong>(current)</strong>" if r["current"] else ""
            rows.append([f"{r['highValueMin']:.2f}{mark}", f"{r['costCapMs']} ms", ms(r["fast_p50_ms"]),
                         pc(r["lowrisk_p50_reduction"], 0), pc(r["signal_retention"]), pc(r["attr_retention"], 0),
                         pc(1 - r["bytes_ratio"], 0)])
        parts.append("<h2>Tuning trade-off</h2><p class='sub'>The same data replayed with different tier settings. "
                     "A higher bar for “high value” makes the fast path faster but keeps less signal.</p>"
                     "<div class='card'>"
                     + table(["High-value bar", "Cost cap", "Fast-path p50", "Low-risk saving",
                              "Signal kept (weighted)", "Attributes kept", "Payload saved"], rows,
                             numeric=(2, 3, 4, 5, 6)) + "</div>")

    ro = x.get("rolling")
    if ro:
        rows = []
        for r in ro:
            c, live = r["candidate"], r["live"]
            new = [b for b in r["buckets"] if not any(b in p["buckets"] for p in ro if p["window"] < r["window"])]
            action = "<span class='pass'>✓ Promote</span>" if r["action"] == "promote" else \
                "<span class='fail'>✕ Hold</span>"
            rows.append([f"{r['window']} (day {r['start_day']}–{r['start_day'] + 9})", f"{r['visits']:,}",
                         esc(", ".join(new)) if r["window"] > ro[0]["window"] and new else "—",
                         pc(live["unknown_share"], 0) if live else "—", pc(c["unknown_share"], 0),
                         pc(live["fast_share"], 0) if live else "—", pc(c["fast_share"], 0), action])
        parts.append("<h2>Rolling release</h2><p class='sub'>Every 10 days a candidate policy is built from the "
                     "previous 20 days, run in shadow on the next window, and promoted only if its gates pass. When a "
                     "new browser version appears, the live policy sends it to the full scan until a retrain covers "
                     "it.</p><div class='card'>"
                     + table(["Window", "Visits", "New browser versions covered", "Unknown browser (live)",
                              "Unknown browser (candidate)", "Fast path (live)", "Fast path (candidate)", "Decision"],
                             rows, numeric=(1, 3, 4, 5, 6)) + "</div>")

    k = x.get("kill_switch")
    if k and k.get("series"):
        parts.append("<h2>Kill switch</h2><p class='sub'>Halfway through the held-out period the delivered policy is "
                     f"corrupted. From day {k['switch_day']} every client falls back to today's full scan "
                     f"({pc(k['after_fallback_share'], 0)} of visits after the switch).</p><div class='card'>"
                     + line_chart([("Full scan (today)", "var(--series-2)",
                                    [{"day": p["day"], "y": p["full_p50_ms"]} for p in k["series"]]),
                                   ("Adaptive", "var(--series-1)",
                                    [{"day": p["day"], "y": p["adaptive_p50_ms"]} for p in k["series"]])],
                                  "day", marker=(k["switch_day"], "policy invalid"))
                     + "<p class='muted'>Daily p50 collection time.</p></div>")
    return "".join(parts)
