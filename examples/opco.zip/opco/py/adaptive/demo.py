"""Build the presentation page (demo.html) from one or more run output folders.

Each run folder is what `run-all` writes (metrics.json, gates.json, scenarios.json,
records.jsonl, policy-*.json). The page is self-contained: run data is embedded as
JSON and policy-js is inlined as data: URL modules behind an import map, so the
live slide works from file:// with no server.
"""

import base64
import json
import re
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TEMPLATE = Path(__file__).parent / "demo_template.html"
POLICY_JS_SRC = ROOT / "policy-js" / "src"
PATHS = ["fast", "escalated", "deep", "full"]
REASONS = ["low_risk", "risk_threshold", "conflict", "sensitive_journey", "server_flagged", "unknown_browser",
           "baseline_sample"]

METRIC_KEYS = ["visits", "paths", "reasons", "full_p50_ms", "full_p95_ms", "adaptive_p50_ms", "adaptive_p95_ms",
               "fast_p50_ms", "fast_p95_ms", "lowrisk_full_p50_ms", "lowrisk_adaptive_p50_ms", "lowrisk_p50_reduction",
               "risky_visits", "risk_coverage", "sensitive_visits", "sensitive_deep_rate", "flagged_visits",
               "flagged_deep_rate", "signal_retention", "attr_retention", "bytes_fast_mean", "bytes_fast_full_mean",
               "recognition_full", "recognition_fast", "by_bucket", "train_visits", "test_visits",
               "network_clusters", "network_per_client", "policy_version", "policy_hash", "policy_bytes",
               "replay_identity_ok", "fallback_ok", "timing_mode"]


def _load_run(folder, label):
    folder = Path(folder)
    metrics = json.loads((folder / "metrics.json").read_text())
    gates = json.loads((folder / "gates.json").read_text())
    scen_path = folder / "scenarios.json"
    scenarios = json.loads(scen_path.read_text()) if scen_path.exists() else {}
    policy_files = sorted(folder.glob("policy-*.json"))
    policy = json.loads(policy_files[-1].read_text()) if policy_files else None
    records = []
    with (folder / "records.jsonl").open() as f:
        for line in f:
            r = json.loads(line)
            records.append([round(r["latency_full"], 1), round(r["latency"], 1), r["full_score"],
                            PATHS.index(r["path"]), REASONS.index(r["reason"]) if r["reason"] in REASONS else -1])
    schema = metrics.get("schema", {})
    synthetic = schema.get("synthetic_payloads", 0) > 0
    return {
        "label": label,
        "synthetic": synthetic,
        "estimated": schema.get("timing_mode") == "elapsed",
        "payloads": schema.get("payloads", 0),
        "threshold": policy["escalation"]["threshold"] if policy else 40,
        "metrics": {k: metrics.get(k) for k in METRIC_KEYS},
        "gates": [{k: g[k] for k in ("label", "actual", "op", "value", "unit", "passed")} for g in gates],
        "scenarios": scenarios,
        "records": records,
        "policy": policy,
    }


def _import_map():
    """policy-js modules as data: URLs; relative imports rewritten to bare 'pj/<name>' specifiers."""
    imports = {}
    for p in sorted(POLICY_JS_SRC.glob("*.js")):
        src = re.sub(r'from\s+"\./([\w-]+)\.js"', r'from "pj/\1"', p.read_text())
        imports[f"pj/{p.stem}"] = "data:text/javascript;base64," + base64.b64encode(src.encode()).decode()
    return json.dumps({"imports": imports})


def build(runs, out_path):
    """runs: [(folder, label)]"""
    data = {"generatedAt": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"), "paths": PATHS,
            "reasons": REASONS, "runs": [_load_run(f, label) for f, label in runs]}
    html = TEMPLATE.read_text()
    deck = (ROOT / "demo-presentation.html").read_text()
    deck_css = re.search(r"(?s)<style[^>]*>(.*?)</style>", deck).group(1)  # the deck is the source of truth for tokens
    html = html.replace("/*__DECK_CSS__*/", deck_css)
    payload = json.dumps(data, separators=(",", ":")).replace("</", "<\\/")
    html = html.replace("<!--__IMPORTMAP__-->", f'<script type="importmap">{_import_map()}</script>')
    html = html.replace("/*__RUNS__*/null", payload)
    Path(out_path).write_text(html)
    return out_path
