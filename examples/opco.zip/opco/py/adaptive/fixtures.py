"""Synthetic payload generator so the pipeline runs before real data arrives.

Writes raw payloads in the layout config/adapter.json assumes. Values are
fake but shaped to exercise every part of the pipeline: per-browser gaps,
desktop checks that wait and return nothing, slow storage, bots, VMs, and a
small ring of devices that keep resetting wdi1.
"""

import json
import random
from pathlib import Path

from . import catalog as cat
from .hashing import fnv1a32

BROWSERS = [  # family, display name, major, weight, os choices
    ("chrome", "Chrome", 130, 0.25, ["Windows", "macOS", "Linux"]),
    ("chrome", "Chrome", 131, 0.25, ["Windows", "macOS", "Linux"]),
    ("edge", "Microsoft Edge", 130, 0.15, ["Windows"]),
    ("firefox", "Firefox", 132, 0.12, ["Windows", "macOS", "Linux"]),
    ("safari", "Safari", 18, 0.13, ["macOS"]),
    ("chrome", "Chrome", 109, 0.004, ["Windows"]),  # rare -> "unknown version" bucket
]
NAV_PLATFORM = {"Windows": "Win32", "macOS": "MacIntel", "Linux": "Linux x86_64"}
GPUS = ["ANGLE (NVIDIA GeForce RTX 3060)", "ANGLE (Intel(R) UHD Graphics 620)", "ANGLE (AMD Radeon RX 6600)",
        "Apple M1", "Apple M2", "Apple M3", "ANGLE (Intel(R) Iris(R) Xe Graphics)", "Mesa Intel(R) UHD Graphics"]
VM_GPUS = ["Google SwiftShader", "llvmpipe (LLVM 15.0.7)", "VMware SVGA 3D"]
EVENTS = [("login", 0.45), ("page_view", 0.25), ("payment", 0.15), ("account_open", 0.08),
          ("password_change", 0.04), ("payee_add", 0.03)]

CHROMIUM_ONLY = {"navigator.brands", "navigator.fullVersionList", "navigator.chPlatform", "navigator.chPlatformVersion",
                 "navigator.architecture", "navigator.bitness", "navigator.uaFullVersion", "navigator.model",
                 "navigator.deviceMemory", "navigator.batteryStatus", "webGpu.webGpuFingerprint",
                 "navigator.windowControlsOverlay", "navigator.virtualKeyboard", "window.isChrome"}
FIREFOX_ONLY = {"browser.firefoxVersion", "media.mozGetUserMedia", "div.mozCheckBrowser", "navigator.oscpu",
                "browser.buildID", "document.installTriggerType"}
SAFARI_ONLY = {"browser.applePay", "window.isSafari", "browser.privateClickMeasurement"}
LEGACY_IE = {"document.addBehaviorSupport", "document.documentMode", "navigator.appMinorVersion", "navigator.cpuClass",
             "navigator.msDoNotTrack", "screen.screenDeviceXDPI", "screen.screenDeviceYDPI", "media.styleMedia",
             "screen.screenFontSmoothingEnabled", "navigator.wow64"}
EXTENSIONS = {"browser.defaultExtensions", "browser.developerExtensions", "browser.popularExtensions",
              "browser.suspectExtensions"}
DESKTOP_DEAD = {"window.deviceMotions.accelerometer", "window.deviceMotions.deviceOrientationData",
                "window.deviceMotions.deviceOrientation"}
VOLATILE = {"browser.initTime", "date.browserLocalTimeUTC", "date.browserLocaleTimeString", "product.collectionRunTime",
            "product.randomId", "product.signature", "product.eventIP", "product.locationSearch", "browser.referrer",
            "window.consoleLogTime", "window.consoleTableTime", "screen.screenUpdateInterval",
            "browser.scrollDetection", "navigator.userActivation", "document.onMouseMove", "navigator.connection",
            "malware.websocketActivity", "product.eventName", "product.locationPathName", "wdi.lmt.lastModifiedTime"}
DEVICE_LEVEL = {"browser.canvasFingerprint", "browser.canvasString", "media.audioFingerprint", "media.audioSum",
                "webgl.webglFingerprint", "browser.fontsFingerprint", "browser.clientRectsFingerprint",
                "screen.screenString", "navigator.concurrency", "browser.mathFingerprint", "date.timezone",
                "media.enumerateDevices", "webGpu.webGpuFingerprint"}
# (min, max) ms for checks that cost real time; everything else is 0.02-1.5 ms sync.
SYNC_COST = {"browser.canvasFingerprint": (15, 40), "browser.fontsFingerprint": (90, 260),
             "browser.fontPreferences": (10, 35), "browser.preferredFonts": (20, 60), "browser.fontHeight": (5, 15),
             "browser.clientRectsFingerprint": (6, 18), "browser.mathFingerprint": (1, 3),
             "webgl.webglFingerprint": (12, 35), "webgl.webglCanvas": (8, 20), "browser.domBlockers": (20, 60),
             "navigator.navigatorObject": (3, 10), "navigator.ownPropertiesOfNavigator": (2, 8),
             "browser.fingerprints": (5, 20), "browser.privateBrowsingEvidence": (5, 25)}
ASYNC_COST = {"media.audioFingerprint": (30, 120), "media.enumerateDevices": (20, 180),
              "webGpu.webGpuFingerprint": (25, 90), "spoof.remotePorts": (12, 120),
              "malware.honeypotDetection": (75, 130), "malware.storageTamperingDetection": (75, 140),
              "window.storage.storagePersistence": (120, 820), "browser.permissions": (20, 160),
              "navigator.batteryStatus": (2, 12), "screen.screenUpdateInterval": (16, 50),
              "navigator.gpu": (5, 30), "window.storage.indexedDb": (5, 60)}


def _event(rng):
    r, acc = rng.random(), 0.0
    for name, w in EVENTS:
        acc += w
        if r < acc:
            return name
    return EVENTS[-1][0]


def _new_device(rng, i, kind="normal"):
    fam, name, major, _, oses = rng.choices(BROWSERS, weights=[b[3] for b in BROWSERS])[0]
    os_ = rng.choice(oses)
    gpu = rng.choice([g for g in GPUS if (g.startswith("Apple") == (os_ == "macOS"))] or GPUS)
    d = {"id": i, "kind": kind, "family": fam, "name": name, "major": major, "os": os_, "gpu": gpu,
         "seed": rng.getrandbits(48), "wdi1": f"w-{rng.getrandbits(40):010x}", "ext_hits": rng.random() < 0.08}
    if kind == "bot":
        d.update(fam="chrome", name="Chrome", major=131, os="Linux", gpu=rng.choice(VM_GPUS),
                 webdriver=rng.random() < 0.6, headless=rng.random() < 0.7, spoof_platform=rng.random() < 0.5)
    if kind == "ring":
        d.update(fam="chrome", name="Chrome", major=131, os="Windows", gpu=rng.choice(VM_GPUS[2:] + GPUS[:1]),
                 remote=rng.random() < 0.7, spoof_platform=rng.random() < 0.3)
    return d


def _value(path, dev, visit_rng, attr_card):
    """Synthetic value: deterministic per device for stable attributes."""
    if path in VOLATILE:
        return f"{path}:{visit_rng.getrandbits(32)}"
    card = attr_card[path]
    if card == 1:
        return "const"
    if card == 0:  # browser-level
        return f"{dev['family']}:{dev['major']}:{dev['os']}"
    return f"{(dev['seed'] ^ fnv1a32(path)) % card}"


def _available(path, dev):
    fam = dev["family"]
    if path in LEGACY_IE:
        return False
    if path in CHROMIUM_ONLY and fam not in ("chrome", "edge"):
        return False
    if path in FIREFOX_ONLY and fam != "firefox":
        return False
    if path in SAFARI_ONLY and fam != "safari":
        return False
    return True


UPGRADE_FROM, UPGRADE_TO = 131, 132  # browser drift: Chrome 131 devices auto-update during the window


def _at(dev, ts):
    """The device as it looks at time ts (Chrome 131 devices move to 132 at their own upgrade time)."""
    if dev["family"] == "chrome" and dev["major"] == UPGRADE_FROM and ts >= dev["upgrade_ts"]:
        return {**dev, "major": UPGRADE_TO}
    return dev


def _visit_payload(rng, dev, ts, pid, attrs, attr_card):
    dev = _at(dev, ts)
    vrng = random.Random(rng.getrandbits(64))
    data, timing = {}, {}
    cursor = 0.0
    for a in attrs:
        p = a.path
        val, timeout = None, False
        if p in DESKTOP_DEAD:
            dur, timeout = float(a.timeout_ms), True
        elif p == "browser.geolocation":
            timeout = vrng.random() < 0.85
            dur = float(a.timeout_ms) if timeout else vrng.uniform(5, 60)
        elif p in EXTENSIONS:
            if dev["family"] in ("firefox", "safari"):
                dur, timeout = float(a.timeout_ms), True
            else:
                dur = vrng.uniform(100, 480)
                val = ["ext-a", "ext-b"] if dev["ext_hits"] else []
        elif p.startswith("wdi.lmt."):
            failed = vrng.random() < 0.3
            dur = vrng.uniform(80, 450) if vrng.random() > 0.02 else float(a.timeout_ms)
            if failed:
                val = "ERROR"
        elif p.startswith("wdi.ec."):
            dur = vrng.uniform(5, 80) if vrng.random() > 0.03 else 250.0
        elif p in ASYNC_COST:
            lo, hi = ASYNC_COST[p]
            dur = min(vrng.uniform(lo, hi), float(a.timeout_ms))
        elif p in SYNC_COST:
            dur = vrng.uniform(*SYNC_COST[p])
        elif p.startswith("webgl."):
            dur = vrng.uniform(0.3, 2.5)
        else:
            dur = vrng.uniform(0.02, 1.5)
        is_async = p in ASYNC_COST or p in DESKTOP_DEAD or p in EXTENSIONS or p.startswith("wdi.") \
            or p in ("browser.geolocation",)
        timing[p] = {"offset": round(cursor, 3), "duration": round(dur, 3)}
        if not is_async:
            cursor += dur
        if timeout:
            val = "TIMEOUT"
        elif val is None:
            val = _value(p, dev, vrng, attr_card) if _available(p, dev) else "NOT_AVAILABLE"
        _set(data, p, val)

    _override(data, dev, vrng, ts)
    run_time = max(t["offset"] + t["duration"] for t in timing.values())
    _set(data, "product.collectionRunTime", round(run_time, 3))
    return {"payloadId": pid, "receivedAt": ts, "synthetic": True, "data": data, "collectTime": timing}


def _set(tree, dotted, value):
    parts = dotted.split(".")
    for p in parts[:-1]:
        tree = tree.setdefault(p, {})
    tree[parts[-1]] = value


def _override(data, dev, vrng, ts):
    """Realistic values for metadata and every risk-rule input."""
    chromium = dev["family"] in ("chrome", "edge")
    _set(data, "navigator.browserName", dev["name"])
    _set(data, "navigator.browserVersion", f"{dev['major']}.0.{dev['seed'] % 9000}.{dev['seed'] % 200}")
    nav_os = "Windows" if dev.get("spoof_platform") else dev["os"]
    _set(data, "navigator.navPlatform", NAV_PLATFORM[nav_os])
    _set(data, "navigator.chPlatform", dev["os"] if chromium else "NOT_AVAILABLE")
    _set(data, "webgl.webglUnmaskedRenderer", dev["gpu"])
    _set(data, "navigator.webDriverEnabled", bool(dev.get("webdriver")))
    _set(data, "navigator.automationArtifactsPresent", bool(dev.get("webdriver")) and vrng.random() < 0.5)
    _set(data, "navigator.headlessBrowserEvidence", {"detected": bool(dev.get("headless"))})
    _set(data, "navigator.webdriverPropertyDescriptor", {"tampered": dev["kind"] == "bot" and vrng.random() < 0.3})
    _set(data, "spoof.remotePorts", "[7070]" if dev.get("remote") or vrng.random() < 0.01 else "[]")  # real 9.4.0 shape
    tamper = dev["kind"] != "normal" and vrng.random() < 0.2
    _set(data, "malware.storageTamperingDetection", {"detected": tamper})
    _set(data, "malware.scriptInjectionDetection", {"detected": vrng.random() < 0.003})
    _set(data, "malware.apiIntegrity", {"tampered": dev["kind"] == "bot" and vrng.random() < 0.25})
    _set(data, "wdi.ec.wdi1", dev["wdi1"])
    _set(data, "wdi.ec.wdi1Inconsistency", vrng.random() < (0.3 if dev["kind"] == "ring" else 0.01))
    _set(data, "wdi.ec.wdi1Recreation", {"recreated": dev.get("_recreated", False)})
    _set(data, "browser.privateBrowsing", vrng.random() < 0.06)
    _set(data, "product.eventName", _event(vrng))


def generate(n=2000, seed=7, out_dir=None, features=None):
    rng = random.Random(seed)
    attrs = cat.collected(cat.build_catalog(features))
    attr_card = {}
    for a in attrs:
        r = random.Random(f"{seed}:{a.path}").random()
        if a.path in DEVICE_LEVEL:
            attr_card[a.path] = 5000
            continue
        attr_card[a.path] = 1 if r < 0.25 else 0 if r < 0.55 else random.Random(f"card:{a.path}").choice([3, 12, 60, 400, 5000])
    n_devices = max(1, int(n / 2.4))
    devices = [_new_device(rng, i, "bot" if rng.random() < 0.03 else "normal") for i in range(n_devices)]
    ring = [_new_device(rng, n_devices + i, "ring") for i in range(3)]
    t0 = 1_756_684_800_000  # 2025-09-01
    span = 60 * 24 * 3600 * 1000
    day = 24 * 3600 * 1000
    for d in devices + ring:  # upgrades roll out from day 30; most devices update within ~3 weeks
        d["upgrade_ts"] = t0 + 30 * day + int(rng.expovariate(1 / 12) * day)
    payloads = []
    for i in range(n):
        if i % 50 == 0 and ring:
            dev = rng.choice(ring)
            dev["wdi1"], dev["_recreated"] = f"w-{rng.getrandbits(40):010x}", True  # ring resets id every visit
        else:
            dev = rng.choice(devices) if rng.random() < 0.6 else devices[min(int(rng.expovariate(1 / 40)), n_devices - 1)]
            dev["_recreated"] = False
            if rng.random() < 0.04:  # cookie cleared
                dev["wdi1"], dev["_recreated"] = f"w-{rng.getrandbits(40):010x}", True
        ts = t0 + int(rng.random() * span)
        payloads.append(_visit_payload(rng, dev, ts, f"p{i:06d}", attrs, attr_card))
    if out_dir:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        with (out / "fixtures.jsonl").open("w") as f:
            for p in payloads:
                f.write(json.dumps(p, separators=(",", ":")) + "\n")
    return payloads
