"""Hashing shared with policy-js (must stay byte-for-byte identical).

FNV-1a 32-bit over UTF-8 is used for the policy content hash (corruption
detection; real signing is a server concern) and for the deterministic 5%
baseline sample.
"""

import hashlib
import json
import math

FNV_OFFSET = 0x811C9DC5
FNV_PRIME = 0x01000193


def fnv1a32(text):
    h = FNV_OFFSET
    for b in text.encode("utf-8"):
        h ^= b
        h = (h * FNV_PRIME) & 0xFFFFFFFF
    return h


def _normalise(obj):
    # JS prints 1.0 as "1"; make Python agree.
    if isinstance(obj, float):
        if not math.isfinite(obj):
            raise ValueError("non-finite number in policy")
        return int(obj) if obj.is_integer() else obj
    if isinstance(obj, dict):
        return {k: _normalise(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_normalise(v) for v in obj]
    return obj


def canonical_json(obj):
    return json.dumps(_normalise(obj), sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def policy_hash(policy):
    body = {k: v for k, v in policy.items() if k != "hash"}
    return "fnv1a32:%08x" % fnv1a32(canonical_json(body))


def in_baseline_sample(payload_id, rate):
    """Deterministic sample: same payload id -> same answer, in Python and JS."""
    return fnv1a32(payload_id) % 10000 < round(rate * 10000)


def value_hash(value):
    """64-bit signed hash of a JSON value, for equality/entropy stats only (Python-side, not shared)."""
    text = value if isinstance(value, str) else json.dumps(value, sort_keys=True, separators=(",", ":"))
    digest = hashlib.blake2b(text.encode("utf-8"), digest_size=8).digest()
    return int.from_bytes(digest, "little", signed=True)
