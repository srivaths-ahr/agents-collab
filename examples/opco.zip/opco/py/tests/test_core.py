"""Unit tests (stdlib unittest): python3 -m unittest discover -s tests -t ."""

import copy
import unittest

from adaptive.hashing import canonical_json, fnv1a32, in_baseline_sample, policy_hash
from adaptive.model import MISSING as MISSING_, OK, AttrIndex, empty_visit
from adaptive.network import stream
from adaptive.policy import Escalator, decide, validate
from adaptive.risk import rule_fires, score
from adaptive.timing import contributions, observed_latency, simulate
from adaptive.verify import verify


def make_visit(timings, **meta):
    base = dict(payload_id="x", ts=0, wdi1="", event_name="", browser_family="chrome", browser_major=131)
    base.update(meta)
    v = empty_visit(len(timings), **base)
    for s, (o, d) in enumerate(timings):
        v.status[s], v.offset[s], v.duration[s] = OK, o, d
    return v


# serial A 0-10, serial B 10-30, concurrent C 30-130, serial D 30-35
TIMELINE = [(0, 10), (10, 20), (30, 100), (30, 5)]


class TimingTests(unittest.TestCase):
    def test_keep_everything_reproduces_observed(self):
        v = make_visit(TIMELINE)
        self.assertEqual(simulate(v)[0], observed_latency(v))

    def test_skipping_serial_check_shifts_later_checks(self):
        self.assertEqual(simulate(make_visit(TIMELINE), keep={0, 2, 3})[0], 110)

    def test_skipping_concurrent_check_removes_only_its_end(self):
        self.assertEqual(simulate(make_visit(TIMELINE), keep={0, 1, 3})[0], 35)

    def test_wait_truncates_and_marks_lost(self):
        lat, ends, lost = simulate(make_visit(TIMELINE), waits={2: 50})
        self.assertEqual((lat, lost, ends[2]), (80, {2}, 80))

    def test_wait_on_serial_check_shifts_later_checks(self):
        self.assertEqual(simulate(make_visit(TIMELINE), waits={1: 5})[0], 115)

    def test_contributions_match_single_skips(self):
        v = make_visit(TIMELINE)
        full = observed_latency(v)
        for slot, c in contributions(v).items():
            keep = set(range(4)) - {slot}
            self.assertAlmostEqual(c, full - simulate(v, keep=keep)[0], places=3, msg=f"slot {slot}")


class HashTests(unittest.TestCase):
    def test_fnv_vectors_match_js(self):
        self.assertEqual(fnv1a32(""), 0x811C9DC5)
        self.assertEqual(fnv1a32("a"), 0xE40C292C)
        self.assertEqual(fnv1a32("foobar"), 0xBF9CF968)

    def test_canonical_json_matches_js_number_format(self):
        self.assertEqual(canonical_json({"b": 1.0, "a": [0.05, True, None]}), '{"a":[0.05,true,null],"b":1}')

    def test_baseline_sample_is_deterministic_and_about_five_percent(self):
        hits = sum(in_baseline_sample(f"id-{i}", 0.05) for i in range(20000))
        self.assertTrue(0.04 < hits / 20000 < 0.06)
        self.assertEqual(in_baseline_sample("abc", 0.05), in_baseline_sample("abc", 0.05))


RULES = {"threshold": 40, "version": "t", "rules": [
    {"id": "wd", "weight": 50, "when": {"op": "truthy", "attr": "nav.wd"}},
    {"id": "eq", "weight": 20, "when": {"op": "equals", "attr": "rp", "key": "status", "value": "portsFound"}},
    {"id": "rx", "weight": 30, "when": {"op": "regex", "attr": "gpu", "pattern": "swiftshader", "flags": "i"}},
    {"id": "df", "weight": 25, "conflict": True,
     "when": {"op": "differs", "attr": "plat", "other": "ch", "map": {"Win32": "Windows"}}},
]}


class RuleTests(unittest.TestCase):
    def test_ops(self):
        self.assertTrue(rule_fires(RULES["rules"][0]["when"], {"nav.wd": True}))
        self.assertFalse(rule_fires(RULES["rules"][0]["when"], {"nav.wd": 0}))
        self.assertTrue(rule_fires(RULES["rules"][1]["when"], {"rp": {"status": "portsFound"}}))
        self.assertFalse(rule_fires(RULES["rules"][1]["when"], {"rp": "portsFound"}))
        self.assertTrue(rule_fires(RULES["rules"][2]["when"], {"gpu": "Google SwiftShader"}))
        self.assertFalse(rule_fires(RULES["rules"][3]["when"], {"plat": "Win32", "ch": "Windows"}))
        self.assertTrue(rule_fires(RULES["rules"][3]["when"], {"plat": "MacIntel", "ch": "Windows"}))
        self.assertFalse(rule_fires(RULES["rules"][3]["when"], {"plat": "MacIntel"}), "needs both inputs")

    def test_equals_is_type_aware_like_js(self):
        when = {"op": "equals", "attr": "a", "value": 1}
        self.assertFalse(rule_fires(when, {"a": True}))
        self.assertTrue(rule_fires(when, {"a": 1.0}))

    def test_missing_inputs_never_fire(self):
        self.assertEqual(score(RULES, {}), (0, [], False))


def tiny_policy():
    p = {"schema": "adaptive-policy/1", "version": "t", "createdAt": "x", "sourceDataHash": "h",
         "required": ["nav.wd"],
         "guardrails": {"sensitiveEvents": ["payee_add"], "baselineRate": 0.0, "minBucketSupport": 1},
         "escalation": {"threshold": 40, "rulesVersion": "t", "rules": RULES["rules"]},
         "buckets": {"chrome:131": {"support": 9, "checks": [{"attr": "nav.wd", "tier": "required", "waitMs": 100}]}}}
    p["hash"] = policy_hash(p)
    return p


class PolicyTests(unittest.TestCase):
    ctx = {"payloadId": "p1", "eventName": "login", "browserFamily": "chrome", "browserMajor": 131}

    def test_fast_path(self):
        self.assertEqual(decide(tiny_policy(), self.ctx)["mode"], "fast")

    def test_guardrail_order(self):
        p = tiny_policy()
        self.assertEqual(decide(p, {**self.ctx, "eventName": "payee_add", "serverFlagged": True})["reason"],
                         "sensitive_journey")
        self.assertEqual(decide(p, {**self.ctx, "serverFlagged": True})["reason"], "server_flagged")
        self.assertEqual(decide(p, {**self.ctx, "browserMajor": 99})["reason"], "unknown_browser")

    def test_invalid_policies_fall_back(self):
        p = tiny_policy()
        tampered = copy.deepcopy(p)
        tampered["buckets"]["chrome:131"]["checks"][0]["waitMs"] = 5
        missing = copy.deepcopy(p)
        missing["buckets"]["chrome:131"]["checks"] = []
        missing["hash"] = policy_hash(missing)
        self.assertEqual(validate(tampered), "hash_mismatch")
        self.assertEqual(validate(missing), "required_missing:chrome:131")
        for bad in (None, {}, tampered, missing):
            self.assertEqual(decide(bad, self.ctx)["mode"], "full")

    def test_escalation_on_threshold_and_conflict(self):
        e = Escalator(tiny_policy())
        self.assertEqual(e.on_signal("gpu", "SwiftShader")["action"], "continue")
        self.assertEqual(e.on_signal("rp", {"status": "portsFound"})["action"], "escalate")
        self.assertEqual(e.on_signal("nav.wd", True)["action"], "escalated")
        c = Escalator(tiny_policy())
        c.on_signal("plat", "MacIntel")
        r = c.on_signal("ch", "Windows")
        self.assertEqual((r["action"], r["reason"]), ("escalate", "conflict"))


class NetworkTests(unittest.TestCase):
    def test_flags_apply_only_to_later_visits(self):
        index = AttrIndex(["nav.wd", "fp"])
        rules = {"threshold": 40, "rules": [RULES["rules"][0]]}
        visits = []
        for i, (wdi1, risky) in enumerate([("w1", True), ("w1", False), ("w2", False)]):
            v = make_visit([(0, 1), (0, 1)], payload_id=f"p{i}", ts=i, wdi1=wdi1)
            v.vhash[1] = 7
            v.client_id = "ClientA"
            if risky:
                v.rule_values["nav.wd"] = True
            visits.append(v)
        flagged, _, _ = stream(visits, index, rules, ["fp"])
        self.assertIsNone(flagged["p0"], "a visit is never flagged by its own data")
        self.assertEqual(flagged["p1"], "risky_device")
        self.assertIsNone(flagged["p2"])


if __name__ == "__main__":
    unittest.main()


class VerifyTests(unittest.TestCase):
    """Server-side check of a payload against the decision it claims."""

    def setUp(self):
        self.verify = verify
        self.policy = tiny_policy()
        self.index = AttrIndex(["nav.wd", "rp", "extra"])
        self.registry = {self.policy["hash"]: self.policy}
        self.ctx = {"payloadId": "p1", "eventName": "login", "browserFamily": "chrome", "browserMajor": 131}
        self.enabled = {0, 1, 2}

    def visit(self, present=(0,), values=None):
        v = make_visit([(0, 1)] * 3)
        for s in range(3):
            if s not in present:
                v.status[s] = MISSING_
        v.rule_values = values or {}
        return v

    def codes(self, visit, stamp, ctx=None):
        return {f.code for f in self.verify(visit, stamp, self.registry, self.index, ctx or self.ctx, self.enabled)}

    def test_honest_fast_payload_is_clean(self):
        stamp = {"policyHash": self.policy["hash"], "mode": "fast", "reason": "low_risk"}
        self.assertEqual(self.codes(self.visit(), stamp), set())

    def test_tampering_is_caught(self):
        fast = {"policyHash": self.policy["hash"], "mode": "fast", "reason": "low_risk"}
        self.assertIn("required_missing", self.codes(self.visit(present=()), fast))
        self.assertIn("skipped_guardrail", self.codes(self.visit(), fast, {**self.ctx, "eventName": "payee_add"}))
        self.assertIn("missed_escalation", self.codes(self.visit(values={"nav.wd": True}), fast))
        self.assertIn("unknown_policy", self.codes(self.visit(), {**fast, "policyHash": "fnv1a32:00000000"}))
        self.assertIn("unplanned_collection", self.codes(self.visit(present=(0, 2)), fast))

    def test_full_scan_must_be_complete(self):
        deep = {"policyHash": self.policy["hash"], "mode": "deep", "reason": "sensitive_journey"}
        ctx = {**self.ctx, "eventName": "payee_add"}
        self.assertEqual(self.codes(self.visit(present=(0, 1, 2)), deep, ctx), set())
        self.assertIn("incomplete_full_scan", self.codes(self.visit(present=(0,)), deep, ctx))

    def test_cached_validation_is_trusted(self):
        tampered = copy.deepcopy(self.policy)
        tampered["version"] = "other"
        self.assertEqual(decide(tampered, self.ctx)["mode"], "full")
        self.assertEqual(decide(tampered, self.ctx, None)["mode"], "fast", "None means 'already validated'")



class RealLayoutTests(unittest.TestCase):
    """Real 9.4.0 export: one file = a list of {name, data | error, time}; no offsets."""

    def ingest_one(self, entries):
        import json
        import tempfile
        from pathlib import Path
        from adaptive.ingest import ingest
        from adaptive.risk import load_rules
        from adaptive.catalog import Attribute
        catalog = [Attribute(p, p.split(".")[0], True, 2000) for p in
                   ("navigator.browserName", "navigator.browserVersion", "wdi.ec.wdi1", "product.eventName",
                    "date.browserLocalTimeUTC", "product.collectionRunTime", "browser.canvasFingerprint",
                    "browser.geolocation", "spoof.remotePorts")]
        with tempfile.TemporaryDirectory() as d:
            Path(d, "visit-1.json").write_text(json.dumps(entries))
            return ingest(d, load_rules(), catalog=catalog)

    ENTRIES = [
        {"name": "browserName", "data": "Edge", "time": 202.4},
        {"name": "browserVersion", "data": "148.0.1.2", "time": 202.4},
        {"name": "wdi1", "data": "w-1", "time": 278.4},
        {"name": "eventName", "data": "init", "time": 0},
        {"name": "browserLocalTimeUTC", "data": 1781565129865, "time": 0},
        {"name": "canvasFingerprint", "data": "abc", "time": 470.7},
        {"name": "geolocation", "error": {"message": "603"}, "time": 581.4},
        {"name": "remotePorts", "data": "[]", "time": 174.3},
        {"name": "collectionRunTime", "data": "979.700"},
    ]

    def test_list_payload_is_one_visit_with_metadata(self):
        ds = self.ingest_one(self.ENTRIES)
        v = ds.visits[0]
        self.assertEqual((len(ds.visits), v.payload_id, v.bucket, v.wdi1, v.event_name, v.ts, v.elapsed),
                         (1, "visit-1", "edge:148", "w-1", "init", 1781565129865, True))
        self.assertAlmostEqual(v.run_time_ms, 979.7)
        geo = ds.index.slot["browser.geolocation"]
        self.assertEqual(v.status[geo], 3, "603 maps to timeout")
        self.assertEqual(ds.schema["timing_mode"], "elapsed")

    def test_elapsed_estimate(self):
        v = self.ingest_one(self.ENTRIES).visits[0]
        from adaptive.timing import observed_latency, prelude
        self.assertAlmostEqual(prelude(v), 979.7 - 581.4, places=2)
        self.assertAlmostEqual(observed_latency(v), 979.7, places=2)
        idx = {s for s in range(len(v.status)) if v.status[s] != MISSING_}
        geo = self.ingest_one(self.ENTRIES).index.slot["browser.geolocation"]
        lat, _, _ = simulate(v, keep=idx - {geo})
        self.assertAlmostEqual(lat, prelude(v) + 470.7, places=2, msg="next-slowest kept check + fixed prelude")
        lat, _, lost = simulate(v, waits={geo: 100})
        self.assertAlmostEqual(lat, prelude(v) + 470.7, places=2)
        self.assertEqual(lost, {geo})

    def test_start_end_offsets_give_exact_timing(self):
        entries = [dict(e) for e in self.ENTRIES]
        timed = {"browserName": (0, 202.4), "browserVersion": (0, 202.4), "wdi1": (10, 278.4),
                 "eventName": (0, 0), "browserLocalTimeUTC": (0, 0), "canvasFingerprint": (0, 470.7),
                 "geolocation": (300, 581.4), "remotePorts": (5, 174.3)}
        for e in entries:
            if e["name"] in timed:
                start, t = timed[e["name"]]
                e.update(start=start, end=start + t, time=t)
        ds = self.ingest_one(entries)
        v = ds.visits[0]
        from adaptive.timing import observed_latency
        self.assertFalse(v.elapsed)
        self.assertEqual(ds.schema["timing_mode"], "offsets")
        self.assertAlmostEqual(observed_latency(v), 881.4, places=2)
        self.assertEqual(ds.schema["runtime_match_rate"], 0.0, "981.7 recorded vs 881.4 rebuilt is outside tolerance")

    def test_decode_compressed_variants(self):
        import base64
        import gzip
        import zlib
        from adaptive.ingest import decode_compressed
        payload = json_bytes = b'[{"name":"wdi1","data":"w-1","time":1}]'
        raw_deflate = zlib.compressobj(9, zlib.DEFLATED, -15)
        raw = raw_deflate.compress(json_bytes) + raw_deflate.flush()
        for blob in (zlib.compress(payload), gzip.compress(payload), raw):
            for enc in (base64.b64encode, base64.urlsafe_b64encode):
                text = enc(blob).decode().rstrip("=")
                self.assertEqual(decode_compressed(text + "\n"), [{"name": "wdi1", "data": "w-1", "time": 1}])
        with self.assertRaises(ValueError):
            decode_compressed("bm90IGNvbXByZXNzZWQ=")

    def test_remote_ports_rule_on_real_shape(self):
        from adaptive.risk import load_rules
        rule = next(r for r in load_rules()["rules"] if r["id"] == "environment.remoteAccess")["when"]
        self.assertFalse(rule_fires(rule, {"spoof.remotePorts": "[]"}))
        self.assertFalse(rule_fires(rule, {"spoof.remotePorts": "[ ]"}))
        self.assertTrue(rule_fires(rule, {"spoof.remotePorts": "[7070]"}))
        self.assertTrue(rule_fires(rule, {"spoof.remotePorts": '["5900"]'}))


class IngestChecksTests(unittest.TestCase):
    def test_runtime_check_tolerance(self):
        from adaptive.ingest import runtime_check
        a = make_visit(TIMELINE)  # observed 130 ms
        a.run_time_ms = 140.0  # within 20 ms
        b = make_visit(TIMELINE)
        b.run_time_ms = 400.0  # far off: offsets not relative to one start
        c = make_visit(TIMELINE)  # no collectionRunTime reported
        r = runtime_check([a, b, c])
        self.assertEqual((r["runtime_reported"], r["runtime_match_rate"]), (2, 0.5))

    def test_synthetic_marker_counted(self):
        import json
        import tempfile
        from pathlib import Path
        from adaptive.ingest import ingest
        from adaptive.risk import load_rules
        with tempfile.TemporaryDirectory() as d:
            rows = [{"payloadId": "a", "receivedAt": 1, "data": {}, "collectTime": {}},
                    {"payloadId": "b", "receivedAt": 2, "synthetic": True, "data": {}, "collectTime": {}}]
            Path(d, "x.jsonl").write_text("\n".join(json.dumps(r) for r in rows))
            ds = ingest(d, load_rules(), catalog=[])
        self.assertEqual((ds.schema["payloads"], ds.schema["synthetic_payloads"]), (2, 1))


class DemoTemplateTests(unittest.TestCase):
    def test_template_script_parses(self):
        """A syntax error in demo_template.html blanks every slide; catch it here (needs node)."""
        import re
        import shutil
        import subprocess
        from pathlib import Path
        if not shutil.which("node"):
            self.skipTest("node not installed")
        html = (Path(__file__).resolve().parents[1] / "adaptive" / "demo_template.html").read_text()
        script = re.search(r'<script type="module">(.*?)</script>', html, re.S).group(1)
        script = re.sub(r"^\s*import .*$", "", script.replace("/*__RUNS__*/null", "null"), flags=re.M)
        r = subprocess.run(["node", "-e", "new Function(require('fs').readFileSync(0, 'utf8'))"],
                           input=script, capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr[-500:])
