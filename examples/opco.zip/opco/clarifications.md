# Clarifications

Source: working sessions with the project owner (Device IN team), deck `demo-presentation.html`
Authored: 2026-10-19 from the planning and build conversation; defaults the owner has not yet
confirmed are marked *(assumed)*.

## Q1 — Which stack?

**Asked:** Python for replay/analysis plus a TypeScript policy module, Python only, or TS/Node only?
**Answer:** Python for replay, analysis and reporting, plus a **vanilla JavaScript** policy module
(ES modules + JSDoc, no TypeScript, `node:test`), matching `udi-collector-js`. Python ended up
standard-library only because pandas/uv are not installed.
**Affects:** C4, C6, C7.

## Q2 — What form should the output take?

**Asked:** Static HTML report, interactive dashboard, or notebooks?
**Answer:** Static self-contained HTML report (`out/report.html`), plus a presentation page
(`out/demo.html`) using the same CSS as `demo-presentation.html`, able to show several runs.
**Affects:** C8.

## Q3 — How is timing recorded in each payload?

**Asked:** Per-attribute duration + offset, duration only, or per category?
**Answer:** *Revised 2026-10-20 after 6 real samples.* The demo data set (collector `jscVer` 9.4.0) has
**no offsets**: each payload is a JSON list of `{name, data | error, time}` where `time` is elapsed from
that check's own launch to resolution, plus a `collectionRunTime` total. Offsets exist from 9.5.0
(`collectTime.includeOffsets`) but little such data will be ready before the demo. The POC therefore
uses an **estimated** timing mode for these payloads (`timing.py`, elapsed mode): visit time = prelude
(total − slowest check, held fixed) + slowest kept check. This tends to **understate** savings because
cheap checks keep times inflated by main-thread blocking from skipped work. Payloads with offsets keep
the exact critical-path model.
*Update 2026-10-20:* compressed exports from collector **10.0.0** (`data/raw/compressed1.txt`, Base64 of
Pako/zlib) carry **`start` and `end`** per check (`end − start = time` on every entry; latest end within
23 ms of `collectionRunTime`). These use the exact model. Keep 9.4.0 and 10.0.0 payloads in separate
folders so each run has one timing mode.
**Affects:** C1, C2, all latency numbers.

## Q4 — Can visits from the same device be linked?

**Asked:** Is there a stable device ID across the 15,000 payloads?
**Answer:** Yes, via **wdi1** (EverCookie), plus timestamps.
**Affects:** C1 (missing wdi1 count), recognition metrics.

## Q5 — Is there a client ID for the network model?

**Asked:** Do payloads carry a client/tenant ID?
**Answer:** No — all payloads are from **one client**. A synthetic split of roughly 10k ClientA / 5k
ClientB is acceptable as long as it is clearly labelled a demo. Implementation: split per wdi1 (each
identity belongs to one client) aiming for 2:1 by visits *(assumed)*, so ordinary repeat visitors do
not look cross-client.
**Affects:** C8, network slide/report section.

## Q6 — How is "risk" defined without labels?

**Asked:** Rule-based anomaly score, unsupervised model, or both?
**Answer:** **Rule-based anomaly score**, governed and versioned in `rules/risk_rules.json`, computed on
the full scan as the reference.
**Affects:** C4, C5, risk coverage gate.

## Q7 — Are there fraud labels?

**Asked:** Is there an outcome column marking fraud?
**Answer:** No. Nothing in the POC is labelled fraud; "risky" means the rule score reached the threshold.
**Affects:** C9 (wording of results).

## Q8 — What data arrives and where?

**Asked:** Format and location of the payloads?
**Answer:** Decompressed JSON for all ~15,000 payloads, with collection time for each identifier.
Location `data/raw/` as `*.json` (one payload or a list per file) or `*.jsonl` *(assumed)*.
**Affects:** C1.

## Q9 — Should one of the owner's browsers be labelled as fraud for the demo?

**Asked:** Do we categorise a browser as fraud to show a risky visit?
**Answer:** *(assumed)* No labelling. A live risky visit is produced by triggering real rules: Chrome
under automation (`navigator.webdriver`), headless Chrome, a software renderer (`--use-angle=swiftshader`),
or a remote-access tool listening. The live slide also offers clearly-marked simulations.
**Affects:** demo live slide only.

## Q10 — Is a separate demo page wanted?

**Asked:** Build `demo.html` in addition to the report?
**Answer:** Yes, with the CSS from `demo-presentation.html` for consistent colours. Built.
**Affects:** C8.

## Q11 — Which journeys always get the full scan?

**Asked:** Which event names are "sensitive journeys"?
**Answer:** *(assumed)* `password_change`, `payee_add`, `account_recovery`. Login and payment are
deliberately **not** sensitive, because the deck promises those journeys get faster. Still to confirm
with the business, and the real event-name values must be read from the payloads.
**Affects:** C5.

## Q12 — What are the gate thresholds?

**Asked:** Pass/fail targets for the demo?
**Answer:** *(assumed)* the placeholders in `config/gates.json`: fast-path p50 ≤ 800 ms; low-risk p50
reduction ≥ 40%; sensitive and flagged on full scan = 100%; risk coverage ≥ 99%; signal retention ≥ 95%;
recognition drop ≤ 2 points; rebuilt-time match ≥ 95%; fallback and identity checks pass. Still to
confirm with business and Device IN.
**Affects:** C2, C3, C5, C9.

## Q13 — What is the risk threshold?

**Asked:** Score at which a visit must leave the fast path?
**Answer:** *(assumed)* 40, to be revisited against the real score distribution. Changing it changes
which visits count as risky; record the reason.
**Affects:** C5, risk coverage.

## Q14 — Minimum visits before a browser version gets a fast path, and the baseline sample?

**Asked:** Support threshold per `family:major` bucket and random full-scan share?
**Answer:** *(assumed)* 50 visits per bucket; 5% baseline sample (deterministic by payload id).
**Affects:** C5.

## Q15 — How is the data split?

**Asked:** Random split or time-ordered?
**Answer:** *(assumed)* Time-ordered: earliest 70% builds the policy, latest 30% is replayed. Server
flags only affect visits after the one that raised them.
**Affects:** C1, C9.

## Q16 — What if real results miss the deck's "~50% faster"?

**Asked:** Tune until the target is met, or report as measured?
**Answer:** *(assumed)* Report as measured. Use the tuning-sweep slide to discuss the trade-off; never
loosen gates or retune silently.
**Affects:** C9.

## Q17 — Can real values appear in tests or pages?

**Asked:** May real payload values be committed as test fixtures or shown in published pages?
**Answer:** *(assumed)* No raw values. Tests use anonymised values in the real shape; reports show
aggregates only (the per-visit timeline shows check names and timings, not values).
**Affects:** C4, C8.

## Q18 — What do error codes 603 and 604 mean?

**Asked:** The samples carry `error.message` 600, 601, 603, 604. 600 = blocked / not available and
601 = not supported (from `Concurrency.js`). What are 603 and 604?
**Answer:** *(assumed)* 603 = timeout (seen on `geolocation`, `enumerateDevices`), 604 = error (seen on
`permissions`). Configured in `config/adapter.json` → `list.errorCodes`. Only affects whether a check
counts as "timed out" vs "unavailable"; neither counts as a useful value.
**Affects:** C1, signal-value tiers.

## Q19 — What does `wdi1Recreation` mean as a risk signal?

**Asked:** Real value is a JSON string `{"name":"everCookieRecreation","data":{"value":…,"allCandidates":[…]}}`.
Does a non-empty `allCandidates` mean the identity was recreated (risky), or routine storage repair?
**Answer:** *(assumed)* Unknown — the `identity.wdi1Recreated` rule stays marked `confirm` and does not
fire on the string shape. Confirm with the EverCookie owner before giving it weight.
**Affects:** C4.

## Q20 — Several risk-rule inputs are absent from 9.4.0 data. Keep the rules?

**Asked:** `headlessBrowserEvidence`, `automationArtifactsPresent`, `webdriverPropertyDescriptor`, the
extension probes and all `malware.*` checks never appear in the 9.4.0 samples.
**Answer:** *(assumed)* Keep them (they apply to 9.5.0+ data and to the live slide); on 9.4.0 data they
simply never fire. Risk coverage on the demo set rests on `webDriverEnabled`, software renderer,
`remotePorts`, platform mismatch, `wdi1Inconsistency` and `privateBrowsing`. Say so in the demo.
**Affects:** C4, C9.

## Q21 — Which event names occur?

**Asked:** All 6 samples have `eventName: "init"`. Do the 15,000 contain other journeys
(login, payment, payee add…)?
**Answer:** *(assumed)* Read the distribution from the full set (runbook step 4). If every visit is
`init`, the "sensitive journey" guardrail cannot be demonstrated on real data; show it on synthetic
data and in the live slide instead.
**Affects:** C5, Q11.

## Q22 — How do we back the latency claim without offsets?

**Asked:** Offsets will exist in future data but not much in time for the demo. Options:
(a) show the estimate, labelled; (b) a small calibration set with offsets (even 50–200 visits from a
few test machines and browsers) to measure how far the estimate is off; (c) a lab A/B: run the real
collector in a browser with the full `features.js` and with the fast-path override from
`policy-js/src/overlay.js`, and compare the measured `collectionRunTime` directly (no offsets needed).
**Answer:** *(assumed)* (a) now; recommend (c) for the demo headline, plus (b) if any 9.5.0 data is
available. Awaiting the owner's choice. *Update 2026-10-20:* compressed 10.0.0 exports have offsets, so
(b) is possible with whatever 10.0.0 visits exist. On the one sample, the exact model gives 1,371 → 702 ms
(49%) for an illustrative skip set, versus 2–25% from the 9.4.0 estimate.
**Affects:** C2, C9, demo slides 1, 3, 4.

## Q23 — Which collector config applies to 10.0.0 data?

**Asked:** The 10.0.0 sample collects `extendedFonts` (1,277 ms — the slowest check, and the visit's
critical path) and `webGpuInfo`, both `collect: false` in the opco `features.js` (9.5.0), plus a new
`wdi3` check the config does not know. Which `features.js` matches the demo data?
**Answer:** `extendedFonts` and `wdi3` are **disabled and not in production** (owner, 2026-10-20); a
new capture without them replaced `data/raw/compressed1.txt`. `webGpuInfo` is also
**disabled and not in production** (owner, 2026-10-20). The opco `features.js` matches the production
config for these three checks. The 49% figure from the first capture came almost entirely from `extendedFonts` and is
**withdrawn**.
**Affects:** C1, C2, C9, every latency number on 10.0.0 data.

## Q24 — Can lab captures back the latency claim?

**Asked:** The production-config 10.0.0 capture (`documentDomain` 127.0.0.1) takes 193 ms in total;
every slow check finishes within 80 ms, the visit ends on the required `remotePorts` check (115 ms),
and the illustrative skip set saves 0%. The 9.4.0 field data takes 0.7–2.5 s.
**Answer:** *(assumed)* No: a fast machine on a local page does not reproduce field latency, so lab
numbers can only show the mechanism. The latency headline must come from **field** payloads (9.4.0
estimate, or 10.0.0 field exports with offsets). A lab A/B is only meaningful with field-like
conditions: CPU throttling (Chrome DevTools / CDP `Emulation.setCPUThrottlingRate` 4–6×), a real
remote page with cold cache, network throttling, and a low-end laptop. Design note for later: required
checks bound the fast path (here `remotePorts`); a required check need not block the payload if it
can be sent in a follow-up beacon.
**Affects:** C2, C9, demo slides 1, 3, 4.

## Q25 — Is the `privateBrowsing` check reliable?

**Asked:** The 2026-10-20 capture was taken in a fresh **Incognito** window (Chrome 155), yet
`privateBrowsing` returned `false`.
**Answer:** *(assumed)* Not reliable on current Chrome; keep its rule weight low (5) and do not cite
private-browsing detection in the demo until the collector team confirms.
**Affects:** C4.

## Q26 — Should required checks be allowed to report late?

**Asked:** In both production-config lab captures the visit ends on `remotePorts` (required as a risk
input; 115 ms warm, 236 ms in a cold Incognito window). Skipping slow optional checks then saves 0%.
On the Incognito capture (346 ms): deferring `remotePorts` to a follow-up beacon → 321 ms (7%);
plus the illustrative skip set → 291 ms (16%); plus fonts fingerprinting on the full scan only →
223 ms (36%).
**Answer:** *(assumed)* Out of POC scope as an implementation, but worth raising: the fast path's floor
is set by required checks, so the policy needs a "required but non-blocking" tier to save time on fast
machines. Field visits (0.7–2.5 s) have more slack, so this matters less there.
**Affects:** C9, PLAN Phase 7.
