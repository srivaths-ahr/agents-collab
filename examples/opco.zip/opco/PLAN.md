# Risk-adaptive device collection — phase plan

Offline POC that replays 15,000 real desktop payloads to show what a risk-adaptive
collection policy would do. Deck: `demo-presentation.html`. How to run: `README.md`.

**Boundary:** capability demonstration only. No production change, no live learning,
no change to backend fraud decisions. There are no fraud labels; "risk" is a governed
rule-based score on the full scan. ClientA / ClientB are a synthetic split of one
client's traffic.

Status: ✅ done · 🔄 in progress · ⏳ waiting on real data or a decision · ⬜ not started

---

## Phase 0 — Build everything that does not need real data ✅

| Item | Where | Status |
|---|---|---|
| Attribute catalogue read live from `features.js` (309 attrs, 304 enabled on desktop) | `py/adaptive/catalog.py` | ✅ |
| Compact visit model (fixed arrays per attribute) | `py/adaptive/model.py` | ✅ |
| Config-driven payload adapter + schema coverage report | `py/adaptive/ingest.py`, `config/adapter.json` | ✅ |
| Synthetic payload generator (per-browser gaps, dead desktop checks, bots, VMs, a wdi1-reset ring) | `py/adaptive/fixtures.py` | ✅ |
| Critical-path timing model (serial vs concurrent checks, waits) | `py/adaptive/timing.py` | ✅ |
| Per-browser signal value (availability, distinctiveness, stability, cost) | `py/adaptive/value.py` | ✅ |
| Rule-based risk score, shared rule format for Python and JS | `py/adaptive/risk.py`, `rules/risk_rules.json` | ✅ |
| Policy build, validation, guardrails, escalation | `py/adaptive/policy.py`, `schemas/policy.schema.json` | ✅ |
| Network model on synthetic clients, time-ordered flags | `py/adaptive/network.py` | ✅ |
| Replay, recognition, metrics, pass/fail gates | `py/adaptive/replay.py`, `gates.py` | ✅ |
| Self-contained HTML report | `py/adaptive/report.py` → `out/report.html` | ✅ |
| Vanilla JS evaluator: decide, escalate, validate, fallback | `policy-js/src/` | ✅ |
| Tests: Python unit tests (23), JS parity with Python (503 golden cases), overlay, validation, timing (28) | `py/tests/`, `policy-js/test/` | ✅ |

## Phase 0b — More that fake payloads can prove ✅

| Item | Result on 3,000 fake payloads | Where |
|---|---|---|
| **Collector integration shim**: a decision becomes a `features.js` override (checks off, waits tuned); escalation hands back the rest of the scan | JS and Python read the same 304 enabled checks; fast decision enables exactly the planned checks | `policy-js/src/overlay.js` |
| **Server-side decision check** | 0 critical findings on 900 honest payloads; 4 kinds of tampering caught 100% | `py/adaptive/verify.py` |
| **Browser drift** (Chrome 131 → 132 auto-update from day 30) | Live policy sends 21% of visits to full scan until the retrain covers Chrome 132 | `fixtures.py`, report |
| **Rule added after release** | Old policy: 50.5% coverage of the new rule's risky visits; rebuilt: 100%, fast p50 585 → 701 ms | `scenarios.new_rule` |
| **Kill switch** (policy corrupted mid-run) | 100% of later visits fall back to full scan from that day | `scenarios.kill_switch` |
| **Tuning sweep** (15 settings) | Current setting sits before a cliff: raising the high-value bar to 0.3 drops signal kept 98.8% → 86% | `scenarios.sweep` |
| **Rolling release** (10-day windows, shadow, promote on gates) | Retrain at day 50 picks up Chrome 132; fast share 65% → 83% | `scenarios.rolling_release` |
| **Presentation page** (`out/demo.html`) | 11 slides in the deck's style; live slide runs policy-js in the presenter's browser | `py/adaptive/demo.py`, `demo_template.html` |
| **Visit timeline drill-down** | Typical fast visit 1,073 → 485 ms; escalated visit +56 ms over full scan | report |
| **Browser timing** in headless Chrome 155 | decide 0.38 µs, escalation 8 µs/visit, overlay 0.15 ms, policy load 1.2 ms | `policy-js/bench/` |
| Firefox / Safari / Edge timing | Needs Playwright (not installed) | ⏳ |

Also added: an explicit `"synthetic": true` marker on generated payloads (no more payload-count guess) and a gate checking rebuilt time against the collector's own `collectionRunTime` (10 gates now).

Fixes found on the way: Python's cached validation was re-hashing the policy every visit (run time 135 s → 28 s);
a skipped serial check was wrongly shifting a concurrent check that started at the same moment.

## Runbook — once the payloads arrive

Hand-off files for another session or agent: `context.md` (architecture), `task.md` (goal and
acceptance criteria C1–C9), `clarifications.md` (decisions; *(assumed)* = not yet confirmed).
All commands run from `opco/py` unless noted.

**0. Fit the adapter on samples** ✅ done 2026-10-20 with 6 real payloads (`data/raw/1–6.json`):
list layout, no offsets, all 287 names map to `features.js`, metadata found, timing mode `elapsed`.
Re-check quickly with:
```sh
python3 -m adaptive run-all --data ../data/raw --out ../out-sample --no-scenarios --no-golden --set minBucketSupport=1
python3 -c "import json; print(json.dumps(json.load(open('../out-sample/metrics.json'))['schema'], indent=1))"
```

**0b. Compressed 10.0.0 exports** ✅ decoder done 2026-10-20 (`compressed1.txt`: Base64 + zlib, has
`start`/`end` offsets, exact timing). Inspect any file with
`python3 -m adaptive decompress ../data/raw/compressed1.txt` → `../data/decoded/`. Before quoting
10.0.0 latency, get the matching `features.js` (Q23: `extendedFonts` is the critical path but disabled
in the opco config).

**1. Put the full set in place** — one folder per collector version (e.g. `data/raw-9.4/`,
`data/raw-10.0/`) so each run has a single timing mode; pass the folder as `--data`.
```sh
ls ../data/raw | head; ls ../data/raw | wc -l     # *.json (one payload or a list) or *.jsonl
```

**2. Quick full run (no scenarios), check ingest and timing first** — task C1, C2
```sh
python3 -m adaptive run-all --data ../data/raw --out ../out-real --no-scenarios --no-golden
python3 -c "import json; m=json.load(open('../out-real/metrics.json')); print(json.dumps(m['schema'], indent=1)); print([ (g['label'], g['passed']) for g in json.load(open('../out-real/gates.json'))])"
```
Expect `timing_mode: "elapsed"` for this set: check `elapsed_inconsistent_share` ≤ 0.01 and look at
`prelude_p50_ms` / `prelude_p95_ms` (≈250–575 ms on the samples). If a later set has offsets
(`timing_mode: "offsets"`), stop when `runtime_match_rate` < 0.95 and fix the adapter first.

**3. Confirm risk-rule value shapes** — task C4
For each rule with `"confirm": true` in `adaptive/rules/risk_rules.json`, look at real values:
```sh
python3 -c "
import itertools, collections
from adaptive.ingest import iter_raw
names = ['webDriverEnabled','webglUnmaskedRenderer','remotePorts','navPlatform','chPlatform',
         'wdi1Inconsistency','wdi1Recreation','privateBrowsing']
seen = collections.defaultdict(collections.Counter)
for raw, _ in itertools.islice(iter_raw('../data/raw'), 2000):
    for e in raw:
        if e['name'] in names: seen[e['name']][repr(e.get('data', e.get('error')))[:80]] += 1
for n in names: print(n, seen[n].most_common(6))
"
```
Already known from the samples: `remotePorts` is a string list (rule updated, still `confirm` until a
non-empty example is seen); `wdi1Recreation` semantics open (Q19); several inputs absent (Q20).
Fix each rule's `when` (or drop `confirm`), add fire / no-fire cases with anonymised values to
`RealShapeRuleTests` in `tests/test_core.py`.

**4. Apply decisions** — task C5: sensitive events (Q11), gates (Q12), threshold (Q13), support and
baseline (Q14). Read the real event names first:
```sh
python3 -c "
import collections
from adaptive.ingest import iter_raw
c = collections.Counter(next((str(e.get('data')) for e in raw if e['name'] == 'eventName'), None) for raw, _ in iter_raw('../data/raw'))
print(c.most_common(20))"
```
All 6 samples are `init`; if the full set is too, see Q21.

**5. Full run with scenarios and golden refresh, then tests** — task C3, C6, C7
```sh
python3 -m adaptive run-all --data ../data/raw --out ../out-real
python3 -m unittest discover -s tests -t .
cd ../policy-js && npm test && npm run bench:chrome && cd ../py
```

**6. Demo pages** — task C8
```sh
python3 -m adaptive fixtures --n 3000 && python3 -m adaptive run-all --data ../data/fixtures --out ../out --no-golden
python3 -m adaptive run-all --data ../data/raw --out ../out-real          # golden files end on the real policy
python3 -m adaptive demo --run ../out:Synthetic --run ../out-real:Real --out ../out-real/demo-all.html
open ../out-real/report.html ../out-real/demo-all.html
```

**7. Record results** — task C9: update Phases 1–6 below with the headline numbers from
`out-real/metrics.json` and any failing gate with its cause. Never loosen a gate without an answer in
`clarifications.md`.

## Timing evidence without offsets (decision pending — `clarifications.md` Q22, Q23)

*Update 2026-10-20:* compressed 10.0.0 exports include `start`/`end`, so 10.0.0 visits give exact
timing. With the production config (no `extendedFonts`, no `wdi3`) the local test capture takes 193 ms
and the skip set saves 0% — lab machines on a local page are too fast to show field latency (Q24).
A cold Incognito capture (same machine) takes 346 ms and ends on the required `remotePorts` check, so
the skip set again saves 0%; only deferring `remotePorts` to a follow-up beacon unlocks savings
(7% → 36%, Q26). `privateBrowsing` missed Incognito (Q25).
The latency headline needs **field** data: 10.0.0 field exports with offsets (best), or the 9.4.0
field set with the labelled estimate. Option C below only counts with throttled, field-like conditions.


The demo set (collector 9.4.0) records each check's time from its own launch, not when it started.
On the 6 samples the estimate gives only 2–25% savings: ~250–575 ms per visit is not attributable to
any check (held fixed), and cheap checks report 430–830 ms only because they waited behind canvas /
fonts / WebGL work in the same batch. Everything except latency (risk coverage, guardrails,
recognition, signal value, network, verification, live slide) is unaffected.

| Option | What it gives | Needs |
|---|---|---|
| A. Estimate only (current) | Conservative number, labelled "Estimated timing" | Nothing |
| B. Calibration set with offsets | Measures how far the estimate is off; corrects it | 50–200 visits from collector 9.5.0 with `includeOffsets` on, a few browsers |
| C. Lab A/B (recommended for the headline) | A **measured** before/after: run the real collector with the full `features.js` and with the fast-path override from `policy-js/src/overlay.js`, compare `collectionRunTime` | The full collector bundle and a browser harness (Playwright, like `udi-collector-js/live.test.mjs`); a few hours per browser |

## Phase 1 — Ingest and profile the real payloads 🔄 adapter fitted on 6 samples; waiting on the full set

Waiting on: decompressed payloads in `data/raw/` and one or two samples to fit `config/adapter.json`.

- Fit the adapter: field names for wdi1, timestamp, event name, `collectionRunTime`, per-attribute offset and duration.
- Schema coverage: payload keys not in `features.js`, enabled checks never seen.
- Check rebuilt timing against `product.collectionRunTime`; confirm the 0.8–1.5 s claim.
- Profile: browser mix, repeat visits per wdi1, error and timeout rates per check.

## Phase 2 — Signal value per browser on real data ⏳

- Re-derive tiers (required / high value / deep only / skipped) and waits per browser version.
- Review the "skipped" and "deep only" lists with the Device IN team before they become policy.

## Phase 3 — Risk score and guardrails ⏳

Waiting on decisions:
- Sensitive event names that must always get the full scan (placeholders: `password_change`, `payee_add`, `account_recovery`).
- Confirm value shapes for rules marked `confirm` in `rules/risk_rules.json`.
- Agree the risk threshold (placeholder 40) from the real score distribution.

## Phase 4 — Policy build and replay on real data ⏳

- Build from the earliest 70% by time; replay the latest 30%.
- Sanity checks: a policy that keeps every check reproduces observed time; an invalid policy falls back to full scan.

## Phase 5 — Network model demo ⏳

- Synthetic split per wdi1, aiming for ClientA 10k / ClientB 5k visits.
- Review flagged clusters for obvious false positives (shared corporate hardware, popular configs).

## Phase 6 — Metrics, gates, report ⏳

Waiting on: agreed thresholds in `config/gates.json` (placeholders today).
- Final report for the demo: latency, recognition, signal retention, risk coverage, guardrails, fallback, payload size.

## Demo plan (once real payloads are in)

What we show: the policy replayed over the real 15,000 visits. Every number is re-timed from recorded
per-check timings, not measured live; the demo says so.

| Story beat | Evidence | Visual |
|---|---|---|
| 1. Today every visit pays for the full scan | Recorded collection time per visit | Distribution of today's times, 0.8–1.5 s band highlighted |
| 2. Most visits are low risk and can go faster | Share on the fast path | One 100% bar: fast / escalated / guardrail / fallback |
| 3. How much faster | Low-risk median before vs after, per browser | Before/after bars + a visit "race": the same visit as a check-by-check timeline, full vs adaptive |
| 4. Risk still gets full scrutiny | Every visit at or above the risk threshold left the fast path | Score histogram with the threshold line; risky bars all marked "full scan" |
| 5. Guardrails and safety | Sensitive journeys, flagged devices, 5% baseline, kill switch, server check | Reason counts; kill-switch time series; tamper table |
| 6. Network effect (synthetic clients) | Clusters seen across ClientA and ClientB | Cluster table (aggregates only) |
| 7. Trade-offs are governed | Tuning sweep, rule-added scenario, rolling release | Small tables |

Live risky visit (optional): no browser is labelled fraud. A presenter's browser becomes "risky" by
triggering real rules, for example Chrome under automation (`navigator.webdriver = true`), a software
renderer (`--use-angle=swiftshader` gives a SwiftShader WebGL renderer), or a remote-access tool listening
(AnyDesk, picked up by RemotePorts). Run `decide` + escalation in that browser and show it switch to the full scan.

Presentation page ✅: `out/demo.html`, built by `run-all` (single run) or
`python3 -m adaptive demo --run ../out:Synthetic --run ../out-real:Real` (switch between runs in the page).
Same CSS tokens as `demo-presentation.html` (read from the deck at build time). Self-contained: opens from
file://, includes policy-js for the live slide. `out/report.html` stays as the evidence appendix.
Rehearsal URLs: `#s-race` jumps to a slide; `?still=1` disables animation (PDF export);
`?live=run&sim=webdriver` runs the live slide on load.

## Effort to demo-ready once real payloads arrive

Assumes the pipeline above works unchanged and only the payload layout differs from the assumption.

| Step | Your time | Mine | Main risk |
|---|---|---|---|
| Share 3–5 sample payloads (can be done now) | 15 min | fit `config/adapter.json`: 0.5 day | timing stored differently than per-attribute offset + duration |
| Phase 1: ingest 15k, check rebuilt time vs `collectionRunTime` | 0.5 day | 0.5–1 day | offsets not relative to one start; missing wdi1 or timestamps |
| Phase 2: review skip / deep-only lists with Device IN | 0.5 day (meeting) | 0.5 day | a "useless" check matters for a reason the data cannot show |
| Phase 3: confirm rule value shapes, sensitive events, threshold | 0.5 day + business decision | 0.5 day | real values for `confirm` rules differ from guesses |
| Phases 4–6: run, review numbers, tune, agree gates | 0.5–1 day | 1 day | real data noisier; numbers below the deck's "~50%" target |
| Network review (synthetic split) | 1 hour | 0.5 day | popular hardware creating false clusters |
| Demo rehearsal, wording | 0.5 day | 0.5 day | — |
| **Total** | **about 3–4 days, mostly reviews and decisions** | **about 4–5 days** | about 1–1.5 weeks elapsed |

Sending a few sample payloads before the full set removes most of the schedule risk.

## Phase 7 — Toward production (out of POC scope) ⬜

- Wire `policy-js` into the collector orchestrator (not in the `udi-collector-js` checkout).
- Policy signing (the FNV hash only detects corruption), delivery through settings, kill switch.
- Server-side verification in the ingestion path.
- Cross-client approval gate before any real network-model use.
- A "required but non-blocking" tier: required checks such as `remotePorts` report in a follow-up
  beacon so they stop setting the fast path's floor (Q26).

---

## Open decisions

| Decision | Placeholder | Owner |
|---|---|---|
| Sensitive events (always full scan) | `password_change`, `payee_add`, `account_recovery` | Business |
| Gate thresholds | `config/gates.json` | Business + Device IN |
| Risk threshold | 40 | Device IN |
| Minimum visits before a browser version gets a fast path | 50 | Device IN |
| Baseline full-scan sample | 5% | Device IN |
