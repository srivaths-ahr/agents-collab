/**
 * Hashing shared with py/adaptive/hashing.py. Must stay byte-for-byte identical.
 */

const FNV_OFFSET = 0x811c9dc5;
const FNV_PRIME = 0x01000193;
const encoder = new TextEncoder();

/**
 * FNV-1a 32-bit over the UTF-8 bytes of a string.
 *
 * @param {string} text
 * @returns {number} unsigned 32-bit hash
 */
export function fnv1a32(text) {
  let h = FNV_OFFSET;
  for (const b of encoder.encode(text)) {
    h ^= b;
    h = Math.imul(h, FNV_PRIME) >>> 0;
  }
  return h >>> 0;
}

/**
 * JSON with sorted keys and no whitespace, matching Python's
 * json.dumps(sort_keys=True, separators=(",", ":"), ensure_ascii=False).
 *
 * @param {*} value
 * @returns {string}
 */
export function canonicalJson(value) {
  if (value === null || typeof value !== "object") {
    if (typeof value === "number" && !Number.isFinite(value)) {
      throw new Error("non-finite number in policy");
    }
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return `[${value.map(canonicalJson).join(",")}]`;
  }
  const keys = Object.keys(value).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${canonicalJson(value[k])}`).join(",")}}`;
}

/**
 * Content hash of a policy, excluding its own "hash" field.
 *
 * @param {object} policy
 * @returns {string}
 */
export function policyHash(policy) {
  const { hash, ...body } = policy; // eslint-disable-line no-unused-vars
  return `fnv1a32:${fnv1a32(canonicalJson(body)).toString(16).padStart(8, "0")}`;
}

/**
 * Deterministic baseline sample: the same payload id gives the same answer in Python and JS.
 *
 * @param {string} payloadId
 * @param {number} rate - 0..1
 * @returns {boolean}
 */
export function inBaselineSample(payloadId, rate) {
  return fnv1a32(payloadId) % 10000 < Math.round(rate * 10000);
}
