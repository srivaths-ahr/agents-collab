/**
 * Turn a policy decision into a features.js config the existing collector can run.
 *
 * The collector is driven entirely by its features config, so the adaptive policy
 * needs no new collector code paths: a fast-path decision switches off the checks it
 * leaves out and shortens waits; a deep or full decision returns the config unchanged.
 * Leaf detection mirrors py/adaptive/catalog.py.
 */

import { createEscalation } from "./escalate.js";

const NON_CATEGORY_KEYS = new Set(["version", "formSelector", "payloadCallback", "logger", "timeout", "observability"]);
const EXCLUDED_CATEGORIES = new Set(["mobile"]);
const OWN_TIMEOUT_KEYS = ["timeout", "permissionTimeout", "spTimeout"];

const isObject = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const isConfigKey = (k) => k.endsWith("Config") || k.endsWith("Details");
const collectorChildren = (node) =>
  Object.entries(node).filter(([k, v]) => isObject(v) && "collect" in v && !isConfigKey(k));

/**
 * Visit every leaf check (desktop scope) with its dotted path.
 *
 * @param {object} features
 * @param {(path: string, node: object, enabled: boolean) => void} fn
 */
export function forEachCheck(features, fn) {
  const walk = (node, path, enabled) => {
    const on = enabled && node.collect !== false;
    const children = collectorChildren(node);
    if (children.length === 0) {
      fn(path.join("."), node, on);
      return;
    }
    for (const [k, child] of children) walk(child, [...path, k], on);
  };
  for (const [category, node] of Object.entries(features)) {
    if (NON_CATEGORY_KEYS.has(category) || EXCLUDED_CATEGORIES.has(category) || !isObject(node)) continue;
    walk(node, [category], true);
  }
}

/**
 * @param {object} features
 * @returns {string[]} dotted paths of every check the config would run
 */
export function enabledChecks(features) {
  const out = [];
  forEachCheck(features, (path, _node, on) => on && out.push(path));
  return out;
}

/**
 * Build the features config for one decision.
 *
 * @param {object} features - the collector's features.js export (not mutated)
 * @param {{mode: string, checks?: Array<{attr: string, waitMs: number}>}} decision
 * @returns {{features: object, waitsApplied: string[], waitsNotApplied: string[]}}
 *   waitsNotApplied lists checks whose wait lives in a shared parent config and was left alone.
 */
export function featuresForDecision(features, decision) {
  const copy = structuredClone(features);
  if (decision.mode !== "fast") {
    return { features: copy, waitsApplied: [], waitsNotApplied: [] };
  }
  const plan = new Map(decision.checks.map((c) => [c.attr, c.waitMs]));
  const waitsApplied = [];
  const waitsNotApplied = [];
  forEachCheck(copy, (path, node) => {
    if (!plan.has(path)) {
      node.collect = false;
      return;
    }
    const key = OWN_TIMEOUT_KEYS.find((k) => typeof node[k] === "number");
    if (!key) {
      waitsNotApplied.push(path);
    } else if (plan.get(path) < node[key]) {
      node[key] = plan.get(path);
      waitsApplied.push(path);
    }
  });
  return { features: copy, waitsApplied, waitsNotApplied };
}

/**
 * Features config for the rest of the scan after an escalation: every check the
 * full config runs, minus the ones already collected on this visit.
 *
 * @param {object} features
 * @param {Iterable<string>} collected
 * @returns {object}
 */
export function remainingFeatures(features, collected) {
  const done = new Set(collected);
  const copy = structuredClone(features);
  forEachCheck(copy, (path, node) => {
    if (done.has(path)) node.collect = false;
  });
  return copy;
}

/**
 * One visit, end to end, in the shape a collector orchestrator would use:
 * run `features`, report each result through `onResult`, and if it returns
 * `{action: "escalate", features}` run that config as well.
 *
 * @param {object} features
 * @param {object} policy - validated policy
 * @param {{mode: string, checks?: Array<{attr: string, waitMs: number}>}} decision
 */
export function createRun(features, policy, decision) {
  const { features: runFeatures } = featuresForDecision(features, decision);
  const watched = new Set(policy.escalation.rules.flatMap((r) => [r.when.attr, r.when.other].filter(Boolean)));
  const escalation = decision.mode === "fast" ? createEscalation(policy) : null;
  const collected = new Set();
  return {
    features: runFeatures,
    /**
     * @param {string} attr
     * @param {*} value
     * @param {boolean} ok - false for unavailable / error / timeout results
     */
    onResult(attr, value, ok = true) {
      collected.add(attr);
      if (!escalation || !ok || !watched.has(attr)) return { action: "continue" };
      const r = escalation.onSignal(attr, value);
      if (r.action !== "escalate") return { action: "continue" };
      return { action: "escalate", reason: r.reason, score: r.score, fired: r.fired,
        features: remainingFeatures(features, collected) };
    },
  };
}
