/**
 * Risk-rule evaluation. Mirrors py/adaptive/risk.py exactly.
 */

import { canonicalJson } from "./hash.js";

const isPlainObject = (v) => v !== null && typeof v === "object" && !Array.isArray(v);

/**
 * Read a dotted property path inside an attribute value.
 *
 * @param {*} value
 * @param {string} [key]
 * @returns {*} the property, or null when absent
 */
function read(value, key) {
  if (key === undefined || key === null) {
    return value;
  }
  for (const part of key.split(".")) {
    if (!isPlainObject(value) || !Object.hasOwn(value, part)) {
      return null;
    }
    value = value[part];
  }
  return value;
}

const same = (a, b) => canonicalJson(a) === canonicalJson(b);
const present = (v) => v !== null && v !== undefined;

/**
 * Does a rule's condition hold for the values collected so far?
 *
 * @param {object} when - rule condition { op, attr, key?, value?, pattern?, flags?, other?, map? }
 * @param {Record<string, *>} values - attribute -> raw value, only for checks that returned ok
 * @returns {boolean}
 */
export function ruleFires(when, values) {
  if (!Object.hasOwn(values, when.attr)) {
    return false;
  }
  let v = read(values[when.attr], when.key);
  switch (when.op) {
    case "truthy":
      return Boolean(v);
    case "equals":
      return present(v) && same(v, when.value);
    case "regex":
      return typeof v === "string" && new RegExp(when.pattern, (when.flags || "").includes("i") ? "i" : "").test(v);
    case "differs": {
      if (!Object.hasOwn(values, when.other) || !present(v)) {
        return false;
      }
      const other = values[when.other];
      if (!present(other) || other === "") {
        return false;
      }
      const map = when.map || {};
      if (typeof v === "string" && Object.hasOwn(map, v)) {
        v = map[v];
      }
      return !same(v, other);
    }
    default:
      throw new Error(`unknown rule op ${when.op}`);
  }
}
