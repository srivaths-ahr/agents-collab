/**
 * Policy validation (schemas/policy.schema.json, hand-written so there are no dependencies).
 * Mirrors policy.validate() in py/adaptive/policy.py.
 */

import { policyHash } from "./hash.js";

export const SCHEMA = "adaptive-policy/1";
export const TIERS = ["required", "high"];
const OPS = ["truthy", "equals", "regex", "differs"];

const isObject = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const isNum = (v) => typeof v === "number" && Number.isFinite(v);

/**
 * @param {*} policy
 * @returns {string|null} null when valid, otherwise a reason code
 */
export function validate(policy) {
  if (!isObject(policy)) return "not_object";
  if (policy.schema !== SCHEMA) return "schema";
  for (const key of ["version", "hash", "sourceDataHash"]) {
    if (typeof policy[key] !== "string") return `field:${key}`;
  }
  try {
    if (policyHash(policy) !== policy.hash) return "hash_mismatch";
  } catch {
    return "hash_error";
  }
  const req = policy.required;
  if (!Array.isArray(req) || !req.every((a) => typeof a === "string")) return "field:required";
  const g = policy.guardrails;
  if (!isObject(g) || !Array.isArray(g.sensitiveEvents) || !isNum(g.baselineRate) || g.baselineRate < 0 || g.baselineRate > 1) {
    return "field:guardrails";
  }
  const e = policy.escalation;
  if (!isObject(e) || !isNum(e.threshold) || !Array.isArray(e.rules)) return "field:escalation";
  for (const r of e.rules) {
    const w = isObject(r) ? r.when : null;
    if (!isObject(w) || !OPS.includes(w.op) || typeof w.attr !== "string" || !isNum(r.weight)) {
      return "field:escalation.rules";
    }
  }
  const b = policy.buckets;
  if (!isObject(b)) return "field:buckets";
  for (const [name, bucket] of Object.entries(b)) {
    const checks = isObject(bucket) ? bucket.checks : null;
    if (!Array.isArray(checks)) return `bucket:${name}`;
    for (const c of checks) {
      if (!isObject(c) || typeof c.attr !== "string" || !TIERS.includes(c.tier) || !Number.isInteger(c.waitMs) || c.waitMs <= 0) {
        return `bucket:${name}:check`;
      }
    }
    const have = new Set(checks.map((c) => c.attr));
    if (req.some((a) => !have.has(a))) return `required_missing:${name}`;
  }
  return null;
}
