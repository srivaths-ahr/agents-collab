/**
 * Mid-visit escalation: feed signals as they arrive; switch to the full scan once
 * the score reaches the threshold or a conflict rule fires.
 * Mirrors policy.Escalator in py/adaptive/policy.py.
 */

import { ruleFires } from "./rules.js";

/**
 * @param {object} policy - a validated policy
 * @returns {{onSignal: (attr: string, value: *) => {action: string, score: number, fired: string[], reason?: string}}}
 */
export function createEscalation(policy) {
  const { rules, threshold } = policy.escalation;
  const values = {};
  const fired = [];
  let score = 0;
  let escalated = false;

  return {
    onSignal(attr, value) {
      values[attr] = value;
      let conflict = false;
      for (const r of rules) {
        if (fired.includes(r.id)) continue;
        if (ruleFires(r.when, values)) {
          fired.push(r.id);
          score += r.weight;
          conflict = conflict || Boolean(r.conflict);
        }
      }
      if (!escalated && (score >= threshold || conflict)) {
        escalated = true;
        return {
          action: "escalate",
          score,
          fired: [...fired],
          reason: conflict && score < threshold ? "conflict" : "risk_threshold",
        };
      }
      return { action: escalated ? "escalated" : "continue", score, fired: [...fired] };
    },
  };
}
