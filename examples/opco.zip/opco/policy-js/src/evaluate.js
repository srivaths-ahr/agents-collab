/**
 * Choose the collection plan for one visit. Pure, synchronous, no network call.
 * Mirrors policy.decide() in py/adaptive/policy.py.
 */

import { inBaselineSample } from "./hash.js";
import { fullScan } from "./fallback.js";
import { validate } from "./validate.js";

/**
 * @typedef {object} VisitContext
 * @property {string} payloadId
 * @property {string} [eventName]
 * @property {string} browserFamily - e.g. "chrome"
 * @property {number} browserMajor - e.g. 131
 * @property {boolean} [serverFlagged] - from the network model, keyed on wdi1
 */

/**
 * @typedef {object} Decision
 * @property {"fast"|"deep"|"full"} mode - deep and full both run the complete scan
 * @property {string} reason
 * @property {string} [bucket]
 * @property {Array<{attr: string, tier: string, waitMs: number}>} [checks] - fast mode only, in run order
 */

/**
 * @param {object} policy
 * @param {VisitContext} ctx
 * @param {string|null} [validated] - cached validate(policy) result; omit to validate on every call
 * @returns {Decision}
 */
export function decide(policy, ctx, validated) {
  const reason = validated === undefined ? validate(policy) : validated;
  if (reason !== null) {
    return fullScan(reason);
  }
  const g = policy.guardrails;
  const bucket = `${ctx.browserFamily}:${ctx.browserMajor}`;
  if (g.sensitiveEvents.includes(ctx.eventName)) {
    return { mode: "deep", reason: "sensitive_journey", bucket };
  }
  if (ctx.serverFlagged) {
    return { mode: "deep", reason: "server_flagged", bucket };
  }
  if (!Object.hasOwn(policy.buckets, bucket)) {
    return { mode: "deep", reason: "unknown_browser", bucket };
  }
  if (inBaselineSample(String(ctx.payloadId ?? ""), g.baselineRate)) {
    return { mode: "deep", reason: "baseline_sample", bucket };
  }
  return { mode: "fast", reason: "low_risk", bucket, checks: policy.buckets[bucket].checks };
}

/**
 * Load a policy once: validate it, then return a decide function bound to that result.
 *
 * @param {*} policy
 * @returns {{valid: boolean, reason: string|null, decide: (ctx: VisitContext) => Decision}}
 */
export function loadPolicy(policy) {
  const reason = validate(policy);
  return { valid: reason === null, reason, decide: (ctx) => decide(policy, ctx, reason) };
}
