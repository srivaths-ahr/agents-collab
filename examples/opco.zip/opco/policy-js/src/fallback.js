/**
 * Fallback: today's fixed scan. The collector runs features.js unchanged.
 */

/**
 * @param {string} reason
 * @returns {{mode: "full", reason: string}}
 */
export function fullScan(reason) {
  return { mode: "full", reason: `policy_invalid:${reason}` };
}
