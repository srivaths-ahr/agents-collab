/**
 * Run bench/index.html in headless Chrome and print the timings. No dependencies.
 *
 *   node bench/run-chrome.mjs            (CHROME=/path/to/chrome to override)
 */

import { spawn } from "node:child_process";
import { readFile } from "node:fs/promises";
import { createServer } from "node:http";
import { createRequire } from "node:module";
import { extname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("..", import.meta.url));
const features = createRequire(import.meta.url)("../../features.js");
const CHROME = process.env.CHROME || "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const TYPES = { ".html": "text/html", ".js": "text/javascript", ".json": "application/json" };

let chrome;
const server = createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  if (req.method === "POST" && url.pathname === "/result") {
    let body = "";
    for await (const chunk of req) body += chunk;
    res.end("ok");
    const r = JSON.parse(body);
    console.log(r.userAgent);
    console.log(`policy size         ${r.policyBytes.toLocaleString()} bytes`);
    console.log(`loadPolicy          ${r.loadPolicyMs.toFixed(2)} ms (once per policy)`);
    console.log(`decide              ${r.decideUs.toFixed(2)} µs per visit`);
    console.log(`escalation          ${r.escalationPerVisitUs.toFixed(1)} µs per visit (all signals)`);
    console.log(`features overlay    ${r.featuresOverlayMs.toFixed(2)} ms per visit`);
    const ok = r.decideUs < 1000 && r.escalationPerVisitUs < 1000;
    console.log(ok ? "PASS: decide + escalation under 1 ms" : "FAIL: over the 1 ms budget");
    chrome.kill();
    server.close();
    process.exitCode = ok ? 0 : 1;
    return;
  }
  if (url.pathname === "/features.json") {
    res.setHeader("content-type", "application/json");
    res.end(JSON.stringify(features));
    return;
  }
  const path = normalize(join(root, url.pathname));
  if (!path.startsWith(root)) {
    res.statusCode = 403;
    res.end();
    return;
  }
  try {
    const data = await readFile(path);
    res.setHeader("content-type", TYPES[extname(path)] || "application/octet-stream");
    res.end(data);
  } catch {
    res.statusCode = 404;
    res.end();
  }
});

server.listen(0, "127.0.0.1", () => {
  const { port } = server.address();
  chrome = spawn(CHROME, ["--headless=new", "--disable-gpu", "--no-first-run", `--user-data-dir=${join(root, ".bench-profile")}`,
    `http://127.0.0.1:${port}/bench/index.html`], { stdio: "ignore" });
  setTimeout(() => {
    console.error("timed out waiting for the browser");
    chrome.kill();
    server.close();
    process.exitCode = 2;
  }, 60000).unref();
});
