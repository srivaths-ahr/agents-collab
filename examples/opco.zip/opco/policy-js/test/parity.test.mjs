import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

import { createEscalation, decide, validate } from "../src/index.js";

/**
 * Golden cases are exported by the Python replay (`python3 -m adaptive run-all`).
 * Every decision and every escalation step must match exactly.
 */
const fixture = (name) => JSON.parse(readFileSync(new URL(`./fixtures/${name}`, import.meta.url), "utf8"));
const policy = fixture("policy.json");
const cases = fixture("golden.json");

test("golden policy is valid in JS", () => {
  assert.equal(validate(policy), null);
});

test(`decisions match Python for ${cases.length} cases`, () => {
  for (const c of cases) {
    assert.deepStrictEqual(decide(policy, c.ctx), c.decision, `payload ${c.ctx.payloadId}`);
  }
});

test("escalation steps match Python", () => {
  let steps = 0;
  for (const c of cases) {
    const esc = createEscalation(policy);
    c.signals.forEach(([attr, value], i) => {
      assert.deepStrictEqual(esc.onSignal(attr, value), c.steps[i], `payload ${c.ctx.payloadId} step ${i}`);
      steps++;
    });
  }
  assert.ok(steps > 0, "golden set has escalation steps");
});

test("golden set covers every decision path", () => {
  const reasons = new Set(cases.map((c) => c.decision.reason));
  for (const r of ["low_risk", "sensitive_journey", "server_flagged", "unknown_browser"]) {
    assert.ok(reasons.has(r), `missing ${r}`);
  }
  assert.ok(cases.some((c) => c.steps.some((s) => s.action === "escalate")), "no escalation case");
});
