import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

import { createEscalation, decide, loadPolicy } from "../src/index.js";

/**
 * Budget from the deck: decide locally in under 1 ms. Measured here in Node;
 * browser numbers still need a Playwright run.
 */
const policy = JSON.parse(readFileSync(new URL("./fixtures/policy.json", import.meta.url), "utf8"));
const cases = JSON.parse(readFileSync(new URL("./fixtures/golden.json", import.meta.url), "utf8"));
const N = 2000;

const time = (fn) => {
  for (let i = 0; i < 200; i++) fn(i); // warm-up
  const t0 = performance.now();
  for (let i = 0; i < N; i++) fn(i);
  return (performance.now() - t0) / N;
};

test("policy load (validate + hash) is a one-off cost under 5 ms", (t) => {
  // Hashing the whole policy dominates; do it once when the policy is loaded, not per visit.
  const ms = time((i) => decide(policy, cases[i % cases.length].ctx));
  t.diagnostic(`validate+decide: ${(ms * 1000).toFixed(1)} µs/call (policy ${JSON.stringify(policy).length} bytes)`);
  assert.ok(ms < 5, `${ms} ms`);
});

test("decide with a pre-validated policy stays well under 1 ms", (t) => {
  const { decide: bound } = loadPolicy(policy);
  const ms = time((i) => bound(cases[i % cases.length].ctx));
  t.diagnostic(`decide (loaded): ${(ms * 1000).toFixed(2)} µs/call`);
  assert.ok(ms < 0.1, `${ms} ms`);
});

test("escalation over all signals of a visit stays under 1 ms", (t) => {
  const withSignals = cases.filter((c) => c.signals.length);
  const ms = time((i) => {
    const c = withSignals[i % withSignals.length];
    const esc = createEscalation(policy);
    for (const [a, v] of c.signals) esc.onSignal(a, v);
  });
  t.diagnostic(`escalation (all signals): ${(ms * 1000).toFixed(1)} µs/visit`);
  assert.ok(ms < 1, `${ms} ms`);
});
