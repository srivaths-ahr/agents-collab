import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";

import { createRun, decide, enabledChecks, featuresForDecision, remainingFeatures } from "../src/index.js";

// The real collector config (CommonJS) from the opco folder.
const features = createRequire(import.meta.url)("../../features.js");
const fixture = (name) => JSON.parse(readFileSync(new URL(`./fixtures/${name}`, import.meta.url), "utf8"));
const policy = fixture("policy.json");
const catalog = fixture("catalog.json");
const cases = fixture("golden.json");
const fast = cases.find((c) => c.decision.mode === "fast").decision;

test("JS and Python read the same enabled checks from features.js", () => {
  assert.deepStrictEqual(enabledChecks(features).sort(), catalog);
});

test("a deep or full decision leaves the config unchanged", () => {
  for (const mode of ["deep", "full"]) {
    const { features: out } = featuresForDecision(features, { mode });
    assert.deepStrictEqual(out, features);
  }
});

test("a fast decision runs exactly the planned checks", () => {
  const { features: out } = featuresForDecision(features, fast);
  const planned = new Set(fast.checks.map((c) => c.attr));
  const expected = catalog.filter((a) => planned.has(a)).sort();
  assert.deepStrictEqual(enabledChecks(out).sort(), expected);
  assert.ok(expected.length < catalog.length, "fast path should skip something");
});

test("the input config is never mutated", () => {
  const before = JSON.stringify(features);
  featuresForDecision(features, fast);
  remainingFeatures(features, ["navigator.userAgent"]);
  assert.equal(JSON.stringify(features), before);
});

test("shortened waits are written to the check's own timeout and never lengthened", () => {
  const { features: out, waitsApplied } = featuresForDecision(features, fast);
  const plan = new Map(fast.checks.map((c) => [c.attr, c.waitMs]));
  for (const path of waitsApplied) {
    const [cat, ...rest] = path.split(".");
    let node = out[cat];
    let orig = features[cat];
    for (const k of rest) {
      node = node[k];
      orig = orig[k];
    }
    const key = ["timeout", "permissionTimeout", "spTimeout"].find((k) => typeof node[k] === "number");
    assert.equal(node[key], plan.get(path));
    assert.ok(node[key] < orig[key]);
  }
});

test("mobile overrides and global settings are untouched", () => {
  const { features: out } = featuresForDecision(features, fast);
  assert.deepStrictEqual(out.mobile, features.mobile);
  assert.equal(out.timeout, features.timeout);
  assert.deepStrictEqual(out.observability, features.observability);
});

test("after escalation the remaining config is the full scan minus what was collected", () => {
  const collected = fast.checks.slice(0, 20).map((c) => c.attr);
  const rest = enabledChecks(remainingFeatures(features, collected)).sort();
  assert.deepStrictEqual(rest, catalog.filter((a) => !collected.includes(a)).sort());
});

test("createRun escalates on a risky signal and hands back the rest of the scan", () => {
  const ctx = cases.find((c) => c.decision.mode === "fast").ctx;
  const run = createRun(features, policy, decide(policy, ctx));
  assert.equal(run.onResult("navigator.userAgent", "Mozilla/5.0").action, "continue");
  assert.equal(run.onResult("navigator.webDriverEnabled", false).action, "continue");
  assert.equal(run.onResult("navigator.automationArtifactsPresent", true, false).action, "continue",
    "a failed check never escalates");
  const r = run.onResult("navigator.webDriverEnabled", true);
  assert.equal(r.action, "escalate");
  assert.ok(r.fired.includes("automation.webdriver"));
  const rest = new Set(enabledChecks(r.features));
  assert.ok(!rest.has("navigator.userAgent") && !rest.has("navigator.webDriverEnabled"));
  assert.ok(rest.has("browser.fontsFingerprint") || !catalog.includes("browser.fontsFingerprint"));
});

test("createRun on a deep decision never escalates (it is already the full scan)", () => {
  const run = createRun(features, policy, { mode: "deep", reason: "sensitive_journey" });
  assert.deepStrictEqual(run.features, features);
  assert.equal(run.onResult("navigator.webDriverEnabled", true).action, "continue");
});
