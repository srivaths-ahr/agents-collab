import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

import { decide, loadPolicy, policyHash, validate } from "../src/index.js";

const policy = JSON.parse(readFileSync(new URL("./fixtures/policy.json", import.meta.url), "utf8"));
const ctx = { payloadId: "p-test", eventName: "login", browserFamily: "chrome", browserMajor: 131 };
const clone = () => structuredClone(policy);
const rehash = (p) => ({ ...p, hash: policyHash(p) });

test("missing or non-object policy falls back to full scan", () => {
  for (const p of [undefined, null, 42, "policy", []]) {
    assert.equal(decide(p, ctx).mode, "full");
  }
});

test("tampered policy (hash mismatch) falls back to full scan", () => {
  const p = clone();
  const bucket = Object.values(p.buckets)[0];
  bucket.checks[bucket.checks.length - 1].waitMs += 1;
  assert.equal(validate(p), "hash_mismatch");
  assert.deepStrictEqual(decide(p, ctx), { mode: "full", reason: "policy_invalid:hash_mismatch" });
});

test("wrong schema version falls back to full scan", () => {
  assert.equal(validate(rehash({ ...clone(), schema: "adaptive-policy/0" })), "schema");
});

test("a bucket missing a required check is rejected even with a correct hash", () => {
  const p = clone();
  const [name, bucket] = Object.entries(p.buckets)[0];
  const req = new Set(p.required);
  bucket.checks = bucket.checks.filter((c) => c.attr !== [...req][0]);
  assert.equal(validate(rehash(p)), `required_missing:${name}`);
});

test("non-integer or zero waits are rejected", () => {
  for (const waitMs of [0, -5, 1.5, "100"]) {
    const p = clone();
    Object.values(p.buckets)[0].checks[0].waitMs = waitMs;
    assert.match(validate(rehash(p)), /^bucket:.*:check$/);
  }
});

test("guardrails run before the fast path", () => {
  assert.equal(decide(policy, { ...ctx, eventName: policy.guardrails.sensitiveEvents[0] }).reason, "sensitive_journey");
  assert.equal(decide(policy, { ...ctx, serverFlagged: true }).reason, "server_flagged");
  assert.equal(decide(policy, { ...ctx, browserFamily: "opera", browserMajor: 1 }).reason, "unknown_browser");
});

test("fast path always carries every required check", () => {
  const { decide: bound } = loadPolicy(policy);
  for (let i = 0; i < 200; i++) {
    const d = bound({ ...ctx, payloadId: `p${i}` });
    if (d.mode !== "fast") continue;
    const have = new Set(d.checks.map((c) => c.attr));
    for (const a of policy.required) assert.ok(have.has(a), `missing required ${a}`);
  }
});

test("baseline sample is about 5% and deterministic", () => {
  const { decide: bound } = loadPolicy(policy);
  let n = 0;
  for (let i = 0; i < 20000; i++) {
    const a = bound({ ...ctx, payloadId: `id-${i}` });
    assert.deepStrictEqual(a, bound({ ...ctx, payloadId: `id-${i}` }));
    n += a.reason === "baseline_sample";
  }
  assert.ok(n / 20000 > 0.04 && n / 20000 < 0.06, `baseline share ${n / 20000}`);
});
