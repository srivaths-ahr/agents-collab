import test from "node:test";
import assert from "node:assert/strict";

import { canonicalJson, fnv1a32 } from "../src/index.js";

test("fnv1a32 known vectors", () => {
  assert.equal(fnv1a32(""), 0x811c9dc5);
  assert.equal(fnv1a32("a"), 0xe40c292c);
  assert.equal(fnv1a32("foobar"), 0xbf9cf968);
});

test("fnv1a32 hashes UTF-8 bytes, not UTF-16 units", () => {
  assert.notEqual(fnv1a32("é"), fnv1a32("e"));
  assert.equal(fnv1a32("é"), fnv1a32("é"));
});

test("canonicalJson sorts keys at every level and drops whitespace", () => {
  assert.equal(canonicalJson({ b: 1, a: [{ d: 2, c: 1 }], e: "x" }), '{"a":[{"c":1,"d":2}],"b":1,"e":"x"}');
  assert.equal(canonicalJson({ r: 0.05, n: null, t: true }), '{"n":null,"r":0.05,"t":true}');
});

test("canonicalJson rejects non-finite numbers", () => {
  assert.throws(() => canonicalJson({ x: Infinity }));
});
