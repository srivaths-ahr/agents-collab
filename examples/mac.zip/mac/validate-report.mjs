/**
 * Validate one or more harness-report.jsonl files against the expectations in
 * handoff.md and print a verdict per browser/label.
 *
 *   node validate-report.mjs harness-report.jsonl [more.jsonl ...]
 *
 * Exit code 0 when every line passes, 1 otherwise. No dependencies.
 */
import fs from "node:fs";

const files = process.argv.slice(2);
if (files.length === 0) {
  console.error("usage: node validate-report.mjs <report.jsonl> [...]");
  process.exit(2);
}

const browserOf = (ua) =>
  /Firefox\//.test(ua) ? "Firefox"
  : /Edg\//.test(ua) ? "Edge"
  : /Chrome\//.test(ua) ? "Chrome"
  : /Safari\//.test(ua) ? "Safari"
  : "unknown";

let allOk = true;

for (const file of files) {
  const lines = fs.readFileSync(file, "utf8").split("\n").filter(Boolean);
  for (const line of lines) {
    let d;
    try { d = JSON.parse(line); } catch { console.log(`${file}: unparseable line`); allOk = false; continue; }
    const s = d.summary, rows = d.rows ?? [];
    if (!s || rows.length === 0) { console.log(`${file}: no summary/rows`); allOk = false; continue; }

    const browser = browserOf(s.ua);
    const problems = [];
    const notes = [];

    // Per-port tallies across runs.
    const hits = {}, fps = {}, withheld = {};
    rows.forEach((r) => r.probes.forEach((p) => {
      if (p.c === "open") {
        const bucket = s.expectedOpen.includes(p.p) ? hits : fps;
        bucket[p.p] = bucket[p.p] ?? {}; bucket[p.p][p.via] = (bucket[p.p][p.via] ?? 0) + 1;
      } else if (p.tflag) {
        withheld[p.p] = (withheld[p.p] ?? 0) + 1;
      }
    }));

    // 1. Hard rule: no false positives ever.
    if (Object.keys(fps).length) problems.push(`FALSE POSITIVES ${JSON.stringify(fps)}`);

    // 2. Every scan produced a verdict, never an error, never over budget.
    const bad = rows.filter((r) => r.reason === "budgetExceeded" || !r.status);
    if (bad.length) problems.push(`${bad.length} scans without a usable verdict`);
    const inconclusive = rows.filter((r) => r.status === "inconclusive").map((r) => r.reason);
    if (inconclusive.length) notes.push(`inconclusive scans: ${JSON.stringify(inconclusive)}`);

    // 3. Timing probe state.
    const timingStates = {};
    s.timingRan.forEach((t) => { timingStates[t] = (timingStates[t] ?? 0) + 1; });
    const busyRuns = timingStates["skipped:pageBusy"] ?? 0;
    if (!s.busy && busyRuns > rows.length / 2) notes.push(`page read as busy in ${busyRuns}/${rows.length} idle runs: machine or browser was loaded`);
    if (timingStates["skipped:coarseClock"]) notes.push(`coarseClock in ${timingStates["skipped:coarseClock"]} runs (clock ${s.timerResolutionMs} ms)`);

    // 4. Expected listeners: strong ones must be caught in every run on an idle page.
    const strong = { 7070: "AnyDesk", 6783: "Splashtop" };
    if (!s.busy) {
      s.expectedOpen.forEach((port) => {
        const n = Object.values(hits[port] ?? {}).reduce((a, b) => a + b, 0);
        const ratio = `${n}/${rows.length}`;
        if (strong[port] && n < rows.length && busyRuns === 0) {
          // AnyDesk on a 1 ms clock (Firefox/Safari) is allowed one miss.
          const tolerated = port === 7070 && s.timerResolutionMs >= 1 && n >= rows.length - 1;
          (tolerated ? notes : problems).push(`${strong[port]} ${port} caught ${ratio}`);
        } else if (!strong[port]) {
          notes.push(`best-effort port ${port} caught ${ratio}`);
        }
      });
    }

    // 5. Mode sanity: macOS/Linux hosts are rst, Windows hosts are drop.
    const modes = [...new Set(rows.map((r) => r.mode))];
    const isWin = /Windows/.test(s.ua);
    if (isWin && !modes.includes("drop")) notes.push(`Windows host but mode=${modes} (expected drop)`);
    if (!isWin && modes.includes("drop")) notes.push(`non-Windows host in drop mode: ${modes}`);

    // 6. Time.
    const scans = rows.map((r) => r.scanMs).sort((a, b) => a - b);
    const p50 = scans[scans.length >> 1], max = scans[scans.length - 1];
    if (max > 1000) problems.push(`scan exceeded the 1000 ms budget: ${max} ms`);

    const ok = problems.length === 0;
    allOk &&= ok;
    console.log(`${ok ? "PASS" : "FAIL"}  ${browser.padEnd(8)} label=${s.label || "-"} busy=${s.busy} runs=${rows.length} platform=${s.platform} clock=${Number(s.timerResolutionMs).toFixed(2)}ms`);
    console.log(`      scan p50=${p50} ms max=${max} ms  timing=${JSON.stringify(timingStates)}  mode=${modes}`);
    console.log(`      expectedOpen=${JSON.stringify(s.expectedOpen)} hits=${JSON.stringify(hits)} withheldFlags=${JSON.stringify(withheld)}`);
    problems.forEach((p) => console.log(`      PROBLEM: ${p}`));
    notes.forEach((n) => console.log(`      note: ${n}`));
  }
}

process.exit(allOk ? 0 : 1);
