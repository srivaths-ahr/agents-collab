// TEST STUB ONLY. The real CollectorUtils imports files that are not in this
// partial checkout. RemotePorts.js only needs getRandomIntInRange from it.
export default class CollectorUtils {
  static getRandomIntInRange(min = 0, max = 16) {
    if (min >= max) {
      min = 0;
      max = 16;
    }
    const array = new Uint32Array(1);
    globalThis.crypto.getRandomValues(array);
    return min + (array[0] % (max - min));
  }
}
