/*
 * Copyright (c) Experian, 2024-2025.  All rights reserved.
 */

/**
 * Represents a BrowserUtils Class.
 * @class
 */
export default class BrowserUtils {
  /**
   * Constructs a new instance of the Browser class.
   * @param {Object} configuration - The configuration object for the Browser.
   */
  constructor(configuration = {}) {
    this.configuration = configuration;
    this.isOpera = this.isOpera.bind(this);
  }

  /*
   * Functions to help with features that vary through browsers
   */
  isFunctionNative(func) {
    return /^function\s.*?\{\s*\[native code]\s*}$/.test(String(func));
  }

  /**
   * Counts the number of truthy values in an array.
   *
   * @param {Array} values - The array of values to be counted.
   * @returns {number} - The count of truthy values.
   */
  countTruthy(values) {
    return values.reduce((sum, value) => sum + (value ? 1 : 0), 0);
  }

  /**
   * Checks if the user agent corresponds to the Opera browser.
   *
   * @param {string} userAgent - The user agent string.
   * @returns {boolean} - Returns true if the user agent corresponds to Opera, otherwise returns false.
   */
  isOpera(userAgent) {
    return (
      (!!window.opr && !!opr.addons) ||
      !!window.opera ||
      userAgent.includes(" OPR/")
    );
  }

  /**
   * Checks if the current browser is Firefox.
   *
   * @returns {boolean} True if the browser is Firefox, false otherwise.
   */
  isFirefox() {
    return typeof InstallTrigger !== "undefined";
  }

  /**
   * Checks if the current browser is Chrome.
   *
   * @returns {boolean} True if the browser is Chrome, false otherwise.
   */
  isChrome() {
    let check =
      !!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime);
    if (!check && !!window.chrome && !!navigator) {
      // 2nd check as chrome.runtime isn't available at localhost or http domains
      check =
        navigator.vendor == "Google Inc." && // NOSONAR: Maximum browser still support this, so we can use this as a fallback check.
        navigator.userAgent.includes("Chrome") &&
        !navigator.userAgent.includes("SamsungBrowser"); // Skip SamsungBrowser
    }
    return check;
  }

  /**
   * Checks if the current browser is Safari.
   *
   * @returns {boolean} True if the browser is Safari, false otherwise.
   */
  isSafari() {
    return (
      /constructor/i.test(window.HTMLElement) ||
      (function (p) {
        return p.toString() === "[object SafariRemoteNotification]";
      })(
        !window["safari"] ||
          (typeof safari !== "undefined" && safari.pushNotification),
      )
    );
  }

  /**
   * Detects if the current browser is Brave.
   *
   * Brave browser often implements privacy features and anti-fingerprinting measures
   * that can interfere with console timing measurements. This detection helps the
   * devtools detection logic handle Brave's unique behavior appropriately.
   *
   * @returns {Promise<boolean>} True if the browser is identified as Brave, false otherwise
   */
  isBrave = async () => {
    if (typeof navigator !== "undefined" && navigator.brave) {
      try {
        // Brave exposes navigator.brave.isBrave() method
        return await navigator.brave.isBrave();
      } catch (error) {
        // If the method fails, fall back to user agent detection
        return /brave/i.test(navigator.userAgent);
      }
    }

    // Fallback: check user agent string for Brave
    if (typeof navigator !== "undefined") {
      return /brave/i.test(navigator.userAgent);
    }

    return false;
  };

  /**
   * Checks if the current browser is Samsung.
   *
   * @returns {boolean} True if the browser is Samsung, false otherwise.
   */
  isSamsungBrowser(userAgent) {
    return userAgent.includes("Samsung");
  }

  /**
   * Detects the Opera browser based on the user agent.
   *
   * @param {string} userAgent - The user agent string.
   * @returns {object} - An object containing the name and version of the Opera browser.
   */
  detectOpera(userAgent) {
    const match = /(Opera|OPR)\/(\d+(\.\d+)?)/.exec(userAgent);
    if (match) {
      return {
        name: "Opera",
        version: match[2],
      };
    }
    return {
      name: "Opera",
      version: 0,
    };
  }

  /**
   * Detects the Firefox browser and returns its name and version.
   *
   * @param {string} userAgent - The user agent string of the browser.
   * @returns {Object} - An object containing the name and version of the Firefox browser.
   */
  detectFirefox(userAgent) {
    const match = /Firefox\/(\d+(\.\d+)?)/.exec(userAgent);
    if (match) {
      return {
        name: "Firefox",
        version: match[1],
      };
    }
    return {
      name: "Firefox",
      version: 0,
    };
  }

  /**
   * Detects the Safari browser and returns its name and version.
   *
   * @param {string} userAgent - The user agent string of the browser.
   * @returns {Object} - An object containing the name and version of the Safari browser.
   */
  detectSafari(userAgent) {
    const match = /Version\/(\d+(\.\d+)?)/.exec(userAgent);
    if (match) {
      return {
        name: "Safari",
        version: match[1],
      };
    }
    return {
      name: "Safari",
      version: 0,
    };
  }

  /**
   * Detects the Samsung browser and returns its name and version.
   *
   * @param {string} userAgent - The user agent string of the browser.
   * @returns {object} - An object containing the name and version of the Samsung browser.
   */
  detectSamsungBrowser(userAgent) {
    const match = /SamsungBrowser\/(\d+(\.\d+)?)/.exec(userAgent);
    if (match) {
      return {
        name: "Samsung Browser",
        version: match[1],
      };
    }
    return {
      name: "Samsung Browser",
      version: 0,
    };
  }

  /**
   * Detects the version of Internet Explorer based on the user agent.
   * @param {string} userAgent - The user agent string.
   * @returns {Object} - An object containing the name and version of Internet Explorer.
   */
  detectIE(userAgent) {
    const match = /(?:MSIE |rv:)(\d+(\.\d+)?)/.exec(userAgent);
    if (match) {
      return {
        name: "Internet Explorer",
        version: match[1],
      };
    }
    return {
      name: "Internet Explorer",
      version: 0,
    };
  }

  /**
   * Detects if the browser is Edge (Legacy) based on the user agent.
   * @param {string} userAgent - The user agent string of the browser.
   * @returns {Object} - An object containing the name and version of the browser.
   */
  detectEdgeLegacy(userAgent) {
    const match = /Edge\/(\d+(\.\d+)?)/.exec(userAgent);
    if (match) {
      return {
        name: "Edge (Legacy)",
        version: match[1],
      };
    }
    return {
      name: "Edge (Legacy)",
      version: 0,
    };
  }

  /**
   * Detects the version of Edge Chromium based on the user agent.
   *
   * @param {string} userAgent - The user agent string.
   * @returns {object} - An object containing the name and version of Edge Chromium.
   */
  detectEdgeChromium(userAgent) {
    const match = /Edg\/(\d+(\.\d+)?)/.exec(userAgent);
    if (match) {
      return {
        name: "Edge",
        version: match[1],
      };
    }
    return {
      name: "Edge",
      version: 0,
    };
  }

  /**
   * Detects the Chrome browser and returns its name and version.
   *
   * @param {string} userAgent - The user agent string of the browser.
   * @returns {object} - An object containing the name and version of the Chrome browser.
   */
  detectChrome(userAgent) {
    const match = /Chrome\/(\d+(\.\d+)?)/.exec(userAgent);
    if (match) {
      return {
        name: "Chrome",
        version: match[1],
      };
    }
    return {
      name: "Chrome",
      version: 0,
    };
  }

  /**
   * Checks whether the browser is based on Trident (the Internet Explorer engine) without using user-agent.
   *
   * Warning for package users:
   * This function is out of Semantic Versioning, i.e. can change unexpectedly. Usage is at your own risk.
   */
  isTrident() {
    const w = window;
    const n = navigator;

    // The properties are checked to be in IE 10, IE 11 and not to be in other browsers in October 2020
    return (
      this.countTruthy([
        "MSCSSMatrix" in w,
        "msSetImmediate" in w,
        "msIndexedDB" in w,
        "msMaxTouchPoints" in n,
        "msPointerEnabled" in n,
        "ActiveXObject" in window,
      ]) >= 5
    );
  }

  /**
   * Checks whether the browser is based on EdgeHTML (the pre-Chromium Edge engine) without using user-agent.
   *
   * Warning for package users:
   * This function is out of Semantic Versioning, i.e. can change unexpectedly. Usage is at your own risk.
   */
  isEdgeHTML() {
    // Based on research in October 2020
    const w = window;
    const n = navigator;

    return (
      this.countTruthy([
        "msWriteProfilerMark" in w,
        "MSStream" in w,
        "msLaunchUri" in n,
        "msSaveBlob" in n,
      ]) >= 3 && !this.isTrident()
    );
  }

  /**
   * Checks whether the browser is based on Chromium without using user-agent.
   *
   * Warning for package users:
   * This function is out of Semantic Versioning, i.e. can change unexpectedly. Usage is at your own risk.
   */
  isChromium() {
    // Based on research in October 2020. Tested to detect Chromium 42-86.
    const w = window;
    const n = navigator;

    return (
      this.countTruthy([
        "webkitPersistentStorage" in n,
        "webkitTemporaryStorage" in n,
        "webkitResolveLocalFileSystemURL" in w,
        "BatteryManager" in w,
        "webkitMediaStream" in w,
        "webkitSpeechGrammar" in w,
      ]) >= 5
    );
  }

  /**
   * Checks whether the browser is based on mobile or desktop Safari without using user-agent.
   * All iOS browsers use WebKit (the Safari engine).
   *
   * Warning for package users:
   * This function is out of Semantic Versioning, i.e. can change unexpectedly. Usage is at your own risk.
   */
  isWebKit() {
    // Based on research in September 2020
    const w = window;
    const n = navigator;

    return (
      this.countTruthy([
        "ApplePayError" in w,
        "CSSPrimitiveValue" in w,
        "Counter" in w,
        "getStorageUpdates" in n,
        "WebKitMediaKeys" in w,
      ]) >= 4
    );
  }

  /**
   * Checks whether this WebKit browser is a desktop browser.
   * It doesn't check that the browser is based on WebKit, there is a separate function for this.
   *
   * Warning for package users:
   * This function is out of Semantic Versioning, i.e. can change unexpectedly. Usage is at your own risk.
   */
  isDesktopWebKit() {
    // Checked in Safari and DuckDuckGo

    const w = window;
    const { HTMLElement, Document } = w;

    return (
      this.countTruthy([
        "safari" in w, // Always false in Karma and BrowserStack Automate
        !("ongestureend" in w),
        !("TouchEvent" in w),
        !("orientation" in w),
        HTMLElement && !("autocapitalize" in HTMLElement.prototype),
        Document && "pointerLockElement" in Document.prototype,
      ]) >= 4
    );
  }

  /**
   * Checks whether the browser is based on Gecko (Firefox engine) without using user-agent.
   *
   * Warning for package users:
   * This function is out of Semantic Versioning, i.e. can change unexpectedly. Usage is at your own risk.
   */
  isGecko() {
    const w = window;
    // Based on research in September 2020
    return (
      this.countTruthy([
        "buildID" in navigator,
        "MozAppearance" in (document.documentElement?.style ?? {}),
        "onmozfullscreenchange" in w,
        "mozInnerScreenX" in w,
        "CSSMozDocumentRule" in w,
        "CanvasCaptureMediaStream" in w,
      ]) >= 4
    );
  }

  /**
   * Checks whether the browser is based on Chromium version ≥86 without using user-agent.
   * It doesn't check that the browser is based on Chromium, there is a separate function for this.
   */
  isChromium86OrNewer() {
    // Checked in Chrome 85 vs Chrome 86 both on desktop and Android
    const w = window;

    return (
      this.countTruthy([
        !("MediaSettingsRange" in w),
        "RTCEncodedAudioFrame" in w,
        typeof w.Intl === "object",
        w.Reflect === Reflect,
      ]) >= 3
    );
  }

  /**
   * Checks whether the browser is based on WebKit version ≥606 (Safari ≥12) without using user-agent.
   * It doesn't check that the browser is based on WebKit, there is a separate function for this.
   *
   * @see https://en.wikipedia.org/wiki/Safari_version_history#Release_history Safari-WebKit versions map
   */
  isWebKit606OrNewer() {
    // Checked in Safari 9–17
    const w = window;

    return (
      this.countTruthy([
        "DOMRectList" in w,
        "RTCPeerConnectionIceEvent" in w,
        "SVGGeometryElement" in w,
        "ontransitioncancel" in w,
      ]) >= 3
    );
  }

  /**
   * Checks whether the device runs on Android without using user-agent.
   *
   * Warning for package users:
   * This function is out of Semantic Versioning, i.e. can change unexpectedly. Usage is at your own risk.
   */
  isAndroid() {
    const isItChromium = this.isChromium();
    const isItGecko = this.isGecko();
    const w = window;
    const n = navigator;
    const c = "connection";

    // Chrome removes all words "Android" from `navigator` when desktop version is requested
    // Firefox keeps "Android" in `navigator.appVersion` when desktop version is requested
    if (isItChromium) {
      return (
        this.countTruthy([
          !("SharedWorker" in w),
          // `typechange` is deprecated, but it's still present on Android (tested on Chrome Mobile 117)
          // Removal proposal https://bugs.chromium.org/p/chromium/issues/detail?id=699892
          // Note: this expression returns true on ChromeOS, so additional detectors are required to avoid false-positives
          n[c] && "ontypechange" in n[c],
          !("sinkId" in new window.Audio()),
        ]) >= 2
      );
    } else if (isItGecko) {
      return (
        this.countTruthy([
          "onorientationchange" in w.screen,
          "orientation" in w.screen,
          /android/i.test(navigator.userAgent),
        ]) >= 2
      );
    } else {
      // Only 2 browser engines are presented on Android.
      // Actually, there is also Android 4.1 browser, but it's not worth detecting it at the moment.
      return false;
    }
  }

  /**
   * Checks whether the browser is based on WebKit version ≥616 (Safari ≥17) without using user-agent.
   * It doesn't check that the browser is based on WebKit, there is a separate function for this.
   *
   * @see https://developer.apple.com/documentation/safari-release-notes/safari-17-release-notes Safari 17 release notes
   * @see https://tauri.app/v1/references/webview-versions/#webkit-versions-in-safari Safari-WebKit versions map
   */
  isWebKit616OrNewer() {
    const w = window;
    const n = navigator;
    const { CSS, HTMLButtonElement } = w;

    return (
      this.countTruthy([
        !("getStorageUpdates" in n),
        HTMLButtonElement && "popover" in HTMLButtonElement.prototype,
        "CSSCounterStyleRule" in w,
        CSS.supports("font-size-adjust: ex-height 0.5"),
        CSS.supports("text-transform: full-width"),
      ]) >= 4
    );
  }

  /**
   * Checks whether this WebKit browser is Safari.
   * It doesn't check that the browser is based on WebKit, there is a separate function for this.
   *
   * Warning! The function works properly only for Safari version 15 and newer.
   */
  isSafariWebKit() {
    // Checked in Safari, Chrome, Firefox, Yandex, UC Browser, Opera, Edge and DuckDuckGo.
    // iOS Safari and Chrome were checked on iOS 11-17. DuckDuckGo was checked on iOS 17 and macOS 14.
    // Desktop Safari versions 12-17 were checked.
    // The other browsers were checked on iOS 17; there was no chance to check them on the other OS versions.

    const w = window;

    if (!this.isFunctionNative(w.print)) {
      return false; // Chrome, Firefox, Yandex, DuckDuckGo macOS, Edge
    }

    return (
      this.countTruthy([
        // Incorrect in Safari <= 14 (iOS and macOS)
        String(w.browser) === "[object WebPageNamespace]",
        // Incorrect in desktop Safari and iOS Safari <= 15
        "MicrodataExtractor" in w,
      ]) >= 1
    );
  }

  /**
   * Warning for package users:
   * This function is out of Semantic Versioning, i.e. can change unexpectedly. Usage is at your own risk.
   */
  getFullscreenElement() {
    const d = document;
    return (
      d.fullscreenElement ||
      d.msFullscreenElement ||
      d.mozFullScreenElement ||
      d.webkitFullscreenElement ||
      null
    );
  }

  exitFullscreen() {
    const d = document;
    // `call` is required because the function throws an error without a proper "this" context
    return (
      d.exitFullscreen ||
      d.msExitFullscreen ||
      d.mozCancelFullScreen ||
      d.webkitExitFullscreen
    ).call(d);
  }
}