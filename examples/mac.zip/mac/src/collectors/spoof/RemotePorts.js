import { Constants } from "../Constants.js";
import CollectorUtils from "../../utils/CollectorUtils.js";
import BrowserUtils from "../../utils/BrowserUtils.js";

/**
 * Scan-level outcome emitted alongside the port list.
 *
 * An empty port list on its own is ambiguous: a genuinely clean host, a probe
 * blocked by browser policy and a probe whose every request timed out all
 * produced the same value. Consumers must be able to tell "scanned, nothing
 * listening" from "we could not measure", so the outcome is explicit.
 */
export const REMOTE_PORTS_STATUS = Object.freeze({
  /** At least one port classified as listening. */
  PORTS_FOUND: "portsFound",
  /** The probe ran and produced usable measurements; nothing was listening. */
  SCANNED_CLEAN: "scannedClean",
  /** The probe did not produce a trustworthy verdict — do not read as clean. */
  INCONCLUSIVE: "inconclusive",
});

/** Why a scan came back inconclusive. */
export const REMOTE_PORTS_REASON = Object.freeze({
  /** Some ports fell silent but the baseline could not confirm what silence means here. */
  PORTS_FILTERED: "portsFiltered",
  /** No port produced a usable timing sample. */
  NO_SAMPLES: "noSamples",
  /** Control ports fell silent or disagreed: the environment was measured, not the host. */
  PROBE_SATURATED: "probeSaturated",
  /**
   * A majority of the control ports completed an HTTP exchange. Something is
   * answering for ports with nothing bound on them — an interposing proxy, a
   * block page, an injected service worker — so a completed exchange stops
   * being evidence of a listener anywhere in this scan.
   *
   * Kept separate from PROBE_SATURATED because it is the opposite failure:
   * everything answers rather than nothing does, and only this one invalidates
   * the non-timing proof as well as the timings.
   */
  CONTROLS_RESPONDED: "controlsResponded",
  /**
   * A majority of the *target* ports completed an HTTP exchange, so something is
   * answering across the whole map whatever the controls said.
   *
   * The control gate needs a majority of 5 randomly chosen ports to be
   * intercepted. An interceptor that answers only some of them slips it, and
   * then every target reading `open` on the proof path looks like a host
   * running every remote-access tool at once. Nineteen ports all answering is
   * that signature on its own.
   */
  TARGETS_SATURATED: "targetsSaturated",
  /**
   * The probe never reached the network. A tenant CSP `connect-src` rule, a
   * denied Local Network Access prompt or a blocking extension rejects every
   * fetch before a packet leaves, far faster than a real TCP RST.
   *
   * The opposite end of PROBE_SATURATED, and the more dangerous one: a slow
   * environment at least looks wrong, whereas a blocked one looks like a fast,
   * tight, healthy baseline on which every port reads closed. Without this the
   * scan reports a clean sheet it never measured.
   */
  PROBE_BLOCKED: "probeBlocked",
  /**
   * Not enough control data to calibrate against. Covers a control set that is
   * empty, one that produced no requests at all, and one where too few controls
   * yielded samples. Distinct from PROBE_SATURATED, which means the controls
   * did run and told us the environment was being measured rather than the
   * host. Field data is segmented on these codes, so a scan that never
   * calibrated must not be filed under a code that says it did.
   */
  CONTROLS_UNUSABLE: "controlsUnusable",
  /** Closed-port timings were so noisy that no threshold separates open from closed. */
  BASELINE_TOO_NOISY: "baselineTooNoisy",
  /**
   * The scan did not finish inside its wall-clock budget and was abandoned.
   *
   * Every other ceiling in this collector bounds a single request. None of them
   * bounds the scan, so an environment that makes requests hang rather than fail
   * could hold the whole collection open indefinitely — and this probe runs on a
   * page-load budget of roughly a second, most of which it can already consume.
   */
  BUDGET_EXCEEDED: "budgetExceeded",
});

/**
 * Per-port classification.
 *
 * `closed` and `filteredOrOpen` are the nmap closed-versus-filtered
 * distinction. A closed port answers with a TCP RST in single-digit
 * milliseconds. A port that never answers either dropped the packet or
 * accepted the TCP connection and did not speak HTTP — which is exactly what
 * AnyDesk, TeamViewer, RustDesk and RDP do, none of them being HTTP servers.
 * Collapsing that case into `closed` turns the most common open-RAT-port
 * signature into a confident negative.
 */
export const PORT_CLASSIFICATION = Object.freeze({
  OPEN: "open",
  CLOSED: "closed",
  FILTERED_OR_OPEN: "filteredOrOpen",
  INCONCLUSIVE: "inconclusive",
});

/**
 * How this host answers a port with nothing bound on it.
 *
 * The technique's premise is that a closed port is *measurably* fast: the stack
 * returns a TCP RST, so "slower than a closed port" means open. That premise
 * holds on macOS and on an unfiltered Linux host. It is false on a Windows
 * endpoint whose security stack drops SYNs to unbound ports instead of
 * resetting them: there a closed port never answers at all, so there is no
 * baseline to be slower than, and the silence that means "closed" on one host
 * means "possibly open" on the other.
 *
 * Measured on the 2026-09-01 RAT batch (240 captures): all 132 Windows captures
 * produced zero samples across all 660 control-port rows, while ports with a
 * listener behind them answered in ~26 ms. macOS produced timings on all 15984
 * requests. The split is by host, not by browser — Chrome, Edge, Opera and
 * Brave behave identically on the same machine, and `curl` reproduces it
 * outside the browser entirely.
 *
 * So the control ports have two jobs, and the first matters more: establish
 * which of these worlds we are in, and only then supply a number.
 */
export const BASELINE_MODE = Object.freeze({
  /** Closed ports answer fast. Open ports are the slow or silent ones. */
  RST: "rst",
  /**
   * Closed ports never answer. Open ports are the only ones that do, so the
   * verdict inverts and needs no timing threshold at all.
   */
  DROP: "drop",
});

/**
 * Reasons that void a completed HTTP exchange as proof of a listener.
 *
 * Every other calibration failure is a timing failure, and a completed exchange
 * owes nothing to timing, so it still stands. These two are different in kind:
 * both mean something is answering for ports regardless of what is bound on
 * them, which is the one premise the proof depends on.
 */
const PROOF_VOIDING_REASONS = new Set([
  REMOTE_PORTS_REASON.CONTROLS_RESPONDED,
  REMOTE_PORTS_REASON.TARGETS_SATURATED,
]);

export default class RemotePorts {
  constructor(configuration = {}) {
    this._promise = null;
    this.configuration = configuration;

    // Engine detection. The throttling this guards against is a property of
    // WebKit, not of Safari: every browser on iOS is WebKit, so Chrome, Brave
    // and Edge there throttle exactly as Safari does. The legacy isSafari()
    // check returns false for all of them, which left iOS skipping the guard
    // entirely — consistent with 0 of 4 iOS active sessions detected while the
    // iOS samples carried the saturated all-controls-silent reading.
    //
    // isWebKit() is the engine-level predicate and is what the guard needs.
    // isSafariWebKit() only distinguishes Safari from other WebKit browsers, so
    // on its own it would still exclude iOS Chrome; it is recorded in
    // diagnostics so that iOS-non-Safari coverage can be verified in the field.
    //
    // Caveat to re-verify periodically: BrowserUtils.isWebKit() requires 4 of 5
    // WebKit-only APIs identified in 2020 research, one of which
    // (navigator.getStorageUpdates) is being retired. As those APIs disappear
    // the count drifts toward the threshold, and if it falls below it the guard
    // switches itself off on exactly the platform it exists to protect. The
    // `webkit` diagnostic below is what makes that visible in the field.
    const detect = (probe) => {
      try {
        return probe();
      } catch {
        // Engine detection must never break collection.
        return false;
      }
    };
    const browserUtils = new BrowserUtils();
    this.isSafariWebKit = detect(() => browserUtils.isSafariWebKit());
    this.isWebKit =
      detect(() => browserUtils.isWebKit()) ||
      this.isSafariWebKit ||
      detect(() => browserUtils.isSafari());

    // Timeout per request in milliseconds.
    //
    // 100, down from 150. This ceiling is only ever paid by a silent port, and
    // on a DROP host (Windows) every unbound port is silent, so it is the floor
    // of every Windows scan. The slowest genuine answer measured on Windows was
    // ~26 ms and the closed-baseline ceiling below is 60 ms; 100 clears both.
    this.timeout = 100;

    // Batch size for early termination strategy
    this.batchSize = 3;

    // Requested budget per port. Sampling stops early when a port answers fast
    // and tight, so this is a ceiling rather than a fixed cost.
    //
    // Cost model: ports are scanned concurrently and only the batches within a
    // port are sequential, so worst-case wall clock is
    // maxBatches * timeout — independent of how many ports are probed. Adding
    // ports raises request volume, not scan duration.
    this.requestsPerPort = 10;

    // Requests are issued a whole batch at a time, so the real ceiling is the
    // budget rounded up to a batch boundary: 10 requested over batches of 3
    // sends 12. Diagnostics report this figure, not the requested one, because
    // a per-port timeout count has to be read against the number of requests
    // that were actually issued.
    this.maxBatches = Math.ceil(this.requestsPerPort / this.batchSize);
    this.maxRequestsPerPort = this.maxBatches * this.batchSize;

    // Minimum samples needed before sampling can stop early
    this.minSamplesForDecision = 3;

    // Batches that must be collected before sampling stops early.
    //
    // One, down from two. Phase 1 verdicts are comparisons of KIND (answered,
    // silent, completed HTTP), so once a batch has answered, more samples of
    // the same answer cannot change the verdict. The second batch cost one
    // extra loopback round trip on every port of every scan and bought nothing.
    this.earlyStopMinBatches = 1;

    // Batches of consecutive all-timeout responses required before treating a
    // port as silent.
    //
    // One, down from two. The stall the second batch guarded against would hit
    // the control ports in the same window, and silence only reads OPEN when
    // the controls answered in that window, so the controls already police it.
    // Halves the cost of every silent port and of every Windows scan.
    // FIELD-VALIDATE: watch the RST-mode `open` rate via `via: "silent"`.
    this.filteredOrOpenMinBatches = 1;

    // Fraction of a port's requests that must time out for the silence to count
    // as evidence rather than noise.
    this.majorityTimeoutRatio = 0.5;

    // Emit the measurements the classification was derived from. On by default:
    // without them a false positive or a miss can only be investigated by
    // inferring probe behaviour statistically across stored payloads and reading
    // the collector source, which is how the 29.87% detection rate had to be
    // diagnosed in the first place. Set `diagnostics: false` to opt out.
    this.emitDiagnostics = configuration.diagnostics !== false;

    // Control-port calibration.
    //
    // Absolute timing thresholds cannot work here. Loopback latency varies by an
    // order of magnitude between machines and with load, so a fixed 100 ms
    // boundary made the verdict track machine slowness rather than port state:
    // detected samples had median collectionRunTime 1620 ms against 926 ms for
    // the misses, and 9 of 16 repeat-capture groups contradicted themselves on
    // an unchanged host.
    //
    // Every scan therefore probes a few random high ports alongside the RAT
    // ports. Nothing is bound on them with near-certainty, so they measure what
    // "closed" looks like on this hardware, under this load, right now. They are
    // randomised per scan so a host that happens to have one bound does not
    // permanently invalidate its own scans.
    //
    // Five rather than three: the interceptor gate is a majority of the control
    // set, and at three controls a partial interceptor that answers one of them
    // passes. Controls are scanned concurrently with the targets, so the extra
    // two cost request volume, not wall clock.
    this.controlPortCount = 5;

    // 61000-65535, not the whole 49152-65535 dynamic range.
    //
    // A control is only useful while nothing is bound on it, and the bottom of
    // the dynamic range is the part most likely to be occupied. Windows
    // allocates dynamic RPC upward from 49152, so its endpoints cluster at
    // 49152-49157, and the Linux default ephemeral pool
    // (net.ipv4.ip_local_port_range) is 32768-60999. Starting at 61000 clears
    // both.
    //
    // Avoiding the overlap is the only defence available here. An RPC endpoint
    // speaks DCE/RPC, not HTTP, so the fetch fails exactly as it would against a
    // closed port: the minority-answering rule below never sees it, and its
    // timings join the baseline unnoticed.
    //
    // 4536 ports is still far wider than controlPortCount, so `pickControlPorts`
    // fills its set in the first few draws.
    this.controlPortRangeMin = 61000;
    this.controlPortRangeMax = 65535;

    // A port is open when its average exceeds baseline + k sigma, with a floor
    // so a suspiciously tight baseline cannot make the threshold hair-trigger.
    this.baselineSigmaMultiplier = 4;
    this.baselineMinMarginMs = 15;

    // Calibration must clear these before any timing verdict is trusted.
    this.minControlSamples = 4;
    this.maxControlTimeoutRatio = 0.34;

    // Control ports must agree with each other within this factor (plus the
    // margin floor). One control far slower than its peers means something is
    // bound on a port that should be dead, or the environment is unstable.
    this.maxControlAgreementFactor = 3;

    // Ceiling on what "closed" can plausibly cost. A baseline above this means
    // every request is being delayed on the way out, and a uniform delay hides
    // an open port just as effectively as it fakes one. Note this bounds the
    // *closed* case — unlike the retired absolute open-port threshold, which
    // bounded the interesting case.
    //
    // Raised from 40, but only to 60, and the restraint is the point.
    //
    // 40 was too tight for ordinary hardware: macOS laptops in the 2026-09-01
    // batch calibrated at up to 36.2 ms, inside the old ceiling by under 4 ms.
    // That alone justifies headroom.
    //
    // It is NOT raised to cover the ~184 ms baselines the same batch measured on
    // containers and VMs, tempting as that is — a ceiling high enough to admit
    // those also admits a uniform throttle, and a uniform delay hides an open
    // port exactly as well as it fakes one. Tried at 250 and it turned both the
    // "uniform ~120 ms block" and the "loaded machine" cases into clean sheets:
    // precisely the false negative this bound exists to prevent.
    //
    // The container number is treated as a symptom instead. Most of that 184 ms
    // was the probe's own doing — 24 ports swept concurrently with the controls,
    // so the baseline measured event-loop queueing as much as loopback — and
    // calibration now runs as its own pass first. Whether that brings a
    // container under 60 ms is UNVERIFIED and is the single thing the next field
    // run has to answer. If it does not, re-cut this from the observed
    // `controls[].avg` distribution rather than raising it far enough to make
    // the failure go away.
    this.maxPlausibleBaselineMs = 60;

    // Fraction of a host's probed ports that may read open before the whole map
    // is treated as a failed measurement rather than a very compromised host.
    // Ten ports covering four products cannot all be listening at once.
    this.maxOpenTargetRatio = 0.6;

    // How scattered closed-port timings may be, as a fraction of the baseline,
    // before no threshold built from them means anything. See the check itself
    // for why this is relative to the baseline and not to the abort ceiling.
    this.maxBaselineNoiseRatio = 0.8;

    // Fraction of a host's probed ports that may answer in DROP mode before the
    // DROP reading is withdrawn.
    //
    // DROP mode makes a strong claim — that answering implies listening — so it
    // has to be falsifiable. The claim only holds if unbound ports really are
    // silent here, and a host where most ports answer is contradicting exactly
    // that. This is what makes a cheap calibration ceiling safe: a merely-slow
    // host misread as DROP answers broadly and is caught, rather than reporting
    // its whole port map as listening.
    //
    // Measured Windows shape for scale: 0 of 5 controls and 1 of 19 targets
    // answered, on every one of six captures.
    this.maxDropAnswerRatio = 0.34;

    // Hard wall-clock ceiling for the whole scan.
    //
    // Sized from measurement, not guessed: the worst observed real path is a
    // DROP host at roughly 200 ms calibration plus 300 ms of target sweep, and
    // the slowest container capture ran 1130 ms under the previous settings. 1500
    // ms leaves headroom for a slow machine while capping the damage an
    // environment where requests never settle can do — which is the case the
    // per-request ceilings cannot help with, since they assume the request
    // eventually resolves or aborts.
    //
    // 1000, down from 1500, after the per-request ceiling fell to 100 ms and
    // the silent-port cost halved: the worst real path is now ~100 ms of sweep
    // plus ~250 ms of timing probe on a busy page.
    this.scanBudgetMs = 1000;

    // ---- Phase 2: sequential timing probe ----
    //
    // On an RST host a listener that accepts the TCP connection and closes it
    // without speaking — AnyDesk, TeamViewer and VNC all do this on macOS —
    // answers exactly like a refused port, so phase 1 reads it as CLOSED. The
    // difference is sub-millisecond at the socket: refused ~0.1-0.2 ms,
    // accept-then-close ~0.5-1 ms, and ~3 ms for AnyDesk, whose listener
    // completes a TLS handshake when probed over https. That gap is only
    // visible with ONE request in flight at a time; the concurrent sweep
    // queues everything in the network process to 2-4 ms and erases it.
    //
    // Measured 2026-09-04, Chrome 152 and Edge on macOS, 12 runs idle and
    // busy: AnyDesk https min 2.7-7.9 ms against a control min of 0.1-1.2 ms,
    // a ratio of at least 5 in every run, while no closed port exceeded 2x
    // under load. TeamViewer and VNC sat at 3-8x idle and 1.4-2.5x busy, so
    // they are caught on a quiet page only.
    //
    // The statistic is a MINIMUM over rounds, not an average: load can only
    // push a timing up, never down, so the minimum converges on the socket
    // cost. This is what the retired absolute thresholds and the old
    // average-based rule lacked.
    this.timingProbeEnabled = configuration.timingProbe !== false;
    this.timingProbeScheme = "https";
    this.timingProbeRounds = 3;
    // Ceiling on the one-round-at-a-time confirmation of flagged ports. See
    // the confirmation loop in `runTimingProbe`. Three, because the probe is
    // only allowed to speak on a quiet page (below), and on a quiet page six
    // agreeing samples is plenty: 32 idle runs across Chrome, Edge and
    // Firefox produced no false positive at three initial rounds alone.
    this.timingProbeMaxConfirmRounds = 3;
    // Flagged ports at or above this multiple of the threshold skip
    // confirmation. See the confirmation loop.
    this.timingProbeConfirmBelowFactor = 2;

    // The probe only speaks on a quiet page.
    //
    // Timing verdicts on a busy page were wrong too often to ship: with the
    // main thread 60% blocked in 6 ms tasks, one closed port in about every
    // eight scans kept every sample delayed past the threshold, and neither
    // Resource Timing nor nine confirmation rounds fixed that. So the probe
    // waits for an idle callback, watches timer lag while it runs, and if the
    // main thread was blocked for more than this fraction of the probe it
    // withholds its verdicts and reports `pageBusy`. The measurements are
    // still emitted (`tmin`, `tflag`) so the field can show what a verdict
    // would have said. Integrators who can defer the collector to page idle
    // get the verdicts; on a page that never goes quiet, honesty over a guess.
    this.timingProbeIdleWaitMs = 200;
    this.timingProbeMaxBlockedRatio = 0.15;
    // Wall-clock ceiling for phase 2 alone. Firefox spends ~4 ms per request
    // on this path and would otherwise run past the point of usefulness.
    this.timingProbeBudgetMs = 300;
    // A TLS listener answers in single-digit ms; a port still silent here is
    // holding the connection, which is a listener too, and is scored at the
    // ceiling.
    this.timingProbeTimeoutMs = 50;
    this.timingProbeRatio = 3;
    this.timingProbeMarginMs = 0.5;
    // Coarsest clock the probe will run on. Chrome's 100 us clamp is the
    // intended case. Firefox's and Safari's 1 ms clocks are admitted because
    // the threshold in `decideTimingOpen` scales with the clock step and
    // Firefox measured listeners at 4-5 ms there; anything coarser (Firefox
    // resistFingerprinting is 100 ms) stands the probe down with a diagnostic.
    // Two rather than one: Firefox's 1 ms clock measured as 2 in a quarter
    // of runs, and on a 2 ms clock the threshold scales itself up to 6 ms,
    // which simply finds nothing rather than finding the wrong thing.
    this.timingProbeMaxTimerResolutionMs = 2;
    // Controls slower than this on the sequential path mean the environment,
    // not the socket, dominates the timing. Busy-page runs peaked at 1.2 ms.
    this.timingProbeMaxControlMinMs = 5;
    this.timingProbeMinControls = 3;

    // Floor on what "closed" can plausibly cost, and the counterpart to the
    // ceiling above. A blocked probe fails inside the fetch algorithm before any
    // packet leaves, which is an order of magnitude faster than a loopback RST
    // through the browser's network process.
    //
    // PROVISIONAL. 0.5 ms is set deliberately low: over-triggering turns a fast
    // clean host into `probeBlocked` and takes detection to zero, which is worse
    // than missing a block. Re-cut it from the `controls[].min` distribution on
    // real unblocked hosts once the field run lands — the floor wants to sit
    // just under the fastest genuine RST observed, not at a round number.
    this.minPlausibleBaselineMs = 0.5;

    // Target-side interceptor gate. Fires when more than this fraction of one
    // host's targets completed an HTTP exchange.
    //
    // Only applied from `minTargetsForInterceptorGate` targets upward: "most of
    // the map answered" means nothing across two or three ports, and the
    // integration suite legitimately scans small pinned sets. Nineteen ports is
    // comfortably above it, and no real host — clean or compromised — has ten
    // remote-access ports serving HTTP at once.
    this.targetInterceptorRatio = 0.5;
    this.minTargetsForInterceptorGate = 8;

    // Smallest step this browser's clock will admit to, measured once.
    //
    // The block floor above compares against sub-millisecond values, and
    // `performance.now()` is clamped: Chrome to 100 us without cross-origin
    // isolation, Firefox to 1 ms by default, coarser again under
    // resistFingerprinting. On a 1 ms clock a genuine fast loopback RST and a
    // blocked fetch both read 0, so the floor could not tell them apart and
    // would call a fast clean host blocked — taking detection to zero on the
    // machines that measure best.
    //
    // Measured rather than assumed, because it varies with browser, flags and
    // isolation state. Null when it could not be observed, which disables the
    // floor: unknown resolution is treated as coarse.
    this.timerResolutionMs = this.measureTimerResolutionMs();

    // Probe the IPv4 loopback literally rather than the `localhost` name.
    // Browsers resolve `localhost` to the IPv6 loopback ::1 in preference to
    // 127.0.0.1, while remote-access tools overwhelmingly bind IPv4 0.0.0.0, so a
    // name-resolved probe can fail instantly against ::1 and be scored as closed.
    // Using a literal address also keeps resolver latency out of the timing
    // measurement the whole open/closed decision depends on.
    this.probeHost = "127.0.0.1";

    // Optional IPv6 loopback sweep, scanned as separate targets rather than by
    // relying on resolver preference. Off by default: IPv6-only bound
    // remote-access services are rare and each host doubles the target count.
    this.ipv6ProbeHost = "[::1]";
    this.probeIpv6Loopback = configuration.probeIpv6Loopback === true;

    // RAT ports to scan.
    //
    // Reverse-connect tools (Zoho Assist, AsyncRAT, Quasar) are deliberately
    // absent. Their well-known ports — Quasar 4782, AsyncRAT 6606/7707/8808 —
    // are the *controller's* listening ports. On an implanted host the client
    // dials out and binds nothing, so a loopback probe cannot reach them at any
    // port number.
    //
    // They were added once and removed again, so the reason is worth keeping:
    // they cannot produce a true positive here, and they can produce a false
    // one. 8808 in particular is a common alternate-HTTP port for dev servers
    // and admin consoles, and anything answering HTTP there takes the
    // `successCount > 0` path — the branch treated as proof — and is reported
    // as an AsyncRAT detection. See the `not.toContain` assertions in the unit
    // suite, which exist to keep this decision from being undone by accident.
    //
    // Detecting an operator's own machine is a different product question with
    // different semantics ("this user runs controller software", not "this
    // session is remote-controlled"). It needs its own labelled set and its own
    // flag, not a quiet addition here.
    // Scoped to the four products this probe is known to detect. Everything else
    // was measured and removed rather than left in on the assumption that a
    // probed port costs nothing.
    //
    // AnyDesk earns its place for a different reason from the other three: on
    // Windows, 7070 answered on 15 of 15 captures with a live session and 0 of 18
    // with the app merely running — the only port measured here that separates a
    // remote session from an installed tool. Confirmed independently with
    // `Get-NetTCPConnection`: nothing listens on 7070 until a session is
    // established. TeamViewer, RealVNC and Splashtop listen whenever installed,
    // so they report presence, not sessions.
    //
    // Removed, with the evidence, so they are not re-added speculatively:
    //   RustDesk 21114-21119 — 0 detections across 15 ACTIVE-session and 21 idle
    //     Windows captures, and `Get-NetTCPConnection` confirms it binds nothing
    //     even when run as administrator. Reverse-connect, like AsyncRAT and
    //     Quasar, which were dropped for the same reason.
    //   RDP 3389 — never exercised by any capture in the corpus, so its one
    //     appearance was an artifact rather than a detection. Genuinely common in
    //     production; re-add it WITH a labelled RDP session to measure against,
    //     not before.
    //   KasmVNC 6800/6901 — never exercised either, and 6901 is TLS, so an http://
    //     probe may only ever see a handshake-level rejection indistinguishable
    //     from closed. Re-add alongside a real Kasm container capture.
    this.ratPorts = [
      { port: 7070, tool: "AnyDesk" },
      { port: 6568, tool: "AnyDesk" },
      { port: 5938, tool: "TeamViewer" },
      { port: 5939, tool: "TeamViewer" },
      { port: 5900, tool: "VNC" },
      { port: 5901, tool: "VNC" },
      { port: 5902, tool: "VNC" },
      // Splashtop answers real HTTP (`HTTP/1.0 404`), so it is caught by the
      // proof path in phase 1 and never needs the timing probe. Marking it
      // saves nine sequential requests per scan.
      { port: 6783, tool: "Splashtop", timing: false },
      { port: 6784, tool: "Splashtop", timing: false },
      { port: 6785, tool: "Splashtop", timing: false },
    ];
    this.timingExcludedPorts = new Set(
      this.ratPorts.filter((entry) => entry.timing === false).map((e) => e.port),
    );
  }

  /**
   * Collect the remotePorts identifier.
   *
   * Emits an object, not a bare port list: `{ status, ports, reason? }`. The
   * status distinguishes ports found, scanned clean, and probe inconclusive or
   * blocked, so an empty `ports` array is no longer a silent negative.
   *
   * A settled promise is cached deliberately, rejection included: a scan is
   * hundreds of requests, so a second caller must not trigger a second sweep.
   * The rejection carries the original failure as `cause`, so the reason a scan
   * died is still recoverable rather than flattened into NOT_AVAILABLE.
   *
   * @returns {Promise<{status: string, ports: number[], reason?: string}>} Scan payload
   */
  getPorts = () => {
    if (this._promise !== null) {
      return this._promise;
    }

    this._promise = this.scanPorts().catch((error) => {
      throw new Error(Constants.ERROR_CODES.NOT_AVAILABLE, { cause: error });
    });

    return this._promise;
  };

  /**
   * The loopback hosts this scan probes.
   *
   * @returns {string[]} Probe hosts, IPv4 first
   */
  buildProbeHosts = () =>
    this.probeIpv6Loopback
      ? [this.probeHost, this.ipv6ProbeHost]
      : [this.probeHost];

  /**
   * Build the list of scan targets: one entry per probe host per RAT port.
   * @returns {Array<{host: string, port: number, tool: string}>} Scan targets
   */
  buildScanTargets = () => {
    const targets = [];
    this.buildProbeHosts().forEach((host) => {
      this.ratPorts.forEach(({ port, tool }) => {
        targets.push({ host, port, tool });
      });
    });
    return targets;
  };

  /**
   * Measure the smallest observable step of `performance.now()`, in ms.
   *
   * Spins until the clock moves, bounded so a pathologically coarse or frozen
   * timer cannot hang collection. Runs once per instance and normally exits in
   * microseconds.
   *
   * @returns {number|null} Clock resolution in ms, or null if unobservable
   */
  measureTimerResolutionMs = () => {
    try {
      const start = performance.now();
      // Bounded by wall time as well as by iterations. Safari runs 20,000
      // calls in well under its 1 ms clock step, so an iteration bound alone
      // returned null in six of eight Safari scans and the timing probe
      // stood down for a clock it never measured. Date.now() is the wall
      // reference because it does not share the clamp being measured.
      const wallStart = Date.now();
      for (let attempt = 0; attempt < 2000000; attempt++) {
        const now = performance.now();
        if (now > start) {
          return now - start;
        }
        if (attempt % 1000 === 0 && Date.now() - wallStart > 4) {
          break;
        }
      }
    } catch {
      // Never break collection over a diagnostic.
    }
    return null;
  };

  /**
   * Draw one random integer in a range, tolerating an absent Web Crypto API.
   *
   * CollectorUtils reaches straight for window.crypto and throws when it is not
   * there. Control-port selection needs unpredictability only so that repeated
   * scans do not keep colliding with the same bound port; it is not a security
   * decision. Losing the whole collector over a missing crypto object is the
   * worse outcome, so the fallback derives a value from clock jitter.
   *
   * @param {number} min - Lower bound, inclusive
   * @param {number} maxExclusive - Upper bound, exclusive
   * @returns {number} Random integer in [min, maxExclusive)
   */
  drawRandomInt = (min, maxExclusive) => {
    try {
      return CollectorUtils.getRandomIntInRange(min, maxExclusive);
    } catch {
      const span = maxExclusive - min;
      return min + (Math.trunc(performance.now() * 1000) % span);
    }
  };

  /**
   * Pick the control ports for this scan: random high ports, nothing bound on
   * them with near-certainty, never one of the RAT ports we are looking for.
   *
   * The count is guaranteed. The old loop gave up after a fixed number of
   * attempts and could return a short set, which then failed the majority
   * checks in `calibrate` and voided the scan for a reason that had nothing to
   * do with the host. Random draws are still tried first; a deterministic walk
   * only fills whatever the draws left short.
   *
   * @returns {number[]} Control port numbers
   */
  pickControlPorts = () => {
    const reserved = new Set(this.ratPorts.map((entry) => entry.port));
    const chosen = new Set();
    const draw = () =>
      this.drawRandomInt(
        this.controlPortRangeMin,
        this.controlPortRangeMax + 1,
      );

    const attemptLimit = this.controlPortCount * 10;
    for (
      let attempt = 0;
      attempt < attemptLimit && chosen.size < this.controlPortCount;
      attempt++
    ) {
      const port = draw();
      if (!reserved.has(port)) {
        chosen.add(port);
      }
    }

    // Walk upward from a random start until the set is full. The range is far
    // wider than the count, so this terminates on the first few steps.
    let candidate = draw();
    while (chosen.size < this.controlPortCount) {
      if (!reserved.has(candidate)) {
        chosen.add(candidate);
      }
      candidate =
        candidate >= this.controlPortRangeMax
          ? this.controlPortRangeMin
          : candidate + 1;
    }

    return [...chosen];
  };

  /**
   * Scan the RAT ports and the control ports in one concurrent pass, calibrate
   * against the controls, then classify.
   *
   * Controls must be measured in the same pass as the targets: a baseline taken
   * before or after would describe a different load.
   *
   * Controls are also picked and calibrated *per probe host*. IPv4 and IPv6
   * loopback do not share latency or block policy, so judging a `[::1]` target
   * against a 127.0.0.1 baseline compares two different things.
   *
   * @returns {Promise<Object>} Scan payload
   */
  /**
   * Run the scan under a hard wall-clock budget.
   *
   * Every other ceiling here bounds one request. Nothing bounded the scan, and
   * the per-request ceilings only help if requests actually settle — an
   * environment where a loopback fetch neither resolves nor aborts holds the
   * whole collection open. This probe is already the most expensive collector in
   * the payload, on a budget of about a second, so it needs a ceiling it cannot
   * talk its way past.
   *
   * Returns `inconclusive` on expiry rather than throwing: a scan that ran out of
   * time is a scan with no verdict, which is a thing this payload can already
   * express. Diagnostics are omitted because the measurements are still in
   * flight, and a partial set would invite conclusions the scan did not reach.
   *
   * @returns {Promise<Object>} Scan payload
   */
  scanPorts = async () => {
    let budgetTimer;
    try {
      return await Promise.race([
        this.runScan(),
        new Promise((resolve) => {
          budgetTimer = setTimeout(
            () =>
              resolve({
                status: REMOTE_PORTS_STATUS.INCONCLUSIVE,
                ports: [],
                reason: REMOTE_PORTS_REASON.BUDGET_EXCEEDED,
              }),
            this.scanBudgetMs,
          );
        }),
      ]);
    } finally {
      clearTimeout(budgetTimer);
    }
  };

  /**
   * Perform the scan. Callers should use `scanPorts`, which bounds this.
   *
   * @returns {Promise<Object>} Scan payload
   */
  runScan = async () => {
    // Started before the sweep so no violation is missed, stopped in `finally`
    // so the listener never outlives the scan.
    const cspWatch = this.watchCspViolations();

    try {
      const startedAt = performance.now();

      const hosts = this.buildProbeHosts();
      const targets = this.buildScanTargets();

      const controlTargets = [];
      hosts.forEach((host) => {
        this.pickControlPorts().forEach((port) => {
          controlTargets.push({ port, tool: null, host });
        });
      });

      // ONE sweep: controls and targets together, at a single ceiling.
      //
      // This was briefly split into a calibration pass followed by a target pass,
      // to stop the baseline being measured under load the probe was itself
      // creating. That split was solving a problem that no longer exists. It
      // mattered only because a numeric threshold — "answered, but slower than
      // the controls, therefore open" — compared the two populations directly, so
      // measuring them at different concurrencies skewed the comparison and
      // produced nine false positives on a single container capture.
      //
      // That threshold is gone. Every surviving inference is a comparison of
      // KIND, not of magnitude: a completed HTTP exchange proves a listener, and
      // silence where the controls spoke (or speech where the controls were
      // silent) identifies one. None of them cares how long anything took, so the
      // two populations no longer need matched conditions — and folding them back
      // into one sweep returns the ~200 ms the calibration pass cost on every
      // scan, on a collector that is already the most expensive in the payload.
      const measurements = await Promise.all(
        [...targets, ...controlTargets].map((target) =>
          this.measurePort(target.port, target.tool, target.host, this.timeout),
        ),
      );

      const targetMeasurements = measurements.slice(0, targets.length);
      const controlMeasurements = measurements.slice(targets.length);

      const preBaselines = new Map();
      hosts.forEach((host) => {
        preBaselines.set(
          host,
          this.calibrate(
            controlMeasurements.filter(
              (measurement) => measurement.host === host,
            ),
          ),
        );
      });

      // A DROP reading claims that unbound ports are silent on this host. The
      // target sweep is the first chance to test that claim against something
      // other than the five controls, so test it: if most ports answered, they
      // cannot all be listeners and the premise is wrong — this is a host slow
      // enough to have missed the calibration ceiling, not one that drops.
      //
      // Withdrawing the mode here is what lets the calibration ceiling stay cheap.
      // The alternative was to wait longer up front on every scan to avoid ever
      // making the wrong call, which cost a second per page load.
      hosts.forEach((host) => {
        if (preBaselines.get(host)?.mode !== BASELINE_MODE.DROP) {
          return;
        }
        const hostTargets = targetMeasurements.filter((m) => m.host === host);
        const answered = hostTargets.filter(
          (m) => m.responseTimes.length > 0 || m.successCount > 0,
        );
        if (
          hostTargets.length > 0 &&
          answered.length > hostTargets.length * this.maxDropAnswerRatio
        ) {
          preBaselines.set(
            host,
            RemotePorts.voidBaseline(
              preBaselines.get(host),
              REMOTE_PORTS_REASON.BASELINE_TOO_NOISY,
            ),
          );
        }
      });

      const baselines = new Map();
      hosts.forEach((host) => {
        const baseline = preBaselines.get(host);

        // Target-side interceptor gate. Only consulted when the controls did not
        // already catch it: `controlsResponded` is the more direct evidence, so
        // it keeps the reason when both fire. This exists for the interceptor
        // that answers a minority of the controls and slips that gate.
        const intercepted =
          baseline.reason !== REMOTE_PORTS_REASON.CONTROLS_RESPONDED &&
          this.isTargetInterceptor(
            targetMeasurements.filter(
              (measurement) => measurement.host === host,
            ),
          );

        baselines.set(
          host,
          intercepted
            ? RemotePorts.voidBaseline(
                baseline,
                REMOTE_PORTS_REASON.TARGETS_SATURATED,
              )
            : baseline,
        );
      });

      const classifyAll = () =>
        targetMeasurements.map((measurement) => {
          const baseline =
            baselines.get(measurement.host) ?? RemotePorts.NO_BASELINE;
          const classification = this.classify(measurement, baseline);
          return this.buildPortResult({
            ...measurement,
            classification,
            via: this.describeOpenPath(measurement, classification, baseline),
          });
        });

      let results = classifyAll();

      // Phase 2: sequential timing probe over the ports phase 1 called CLOSED
      // on an RST host. Runs once; the overlay is re-applied after the gate
      // below so a voided baseline drops these verdicts with the rest.
      const timing = await this.runTimingProbe(
        hosts,
        results,
        controlMeasurements,
        baselines,
      );
      const applyTiming = (rows) =>
        rows.map((result) => {
          const key = `${result.host}:${result.port}`;
          if (!timing.mins.has(key)) {
            return result;
          }
          const baseline = baselines.get(result.host);
          const flip =
            timing.open.has(key) &&
            baseline?.usable === true &&
            baseline.mode === BASELINE_MODE.RST &&
            result.classification === PORT_CLASSIFICATION.CLOSED;
          return {
            ...result,
            timingMinMs: timing.mins.get(key),
            timingFlagged: timing.flagged.has(key),
            ...(flip && {
              classification: PORT_CLASSIFICATION.OPEN,
              accessible: true,
              via: "timing",
            }),
          };
        });

      results = applyTiming(results);

      // Post-classification saturation gate, and the last line of defence.
      //
      // The existing target gate keys on completed HTTP exchanges, which is the
      // interceptor signature. This one keys on the *verdict*: a host is not
      // running fifteen remote-access tools at once, so a map where most ports
      // read open is a failed measurement whatever route produced it. One
      // capture in the 2026-09-01 batch reached exactly that state — all
      // nineteen ports open on a single Windows capture whose siblings reported
      // one — through the timing path rather than the proof path, so the
      // exchange-based gate never saw it.
      //
      // It matters more now than before: DROP mode calls any answering port
      // open, so anything that makes a host answer broadly would otherwise
      // convert straight into a full-map false positive.
      hosts.forEach((host) => {
        const hostResults = results.filter((result) => result.host === host);
        const open = hostResults.filter(
          (result) => result.classification === PORT_CLASSIFICATION.OPEN,
        );
        if (
          hostResults.length > 0 &&
          open.length >= hostResults.length * this.maxOpenTargetRatio
        ) {
          baselines.set(
            host,
            RemotePorts.voidBaseline(
              baselines.get(host),
              REMOTE_PORTS_REASON.TARGETS_SATURATED,
            ),
          );
        }
      });

      results = applyTiming(classifyAll());

      return this.buildPayload(results, {
        baselines,
        primaryBaseline: this.selectVerdictBaseline(baselines, hosts),
        controlMeasurements,
        cspViolations: cspWatch.count(),
        durationMs: performance.now() - startedAt,
        timing,
      });
    } catch (error) {
      throw new Error(Constants.ERROR_CODES.NOT_AVAILABLE, { cause: error });
    } finally {
      cspWatch.stop();
    }
  };

  /**
   * Count Content-Security-Policy refusals of our own probe URLs while a scan
   * runs.
   *
   * A CSP block is the one cause of a blocked probe the browser will state
   * outright rather than leave to be inferred from timing, and the policy
   * differs per white-label tenant, so this is the difference between "this
   * tenant cannot run the probe" and an unexplained run of clean sheets.
   *
   * Filtered to our own loopback URLs: the host page has its own policy and its
   * own violations, and they say nothing about the probe.
   *
   * @returns {{count: function(): number, stop: function(): void}} Watcher
   */
  watchCspViolations = () => {
    let violations = 0;
    const prefixes = this.buildProbeHosts().map((host) => `http://${host}:`);

    const handler = (event) => {
      const blockedUri = String(event?.blockedURI ?? "");
      if (prefixes.some((prefix) => blockedUri.startsWith(prefix))) {
        violations++;
      }
    };

    try {
      document.addEventListener("securitypolicyviolation", handler);
    } catch {
      // No document, or listeners refused. Never break collection over
      // diagnostics.
      return { count: () => 0, stop: () => {} };
    }

    return {
      count: () => violations,
      stop: () => {
        try {
          document.removeEventListener("securitypolicyviolation", handler);
        } catch {
          // Nothing to do; the scan is over either way.
        }
      },
    };
  };

  /**
   * Whether one host's targets look like they are all being answered by the
   * same thing.
   *
   * @param {Array<Object>} targetMeasurements - Measurements for one host's RAT ports
   * @returns {boolean} Whether an interceptor is answering across the map
   */
  isTargetInterceptor = (targetMeasurements) => {
    if (targetMeasurements.length < this.minTargetsForInterceptorGate) {
      return false;
    }

    const responding = targetMeasurements.filter(
      (measurement) => measurement.successCount > 0,
    ).length;

    return responding > targetMeasurements.length * this.targetInterceptorRatio;
  };

  /**
   * Re-file a baseline under a reason that voids it, keeping the control facts
   * so the diagnostics still show what was measured.
   *
   * @param {Object} baseline - Baseline to void
   * @param {string} reason - Reason to file it under
   * @returns {Object} Voided baseline
   */
  static voidBaseline = (baseline, reason) => {
    const previous = baseline ?? RemotePorts.NO_BASELINE;

    return {
      ...previous,
      usable: false,
      // Cleared with the timings it belongs to. A voided baseline must not leave
      // DROP behind, or `classify` would keep reading silence as a verdict on a
      // scan the caller has just declared untrustworthy.
      mode: null,
      reason,
      // Both reasons can be true at once: the controls can report a saturated
      // environment while the targets report an interceptor. Overwriting would
      // lose the one that describes the environment, which is the same
      // mis-filing the reason codes were separated to prevent. Kept only when
      // it adds something the new reason does not.
      priorReason:
        previous.reason !== reason ? (previous.reason ?? null) : null,
      baselineMs: null,
      sigmaMs: null,
      thresholdMs: null,
    };
  };

  /**
   * Reduce the per-host baselines to the single one the scan verdict is built
   * from.
   *
   * The rule is worst-first, because the verdict is a statement about the whole
   * scan. An interceptor answering for dead ports is page-scope, so if it shows
   * on one host it invalidates every host. Any other calibration failure on any
   * host means the scan cannot claim a clean sheet. Only when every host
   * calibrated does the primary (IPv4) baseline carry the verdict.
   *
   * With a single probe host — the default — this returns that host's baseline
   * unchanged, so single-host behaviour is exactly as before.
   *
   * @param {Map<string, Object>} baselines - Baseline per probe host
   * @param {string[]} hosts - Probe hosts, IPv4 first
   * @returns {Object} Baseline to build the verdict from
   */
  selectVerdictBaseline = (baselines, hosts) => {
    const ordered = hosts.map(
      (host) => baselines.get(host) ?? RemotePorts.NO_BASELINE,
    );

    return (
      // Any proof-voiding reason on any host wins, not just controlsResponded.
      // An interceptor is page-scope, so it invalidates every host however it
      // was spotted — and if this only matched one of the two reasons, a host
      // failing for an ordinary timing reason would be picked ahead of a host
      // that caught the interceptor, and the first host's proof-path ports
      // would still be listed.
      ordered.find((baseline) => PROOF_VOIDING_REASONS.has(baseline.reason)) ??
      ordered.find((baseline) => !baseline.usable) ??
      ordered[0] ??
      RemotePorts.NO_BASELINE
    );
  };

  /**
   * Derive this machine's "closed port" reference from the control ports of one
   * probe host.
   *
   * The controls also police the scan. Nothing should be listening on a random
   * high port, so if a *majority* of them answer, or if they fall silent, the
   * probe measured the environment rather than the host and no port verdict is
   * trustworthy. A minority answering is an unlucky pick rather than a verdict
   * on the scan: those controls are dropped and the rest carry the baseline, as
   * set out below. That replaces the old 100-140 ms throttle band, which only
   * caught a uniform block that happened to land inside a 40 ms window.
   *
   * Sample counters in the returned facts describe the *quiet* controls only —
   * the ones the baseline was actually pooled from. `controlCount` and
   * `controlPorts` describe the whole set, and `quietControlCount` and
   * `controlsResponding` split it. Do not compute a ratio across the two
   * scopes.
   *
   * @param {Array<Object>} controlMeasurements - Measurements for one host's control ports
   * @returns {Object} Baseline
   */
  calibrate = (controlMeasurements) => {
    const controlCount = controlMeasurements.length;

    // A control port has nothing bound on it, so a completed HTTP exchange there
    // is something answering for a port that should be dead. Distinguish the two
    // ways that happens, because they need opposite handling:
    //
    //   a minority answering   - bad luck. The ephemeral range is not guaranteed
    //                            free, and a random pick can land on a real
    //                            listener. Drop those controls and calibrate on
    //                            the rest, so an unlucky pick does not void an
    //                            otherwise good scan (and does not make the same
    //                            host flip between clean and inconclusive across
    //                            repeat captures).
    //   a majority answering   - an interposing proxy, block page or injected
    //                            service worker replying for every port alike.
    //                            Handled below, and it voids more than the
    //                            timings.
    const respondingControls = controlMeasurements.filter(
      (measurement) => measurement.successCount > 0,
    );
    const quietControls = controlMeasurements.filter(
      (measurement) => measurement.successCount === 0,
    );

    const samples = [];
    let requests = 0;
    let timeouts = 0;
    let portsWithSamples = 0;

    quietControls.forEach((measurement) => {
      samples.push(...measurement.responseTimes);
      requests += measurement.requests;
      timeouts += measurement.timeoutCount;
      if (measurement.responseTimes.length > 0) {
        portsWithSamples++;
      }
    });

    const facts = {
      // Whole control set.
      controlPorts: controlMeasurements.map((measurement) => measurement.port),
      controlCount,
      // How many controls answered. Non-zero on a healthy scan means a random
      // pick was unlucky; a majority is the interceptor signature.
      controlsResponding: respondingControls.length,
      // Controls the baseline was pooled from. The three counters below are
      // scoped to these, not to controlCount.
      quietControlCount: quietControls.length,
      controlSamples: samples.length,
      controlTimeouts: timeouts,
      controlRequests: requests,
    };

    const unusable = (reason) => ({
      ...facts,
      usable: false,
      mode: null,
      reason,
      baselineMs: null,
      sigmaMs: null,
      thresholdMs: null,
    });

    // No controls at all: nothing was calibrated, and nothing was learned about
    // the environment either. Checked first so this case is never filed under a
    // reason that claims the controls reported something.
    if (controlCount === 0) {
      return unusable(REMOTE_PORTS_REASON.CONTROLS_UNUSABLE);
    }

    // Most of the ports that should be dead answered anyway. Nothing this scan
    // saw can be attributed to the host.
    if (respondingControls.length * 2 > controlCount) {
      return unusable(REMOTE_PORTS_REASON.CONTROLS_RESPONDED);
    }

    // Every remaining control answered, or issued no requests: there is no
    // quiet-control traffic to reason about, so this is a calibration gap and
    // not a measured environment.
    if (requests === 0) {
      return unusable(REMOTE_PORTS_REASON.CONTROLS_UNUSABLE);
    }

    // TOTAL control silence, with nothing answering and nothing erroring, is a
    // host property and not a failure: this stack drops SYNs to unbound ports
    // rather than resetting them, so a closed port is unmeasurable here by
    // construction. Recognising it is what separates "we could not measure this
    // machine" from "on this machine, silence is the closed reading".
    //
    // It must be checked BEFORE the ratio gate below, which would otherwise file
    // every such host under PROBE_SATURATED — the opposite diagnosis, since
    // saturation means something answers everywhere and this is nothing
    // answering anywhere. That mis-filing discarded all 132 Windows captures in
    // the 2026-09-01 batch, on hosts whose listening ports were plainly visible
    // in the very same measurements.
    //
    // Deliberately strict. A partial timeout ratio is genuinely ambiguous and
    // still falls through to the gate below; only an unbroken sweep of silence
    // across every control, with the requests confirmed as issued, is taken as
    // evidence about the host rather than about the probe.
    if (
      respondingControls.length === 0 &&
      samples.length === 0 &&
      timeouts === requests
    ) {
      return {
        ...facts,
        usable: true,
        mode: BASELINE_MODE.DROP,
        reason: null,
        // No closed-port timing exists on this host, so there is deliberately no
        // baseline and no threshold. `classify` must not reach a numeric
        // comparison in this mode.
        baselineMs: null,
        sigmaMs: null,
        thresholdMs: null,
      };
    }

    // Partial silence on ports with nothing behind them is not a host property:
    // some requests never reached the stack, or responses are being delayed past
    // the abort inconsistently. Neither reading can be trusted.
    if (timeouts / requests > this.maxControlTimeoutRatio) {
      return unusable(REMOTE_PORTS_REASON.PROBE_SATURATED);
    }

    // Require a majority of controls to have produced data, so one bound or
    // blocked control cannot define the baseline on its own.
    if (
      samples.length < this.minControlSamples ||
      portsWithSamples * 2 <= controlCount
    ) {
      return unusable(REMOTE_PORTS_REASON.CONTROLS_UNUSABLE);
    }

    // Controls must agree with each other before their pooled timings can stand
    // for "closed". One control far slower than its peers is a control with
    // something bound on it, and it would drag the whole baseline up.
    const controlAvgs = quietControls
      .map((measurement) => this.summarise(measurement.responseTimes).avg)
      .filter((value) => value !== null);
    const slowest = Math.max(...controlAvgs);
    const fastest = Math.min(...controlAvgs);
    if (
      slowest >
      fastest * this.maxControlAgreementFactor + this.baselineMinMarginMs
    ) {
      return unusable(REMOTE_PORTS_REASON.PROBE_SATURATED);
    }

    const { avg, stdDev } = this.summarise(samples);

    // A baseline past the plausible ceiling means an open port cannot be told
    // from a closed one: the separation the verdict needs is smaller than the
    // delay sitting on top of every measurement alike.
    //
    // Reported as BASELINE_TOO_NOISY, not PROBE_SATURATED. The controls were
    // measured — cleanly, and in agreement with each other — they were simply
    // too slow to discriminate. Calling that "saturated" sends whoever triages
    // it looking for an interceptor that is not there, which is what happened to
    // all 23 container captures in the 2026-09-01 batch: five controls agreeing
    // within a few ms at ~184 ms each, filed as an environment fault.
    //
    // The ceiling is generous because a container or a loaded VM genuinely is
    // this slow on loopback, and because the calibration pass now runs before
    // the target sweep rather than alongside it — most of that 184 ms was the
    // probe's own concurrency, not the host.
    if (avg > this.maxPlausibleBaselineMs) {
      return unusable(REMOTE_PORTS_REASON.BASELINE_TOO_NOISY);
    }

    // Scatter bound, relative to the baseline rather than to the abort ceiling.
    //
    // This replaces what `thresholdMs >= this.timeout` used to catch. That check
    // went circular the moment the abort became adaptive: the ceiling is now
    // derived from the threshold, so the threshold can no longer outrun it and
    // the check can barely fire. The property it was really testing was never
    // about the ceiling anyway — it was that closed-port timings must be tight
    // enough for "slower than closed" to mean something.
    //
    // Bimodal control timings (half at ~2 ms, half at ~75 ms) are the shape that
    // matters: the mean sits in a gap where no sample lands, so every threshold
    // built from it is arbitrary. Ratio cut from observed data, not chosen for
    // roundness — the loosest genuine macOS calibration in the 2026-09-01 batch
    // ran sigma 23.4 ms on a 36.2 ms baseline (0.65), so 0.8 clears real
    // hardware while still rejecting the bimodal case at 0.95.
    if (stdDev > this.maxBaselineNoiseRatio * avg) {
      return unusable(REMOTE_PORTS_REASON.BASELINE_TOO_NOISY);
    }

    // ...and too fast to be a network round trip at all. A CSP `connect-src`
    // refusal, a denied Local Network Access prompt or a blocking extension
    // rejects the fetch before a packet leaves. Controls and targets fail
    // alike, so the baseline comes out fast, tight and apparently healthy, and
    // every port then reads CLOSED against it. This is the check that stops a
    // blocked scan being reported as a clean one.
    //
    // Two limits worth knowing before trusting it:
    //
    // - It only catches a *total* block. `avg` is pooled across the quiet
    //   controls, so a policy or extension that refuses some origins and not
    //   others leaves the average mid-range and passes. The CSP counter covers
    //   that case for CSP alone; a partial non-CSP block is still invisible.
    // - It stands down when the clock is too coarse to mean anything. Comparing
    //   a 0.5 ms floor against a 1 ms-clamped timer would call every fast clean
    //   host blocked, so an unmeasurable or coarse resolution disables the
    //   check rather than firing it.
    const floorIsMeasurable =
      typeof this.timerResolutionMs === "number" &&
      this.timerResolutionMs < this.minPlausibleBaselineMs;

    if (floorIsMeasurable && avg < this.minPlausibleBaselineMs) {
      return unusable(REMOTE_PORTS_REASON.PROBE_BLOCKED);
    }

    const thresholdMs =
      avg +
      Math.max(this.baselineSigmaMultiplier * stdDev, this.baselineMinMarginMs);

    // No adaptive ceiling any more, and none is needed: nothing compares a port's
    // timing against `thresholdMs` to decide open. It is retained purely as a
    // diagnostic — the number a reader would want if a verdict ever looks wrong.

    // Controls must agree with each other. One control reading "open" against
    // the pooled threshold means the spread is being driven by something other
    // than loopback latency.
    const disagreeing = quietControls.some((measurement) => {
      const controlAvg = this.summarise(measurement.responseTimes).avg;
      return controlAvg !== null && controlAvg > thresholdMs;
    });
    if (disagreeing) {
      return unusable(REMOTE_PORTS_REASON.PROBE_SATURATED);
    }

    return {
      ...facts,
      usable: true,
      mode: BASELINE_MODE.RST,
      reason: null,
      baselineMs: avg,
      sigmaMs: stdDev,
      thresholdMs,
    };
  };

  /**
   * Classify one port against the calibrated baseline for its probe host.
   *
   * @param {Object} measurement - Raw measurements for the port
   * @param {Object} baseline - Baseline from `calibrate` for this port's host
   * @returns {string} Classification
   */
  classify = (measurement, baseline) => {
    const { responseTimes, timeoutCount, requests, successCount } = measurement;

    // A no-cors fetch that resolves means something completed an HTTP exchange
    // on this port. That is proof of a listener and owes nothing to timing, so
    // it stands even when calibration failed for a timing reason.
    //
    // It does not stand when the control ports answered too. The inference is
    // only sound while a completed exchange does not also happen on a port with
    // nothing bound, and the controls test exactly that premise: when they
    // answer, the proof is void rather than merely uncalibrated. Without this,
    // an interposing proxy or block page that replies to every http:// request
    // reports the whole port map as open — the all-ports false positive the
    // control ports exist to stop, arriving through the one path that used to
    // bypass them.
    if (successCount > 0) {
      return PROOF_VOIDING_REASONS.has(baseline.reason)
        ? PORT_CLASSIFICATION.INCONCLUSIVE
        : PORT_CLASSIFICATION.OPEN;
    }

    const timeoutRatio = requests > 0 ? timeoutCount / requests : 0;
    const allSilent = responseTimes.length === 0 && timeoutRatio === 1;

    // On a host that drops rather than resets, the verdict inverts: silence is
    // what an unbound port looks like — the controls proved it on this very page
    // load — and a port that answers at all is a port with a listener behind it,
    // closing the connection on an HTTP request it does not understand.
    //
    // No threshold is involved, which is the point. The old failure mode was a
    // 50 ms window between two constants, decided by machine load; this is a
    // ~26 ms answer against a never, and it does not move when the host is busy.
    // On the 2026-09-01 batch it agreed across repeat captures 81 times out of
    // 89, against 7 of 16 for the shipped build.
    if (baseline.mode === BASELINE_MODE.DROP) {
      // A majority of the port's own requests must have answered. A lone sample
      // among timeouts is the flake this mode would otherwise be wide open to,
      // and on the measured hosts a listening port answered every request while
      // an unbound one answered none — so the majority rule costs nothing real.
      if (responseTimes.length * 2 > requests) {
        return PORT_CLASSIFICATION.OPEN;
      }
      if (allSilent) {
        return PORT_CLASSIFICATION.CLOSED;
      }
      return PORT_CLASSIFICATION.INCONCLUSIVE;
    }

    if (!baseline.usable) {
      // Report the raw shape and let the scan status carry the caveat.
      return allSilent
        ? PORT_CLASSIFICATION.FILTERED_OR_OPEN
        : PORT_CLASSIFICATION.INCONCLUSIVE;
    }

    // The controls answered fast under this very load, so silence here is not
    // this machine being slow: the port accepted the connection and never spoke
    // HTTP, which is what every non-HTTP remote-access tool does.
    if (allSilent) {
      return PORT_CLASSIFICATION.OPEN;
    }

    // Defensive, not dead. Reached only when a request neither produced a
    // sample nor counted as a timeout, which happens when `fetch` throws
    // synchronously and `measurePort` records it under `errorCount`. Rare, but
    // the alternative is falling through to `summarise([])` and comparing null
    // against the threshold.
    if (responseTimes.length === 0) {
      return PORT_CLASSIFICATION.INCONCLUSIVE;
    }

    // Mostly silent, but not cleanly so. Evidence without a verdict.
    if (timeoutRatio >= this.majorityTimeoutRatio) {
      return PORT_CLASSIFICATION.FILTERED_OR_OPEN;
    }

    // A port that answered is CLOSED. There is deliberately no "answered, but
    // slower than the baseline, therefore open" branch any more.
    //
    // That comparison was the collector's original premise and it does not
    // survive contact with the data. Across 256 captures on 2026-09-01, every
    // port it ever called open was a false positive — nine of them, all in one
    // container capture, none with any remote-access software running — while
    // every true detection arrived through a path that owes it nothing: five via
    // a completed HTTP exchange (macOS Splashtop) and six via answering while the
    // controls stayed silent (Windows TeamViewer).
    //
    // The reason is structural rather than a matter of tuning. The threshold is
    // built from controls measured at one concurrency and applied to targets
    // measured at another, so the tail of the target queue outruns it: those nine
    // ports were the last nine in the sweep, averaging 231 ms against a 113 ms
    // threshold drawn from controls averaging 46 ms. Widening the margin only
    // trades those false positives for missed ones, because the quantity being
    // compared is scheduling delay, not port state.
    //
    // What remains are the two inferences that do not depend on how loaded the
    // machine is: a completed HTTP exchange proves a listener outright, and
    // silence where the controls spoke is the non-HTTP service signature. Both
    // are ratios against a same-page-load reference rather than measurements
    // against a clock.
    return PORT_CLASSIFICATION.CLOSED;
  };

  /**
   * Build the emitted payload: the verdict, plus the measurements it came from.
   *
   * `baseline` is the pre-multi-host name for `primaryBaseline` and is still
   * accepted. Dropping it outright was worse than keeping it: an unconverted
   * caller kept working but silently fell back to NO_BASELINE, so a scan that
   * really was `probeSaturated` came out as `controlsUnusable` — the exact
   * mis-filing the reason codes were separated to prevent, reached by a
   * different route. A wrong answer that looks like an answer is the failure
   * mode this collector can least afford.
   *
   * @param {Array<Object>} results - Per-port scan results
   * @param {Object} [options] - Scan-level facts
   * @returns {Object} Scan payload
   */
  buildPayload = (
    results,
    {
      baselines = new Map(),
      baseline,
      primaryBaseline = baseline ?? RemotePorts.NO_BASELINE,
      controlMeasurements = [],
      cspViolations = 0,
      durationMs = null,
      timing = null,
    } = {},
  ) => {
    const verdict = this.buildVerdict(results, primaryBaseline, cspViolations);

    if (!this.emitDiagnostics) {
      return verdict;
    }

    return {
      ...verdict,
      scan: this.buildScanDiagnostics(results, {
        baselines,
        primaryBaseline,
        cspViolations,
        durationMs,
        timing,
      }),
      probes: results.map(this.buildProbeDiagnostics),
      controls: controlMeasurements.map(this.buildControlDiagnostics),
    };
  };

  /**
   * Baseline placeholder for callers that classify without calibrating.
   */
  static NO_BASELINE = Object.freeze({
    usable: false,
    mode: null,
    reason: REMOTE_PORTS_REASON.CONTROLS_UNUSABLE,
    baselineMs: null,
    sigmaMs: null,
    thresholdMs: null,
    controlPorts: [],
    controlCount: 0,
    controlsResponding: 0,
    quietControlCount: 0,
    controlSamples: 0,
    controlTimeouts: 0,
    controlRequests: 0,
  });

  /**
   * Scan-level diagnostics: what the probe did, under what settings, and what
   * the control ports said about whether any of it can be believed.
   *
   * The flat calibration fields describe the baseline the verdict was built
   * from. When more than one probe host is in play, `perHost` carries each
   * host's own calibration; with the default single host it is omitted, so the
   * payload shape is unchanged for existing consumers.
   *
   * `baseline` is accepted as the older name for `primaryBaseline`, as in
   * `buildPayload`.
   *
   * @param {Array<Object>} results - Per-port scan results
   * @param {Object} [options] - Scan-level facts
   * @returns {Object} Scan diagnostics
   */
  buildScanDiagnostics = (
    results,
    {
      baselines = new Map(),
      baseline,
      primaryBaseline = baseline ?? RemotePorts.NO_BASELINE,
      cspViolations = 0,
      durationMs = null,
      timing = null,
    },
  ) => {
    const hosts = this.buildProbeHosts();

    return {
      // Phase 2 outcome. `ran` false with a `skipped` code means no timing
      // verdict was attempted on any host; read a macOS clean sheet against
      // this before trusting it.
      timing: this.buildTimingDiagnostics(timing),
      // Total probe wall clock. Detection was found to correlate with
      // collectionRunTime, so the scan's own duration has to be readable
      // directly rather than inferred from the payload-wide figure.
      durationMs: RemotePorts.round(durationMs),
      host: this.probeHost,
      targets: results.length,
      // The abort ceiling every response time below is bounded by. Read a
      // per-port timeout count against this, or against the per-row `req`.
      timeoutMs: this.timeout,
      // How this host answers a port with nothing bound on it: `rst` (closed
      // ports answer fast, so open ports are the slow or silent ones) or `drop`
      // (closed ports never answer, so the verdict inverts and the only ports
      // that answer are the listening ones). Null when calibration failed.
      //
      // This is the single most useful field for triaging a surprising verdict:
      // it says which of two opposite rules produced it.
      mode: primaryBaseline.mode ?? null,
      // Requests actually issued per port at the ceiling, not the requested
      // budget: batching rounds the budget up to a batch boundary.
      requestsPerPort: this.maxRequestsPerPort,
      webkit: this.isWebKit,
      safariWebKit: this.isSafariWebKit,
      calibrated: primaryBaseline.usable,
      // Controls that completed an HTTP exchange. Lets a false positive be
      // attributed to an interceptor answering for dead ports without
      // re-running the scan.
      controlsResponding: primaryBaseline.controlsResponding ?? 0,
      quietControls: primaryBaseline.quietControlCount ?? 0,
      // Probe URLs the page's own Content-Security-Policy refused. Non-zero
      // means this tenant's policy blocks the probe, which is a tenant
      // configuration fact rather than anything about the host.
      cspViolations,
      // Smallest step the clock admits to. The block floor stands down when
      // this is coarser than the floor, so a scan that skipped that check is
      // identifiable in the field rather than merely absent.
      timerResolutionMs: this.timerResolutionMs,
      // Targets that completed an HTTP exchange, for the host the verdict was
      // built from — the gate is per host, so a cross-host total here would not
      // reconcile with the decision that actually fired. Per-host figures are
      // in `perHost`.
      targetsResponding: results.filter(
        (result) => result.host === this.probeHost && result.successes > 0,
      ).length,
      baselineMs: RemotePorts.round(primaryBaseline.baselineMs),
      sigmaMs: RemotePorts.round(primaryBaseline.sigmaMs),
      thresholdMs: RemotePorts.round(primaryBaseline.thresholdMs),
      // Only when the new reason displaced an older one, so the common case
      // costs nothing.
      ...(primaryBaseline.priorReason && {
        priorReason: primaryBaseline.priorReason,
      }),
      ...(hosts.length > 1 && {
        perHost: hosts.map((host) =>
          this.buildHostDiagnostics(
            host,
            baselines.get(host) ?? RemotePorts.NO_BASELINE,
            results.filter(
              (result) => result.host === host && result.successes > 0,
            ).length,
          ),
        ),
      }),
    };
  };

  /**
   * Per-host calibration diagnostics, emitted only for a multi-host scan.
   *
   * @param {string} host - Probe host
   * @param {Object} baseline - That host's baseline
   * @returns {Object} Host diagnostics
   */
  buildHostDiagnostics = (host, baseline, targetsResponding = 0) => ({
    host,
    calibrated: baseline.usable,
    reason: baseline.reason,
    controlPorts: baseline.controlPorts,
    controlsResponding: baseline.controlsResponding,
    quietControls: baseline.quietControlCount,
    // Scoped to this host, so it reconciles with the per-host gate decision.
    targetsResponding,
    baselineMs: RemotePorts.round(baseline.baselineMs),
    sigmaMs: RemotePorts.round(baseline.sigmaMs),
    thresholdMs: RemotePorts.round(baseline.thresholdMs),
    ...(baseline.priorReason && { priorReason: baseline.priorReason }),
  });

  /**
   * Control-port diagnostics. Compact keys as per `buildProbeDiagnostics`.
   *
   * @param {Object} measurement - Control port measurement
   * @returns {Object} Control diagnostics
   */
  buildControlDiagnostics = (measurement) => {
    const { avg, min, max } = this.summarise(measurement.responseTimes);

    return {
      p: measurement.port,
      avg: RemotePorts.round(avg),
      min: RemotePorts.round(min),
      max: RemotePorts.round(max),
      n: measurement.responseTimes.length,
      to: measurement.timeoutCount,
      err: measurement.errorCount,
      ok: measurement.successCount,
      req: measurement.requests,
      // Only meaningful when more than one probe host is in play.
      ...(this.probeIpv6Loopback && { host: measurement.host }),
    };
  };

  /**
   * Per-port diagnostics. Compact keys: p port, c classification, avg/min/max
   * response time in ms, n usable samples, to timeouts, err requests whose
   * promise rejected outright, ok requests that completed an HTTP exchange,
   * req requests issued.
   *
   * @param {Object} result - Per-port scan result
   * @returns {Object} Port diagnostics
   */
  buildProbeDiagnostics = (result) => ({
    p: result.port,
    c: result.classification,
    // Which inference produced an OPEN: proof (completed HTTP exchange),
    // silent (RST host, never answered), answered (DROP host, answered),
    // timing (phase 2). Absent on any other classification.
    ...(result.via && { via: result.via }),
    avg: RemotePorts.round(result.averageResponseTime),
    min: RemotePorts.round(result.minResponseTime),
    max: RemotePorts.round(result.maxResponseTime),
    // Phase 2 minimum in ms, two decimals because the scale is sub-ms. Only
    // present on ports the timing probe measured.
    ...(typeof result.timingMinMs === "number" && {
      tmin: RemotePorts.round2(result.timingMinMs),
    }),
    // The timing rule flagged this port, whether or not the verdict stood
    // (it does not on a busy page). Only emitted when true.
    ...(result.timingFlagged === true && { tflag: true }),
    n: result.samples,
    to: result.timeouts,
    err: result.errors,
    ok: result.successes,
    req: result.requests,
    // Only meaningful when more than one probe host is in play.
    ...(this.probeIpv6Loopback && { host: result.host }),
  });

  /**
   * Round a millisecond measurement to one decimal place, preserving null.
   *
   * @param {number|null} value - Value in ms
   * @returns {number|null} Rounded value
   */
  static round(value) {
    return typeof value === "number" ? Number(value.toFixed(1)) : null;
  }

  /**
   * Round to two decimal places, preserving null. For the sub-millisecond
   * timing-probe figures, where one decimal would fold 0.15 into 0.2.
   *
   * @param {number|null} value - Value in ms
   * @returns {number|null} Rounded value
   */
  static round2(value) {
    return typeof value === "number" ? Number(value.toFixed(2)) : null;
  }

  /**
   * Median of a numeric array, null when empty.
   *
   * @param {number[]} values - Values
   * @returns {number|null} Median
   */
  static median(values) {
    if (values.length === 0) {
      return null;
    }
    const sorted = [...values].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 === 1
      ? sorted[mid]
      : (sorted[mid - 1] + sorted[mid]) / 2;
  }

  /**
   * Name the inference behind an OPEN classification, for diagnostics.
   *
   * @param {Object} measurement - Raw measurements for the port
   * @param {string} classification - Phase 1 classification
   * @param {Object} baseline - Baseline for the port's host
   * @returns {string|null} "proof", "silent" or "answered"; null unless OPEN
   */
  describeOpenPath = (measurement, classification, baseline) => {
    if (classification !== PORT_CLASSIFICATION.OPEN) {
      return null;
    }
    if (measurement.successCount > 0) {
      return "proof";
    }
    return baseline.mode === BASELINE_MODE.DROP ? "answered" : "silent";
  };

  /**
   * Phase 2 diagnostics, flattened for the single-host default.
   *
   * @param {Object|null} timing - Outcome of `runTimingProbe`
   * @returns {Object} Timing diagnostics
   */
  buildTimingDiagnostics = (timing) => {
    if (!timing) {
      return { ran: false, skipped: "notRun" };
    }
    const hosts = timing.perHost ?? [];
    const primary = hosts.find((entry) => entry.host === this.probeHost);
    return {
      ran: timing.ran,
      ...(timing.skipped && { skipped: timing.skipped }),
      scheme: this.timingProbeScheme,
      rounds: this.timingProbeRounds,
      // How long the probe waited for an idle callback, and what fraction of
      // its run the main thread was blocked. `pageBusy` above is the latter
      // exceeding `timingProbeMaxBlockedRatio`.
      waitedMs: RemotePorts.round(timing.waitedMs),
      blockedRatio: RemotePorts.round2(timing.blockedRatio),
      ...(primary?.ran && {
        controlMinMs: RemotePorts.round2(primary.controlMinMs),
        thresholdMs: RemotePorts.round2(primary.thresholdMs),
        candidates: primary.candidates,
        open: primary.open,
        rtSamples: primary.rtSamples,
        samples: primary.samples,
        durationMs: RemotePorts.round(primary.durationMs),
      }),
      ...(hosts.length > 1 && {
        perHost: hosts.map((entry) => ({
          ...entry,
          controlMinMs: RemotePorts.round2(entry.controlMinMs ?? null),
          thresholdMs: RemotePorts.round2(entry.thresholdMs ?? null),
          durationMs: RemotePorts.round(entry.durationMs ?? null),
        })),
      }),
    };
  };

  /**
   * Phase 2: sequential timing probe.
   *
   * Runs only on hosts whose phase 1 baseline is a usable RST reading, and
   * only over the ports phase 1 called CLOSED without proof. One request in
   * flight at a time, targets and controls interleaved in a fresh random order
   * each round so drift lands on both alike. The per-port statistic is the
   * minimum across rounds.
   *
   * Never throws: a failure here must not cost the phase 1 verdict.
   *
   * @param {string[]} hosts - Probe hosts
   * @param {Array<Object>} results - Phase 1 per-port results
   * @param {Array<Object>} controlMeasurements - Phase 1 control measurements
   * @param {Map<string, Object>} baselines - Baseline per host
   * @returns {Promise<{ran: boolean, skipped: string|null, mins: Map, open: Set, perHost: Array}>}
   */
  runTimingProbe = async (hosts, results, controlMeasurements, baselines) => {
    const outcome = {
      ran: false,
      skipped: null,
      mins: new Map(),
      open: new Set(),
      // Ports the rule flagged whether or not the verdict was allowed to
      // stand; diagnostics only.
      flagged: new Set(),
      perHost: [],
      waitedMs: null,
      blockedRatio: null,
    };

    if (!this.timingProbeEnabled) {
      outcome.skipped = "disabled";
      return outcome;
    }
    // Small tolerance: a 1 ms clock measures as 1 plus floating-point dust,
    // and one Firefox run in eight was skipped for exactly that.
    if (
      typeof this.timerResolutionMs !== "number" ||
      this.timerResolutionMs > this.timingProbeMaxTimerResolutionMs + 0.05
    ) {
      outcome.skipped = "coarseClock";
      return outcome;
    }

    // Wait for a quiet moment, then watch for the page getting busy again
    // while the probe runs. See `timingProbeMaxBlockedRatio`.
    const idle = await this.waitForIdle();
    outcome.waitedMs = idle.waitedMs;
    const lag = this.startLagMonitor();
    const probeStartedAt = performance.now();
    const overBudget = () =>
      performance.now() - probeStartedAt > this.timingProbeBudgetMs;
    // Once the page is seen to be busy the verdict is already forfeit, so
    // stop paying for rounds that cannot stand.
    const seenBusy = () =>
      lag.peek().blockedRatio > this.timingProbeMaxBlockedRatio;

    for (const host of hosts) {
      if (overBudget() || seenBusy()) {
        outcome.perHost.push({
          host,
          ran: false,
          skipped: seenBusy() ? "pageBusy" : "budget",
        });
        continue;
      }
      const baseline = baselines.get(host);
      if (baseline?.usable !== true || baseline.mode !== BASELINE_MODE.RST) {
        outcome.perHost.push({ host, ran: false, skipped: "notRstMode" });
        continue;
      }

      const candidates = results
        .filter(
          (result) =>
            result.host === host &&
            result.classification === PORT_CLASSIFICATION.CLOSED &&
            result.successes === 0 &&
            result.samples > 0 &&
            !this.timingExcludedPorts.has(result.port),
        )
        .map((result) => result.port);
      if (candidates.length === 0) {
        outcome.perHost.push({ host, ran: false, skipped: "noCandidates" });
        continue;
      }

      // Only the quiet controls: one that answered HTTP in phase 1 has
      // something bound on it and would drag the reference up.
      const controls = controlMeasurements
        .filter(
          (measurement) =>
            measurement.host === host &&
            measurement.successCount === 0 &&
            measurement.responseTimes.length > 0,
        )
        .map((measurement) => measurement.port);
      if (controls.length < this.timingProbeMinControls) {
        outcome.perHost.push({ host, ran: false, skipped: "controlsUnusable" });
        continue;
      }

      const startedAt = performance.now();
      let mins;
      try {
        mins = await this.measureSequentialMins(host, candidates, controls);
      } catch {
        outcome.perHost.push({ host, ran: false, skipped: "probeFailed" });
        continue;
      }
      let decision = this.decideTimingOpen(mins, candidates, controls);

      // Confirmation. A busy page delays requests at random, and with ten
      // candidates it is not rare for one closed port to have every one of
      // its first three samples delayed past the threshold: the busy-page
      // harness produced one such false positive in about every eight scans.
      //
      // So a flagged port is re-measured one round at a time, with the
      // controls, until its minimum drops below the threshold — which a
      // closed port does as soon as one sample gets through undelayed — or it
      // has survived `timingProbeMaxConfirmRounds` more rounds, which only a
      // port that is genuinely slower at the socket does. On a quiet page a
      // real listener costs the full rounds and a false flag costs one; on a
      // busy page the cost is whatever it takes to tell them apart.
      // Only ports NEAR the threshold need confirming. A port whose minimum is
      // already `timingProbeConfirmBelowFactor` times the threshold (AnyDesk
      // reads 4x on a quiet page) cannot be a delayed closed port: on an idle
      // page closed ports never reached 2x in any run. Skipping their rounds
      // saves the most expensive requests in the scan, since a TLS listener
      // costs ~3 ms per request against 0.2 ms for the rest.
      const needsConfirm = () =>
        [...decision.open].filter(
          (port) =>
            mins.get(port) <
            decision.thresholdMs * this.timingProbeConfirmBelowFactor,
        );
      let confirmRounds = 0;
      while (
        !decision.skipped &&
        needsConfirm().length > 0 &&
        confirmRounds < this.timingProbeMaxConfirmRounds &&
        !overBudget() &&
        !seenBusy()
      ) {
        try {
          const more = await this.measureSequentialMins(
            host,
            needsConfirm(),
            controls,
            1,
          );
          more.forEach((value, port) => {
            mins.set(port, Math.min(mins.get(port) ?? Infinity, value));
          });
          mins.rtSamples = (mins.rtSamples ?? 0) + (more.rtSamples ?? 0);
          mins.samples = (mins.samples ?? 0) + (more.samples ?? 0);
          decision = this.decideTimingOpen(mins, candidates, controls);
        } catch {
          // Keep the decision so far; confirmation is a refinement.
          break;
        }
        confirmRounds++;
      }
      const durationMs = performance.now() - startedAt;

      if (decision.skipped) {
        outcome.perHost.push({
          host,
          ran: false,
          skipped: decision.skipped,
          controlMinMs: decision.controlMinMs,
          durationMs,
        });
        continue;
      }

      candidates.forEach((port) => {
        const key = `${host}:${port}`;
        outcome.mins.set(key, mins.get(port));
        if (decision.open.has(port)) {
          outcome.open.add(key);
          outcome.flagged.add(key);
        }
      });
      outcome.perHost.push({
        host,
        ran: true,
        controlMinMs: decision.controlMinMs,
        thresholdMs: decision.thresholdMs,
        candidates: candidates.length,
        open: decision.open.size,
        // How many samples came from Resource Timing rather than the
        // JavaScript clock. Zero on Firefox and on a page whose observer
        // failed; then the timings carry main-thread delay.
        rtSamples: mins.rtSamples ?? 0,
        samples: mins.samples ?? 0,
        durationMs,
      });
      outcome.ran = true;
    }

    const lagStats = lag.stop();
    outcome.blockedRatio = lagStats.blockedRatio;

    // The page got busy while the probe ran: the flags are recorded but no
    // verdict stands. See `timingProbeMaxBlockedRatio`.
    if (
      outcome.ran &&
      lagStats.blockedRatio > this.timingProbeMaxBlockedRatio
    ) {
      outcome.open.clear();
      outcome.ran = false;
      outcome.skipped = "pageBusy";
      outcome.perHost.forEach((entry) => {
        if (entry.ran) {
          entry.ran = false;
          entry.skipped = "pageBusy";
        }
      });
      return outcome;
    }

    if (!outcome.ran) {
      outcome.skipped = outcome.perHost[0]?.skipped ?? "noHosts";
    }
    return outcome;
  };

  /**
   * Resolve at the next idle callback, or after `timingProbeIdleWaitMs` if
   * none comes. Falls back to a macrotask where the API is absent (Node,
   * Safari before 2024).
   *
   * @returns {Promise<{waitedMs: number, didTimeout: boolean}>} How long we waited
   */
  waitForIdle = () =>
    new Promise((resolve) => {
      const started = performance.now();
      const done = (didTimeout) =>
        resolve({ waitedMs: performance.now() - started, didTimeout });
      try {
        if (typeof requestIdleCallback === "function") {
          requestIdleCallback((deadline) => done(deadline.didTimeout), {
            timeout: this.timingProbeIdleWaitMs,
          });
          return;
        }
      } catch {
        // Fall through to the timer.
      }
      setTimeout(() => done(false), 0);
    });

  /**
   * Measure how much of a period the main thread spent blocked, from the lag
   * of a repeating timer. A timer that should fire every 4 ms and fires after
   * 10 was held for 6. Four ms is Chrome's clamp for nested timers, so the
   * expected gap is stable, and only gaps of more than twice that count, so
   * ordinary jitter does not.
   *
   * @returns {{stop: function(): {blockedMs: number, elapsedMs: number, blockedRatio: number}}} Handle
   */
  startLagMonitor = () => {
    const interval = 4;
    const started = performance.now();
    let last = started;
    let blocked = 0;
    let running = true;

    const tick = () => {
      if (!running) {
        return;
      }
      const now = performance.now();
      const gap = now - last;
      if (gap > interval * 2) {
        blocked += gap - interval;
      }
      last = now;
      setTimeout(tick, interval);
    };
    try {
      setTimeout(tick, interval);
    } catch {
      running = false;
    }

    const stats = () => {
      const elapsedMs = performance.now() - started;
      return {
        blockedMs: blocked,
        elapsedMs,
        blockedRatio: elapsedMs > 0 ? blocked / elapsedMs : 0,
      };
    };

    return {
      peek: stats,
      stop: () => {
        running = false;
        return stats();
      },
    };
  };

  /**
   * Issue one request at a time to every port in `candidates` and `controls`,
   * `timingProbeRounds` times, and return each port's minimum time.
   *
   * A request that hits the ceiling scores the ceiling: on the sequential path
   * a refused port answers in a fraction of a millisecond, so a port that is
   * still silent at the ceiling is holding the connection open.
   *
   * @param {string} host - Probe host
   * @param {number[]} candidates - Target ports
   * @param {number[]} controls - Control ports
   * @returns {Promise<Map<number, number>>} Minimum ms per port
   */
  measureSequentialMins = async (
    host,
    candidates,
    controls,
    rounds = this.timingProbeRounds,
  ) => {
    const order = [...candidates, ...controls];
    const seed = this.drawRandomInt(0, 10000000);
    const samples = [];
    let issued = 0;

    // Resource Timing gives the request's duration as the network process
    // saw it. The JavaScript clock also counts the wait for the main thread
    // to run the fetch callback, and on a busy page that wait is long tasks
    // of several ms landing on top of a 0.2 ms socket answer. Measured on
    // the busy-page harness: AnyDesk 9.4 ms by JavaScript, 3.6 ms by Resource
    // Timing, and 3.6 ms idle by both. Chrome and Edge record entries for
    // failed fetches; Firefox records them with a zero duration, and a zero
    // is treated as absent so the JavaScript figure stands in.
    //
    // A PerformanceObserver rather than the timeline buffer: the host page may
    // have filled its 250-entry buffer long before this probe runs, and the
    // observer receives entries regardless. The probe never clears or resizes
    // the host page's buffer.
    const entries = new Map();
    const observer = this.observeResourceTimings(entries);

    try {
      for (let round = 0; round < rounds; round++) {
        this.shuffle(order);
        for (const port of order) {
          const requestId = (seed + issued++) % 10000000;
          const url = `${this.timingProbeScheme}://${host}:${port}/${requestId}.png`;
          const response = await this.testHttpConnection(
            url,
            this.timingProbeTimeoutMs,
          );
          const jsMs =
            response.error === "timeout"
              ? this.timingProbeTimeoutMs
              : response.responseTime;
          samples.push({ port, url, jsMs, timedOut: response.error === "timeout" });
        }
      }
      // Entries are delivered a task later than the fetch settles; let the
      // observer catch up before reading them.
      await new Promise((resolve) => setTimeout(resolve, 0));
    } finally {
      observer.stop();
    }

    const mins = new Map();
    let rtSamples = 0;
    samples.forEach(({ port, url, jsMs, timedOut }) => {
      const rtMs = timedOut ? null : (entries.get(url) ?? null);
      const ms = typeof rtMs === "number" && rtMs > 0 ? rtMs : jsMs;
      if (ms === rtMs) {
        rtSamples++;
      }
      mins.set(port, Math.min(mins.get(port) ?? Infinity, ms));
    });
    mins.rtSamples = rtSamples;
    mins.samples = samples.length;
    return mins;
  };

  /**
   * Collect Resource Timing durations by URL while a probe runs. Falls back to
   * the timeline buffer at stop time for entries the observer did not see.
   *
   * @param {Map<string, number>} entries - Filled with url -> duration ms
   * @returns {{stop: function(): void}} Handle
   */
  observeResourceTimings = (entries) => {
    let observer = null;
    const record = (list) => {
      list.forEach((entry) => {
        if (entry.name.includes(`://${this.probeHost}:`) || entry.name.includes(`://${this.ipv6ProbeHost}:`)) {
          entries.set(entry.name, entry.duration);
        }
      });
    };
    try {
      observer = new PerformanceObserver((list) => record(list.getEntries()));
      observer.observe({ type: "resource", buffered: false });
    } catch {
      observer = null;
    }
    return {
      stop: () => {
        try {
          if (observer) {
            record(observer.takeRecords());
            observer.disconnect();
          }
          // Whatever the timeline still holds, for the entries delivered
          // before the observer attached or after it detached.
          record(performance.getEntriesByType("resource"));
        } catch {
          // Diagnostics only; the JavaScript timings stand in.
        }
      },
    };
  };

  /**
   * Apply the timing rule to one host's minimums.
   *
   * A port is open when its minimum is at least `timingProbeRatio` times the
   * control reference and at least `timingProbeMarginMs` above it. The
   * reference is the MEDIAN of the control minimums, so one unlucky control
   * with something bound on it cannot move it.
   *
   * Pure, so it is unit-testable without a network.
   *
   * @param {Map<number, number>} mins - Minimum ms per port
   * @param {number[]} candidates - Target ports
   * @param {number[]} controls - Control ports
   * @returns {{skipped: string|null, controlMinMs: number|null, thresholdMs: number|null, open: Set<number>}}
   */
  decideTimingOpen = (mins, candidates, controls) => {
    const controlMins = controls
      .map((port) => mins.get(port))
      .filter((value) => typeof value === "number");
    const controlMinMs = RemotePorts.median(controlMins);
    const result = { skipped: null, controlMinMs, thresholdMs: null, open: new Set() };

    if (controlMins.length < this.timingProbeMinControls) {
      result.skipped = "controlsUnusable";
      return result;
    }
    // Controls at the ceiling: unbound ports are silent on this path, which is
    // the DROP shape, and a ratio against a ceiling means nothing.
    if (controlMinMs >= this.timingProbeTimeoutMs) {
      result.skipped = "controlsSilent";
      return result;
    }
    if (controlMinMs > this.timingProbeMaxControlMinMs) {
      result.skipped = "controlsSlow";
      return result;
    }

    // Resolution-aware. On a 1 ms clock a refused port reads 0 or 1, so the
    // ratio is taken against the clock step when the controls read below it,
    // and the margin is at least two steps: a closed port jittering up one
    // step must not clear it. Firefox measured listeners at 4-5 ms against
    // 0-1 ms refused on that clock, which this still separates. On Chrome's
    // 0.1 ms clock the terms below the control minimum never bind.
    const resolution =
      typeof this.timerResolutionMs === "number" ? this.timerResolutionMs : 0;
    result.thresholdMs = Math.max(
      this.timingProbeRatio * Math.max(controlMinMs, resolution),
      controlMinMs + this.timingProbeMarginMs,
      controlMinMs + 2 * resolution,
    );
    candidates.forEach((port) => {
      const value = mins.get(port);
      if (typeof value === "number" && value >= result.thresholdMs) {
        result.open.add(port);
      }
    });
    return result;
  };

  /**
   * In-place Fisher-Yates shuffle using the collector's random source.
   *
   * @param {Array} items - Array to shuffle
   * @returns {Array} The same array
   */
  shuffle = (items) => {
    for (let i = items.length - 1; i > 0; i--) {
      const j = this.drawRandomInt(0, i + 1);
      [items[i], items[j]] = [items[j], items[i]];
    }
    return items;
  };

  /**
   * Decide the scan-level verdict.
   *
   * The port list alone cannot carry the outcome, so the status says whether the
   * probe produced a verdict at all. Ports whose every request timed out are
   * neither reported as open (filtered and open are indistinguishable from
   * timings alone) nor swept into a clean result.
   *
   * @param {Array<Object>} results - Per-port scan results
   * @param {Object} [baseline] - Baseline from `selectVerdictBaseline`
   * @param {number} [cspViolations] - Probe URLs the page's CSP refused
   * @returns {{status: string, ports: number[], reason?: string}} Scan verdict
   */
  buildVerdict = (
    results,
    baseline = RemotePorts.NO_BASELINE,
    cspViolations = 0,
  ) => {
    const inconclusive = (reason) => ({
      status: REMOTE_PORTS_STATUS.INCONCLUSIVE,
      ports: [],
      reason,
    });

    // Checked before the port list, not after it. Every other unusable baseline
    // still permits a port list, because a completed HTTP exchange is proof on
    // its own; these do not, because something is answering for ports whatever
    // is bound on them — which is the premise that proof rests on. Enforcing it
    // at the verdict as well as in `classify` makes "an invalidated scan is
    // never reported as a list of open ports" a property of the payload rather
    // than of one classification path.
    if (PROOF_VOIDING_REASONS.has(baseline.reason)) {
      return inconclusive(baseline.reason);
    }

    const openPorts = this.collectPorts(results, PORT_CLASSIFICATION.OPEN);

    // A CSP refusal is deliberately checked *after* the port list, not before
    // it. Blocking is per-URL, so a policy that refuses part of the map leaves
    // the rest genuinely measured: a port that completed an HTTP exchange is
    // still proof, and suppressing it would take a tenant's detection rate to
    // zero over a policy that only ever affected some origins.
    //
    // What a refusal does rule out is the opposite claim. "Nothing is
    // listening" cannot be asserted across a map that was only partly swept, so
    // below this point a violation turns a clean sheet into `probeBlocked`.
    if (openPorts.length > 0) {
      return { status: REMOTE_PORTS_STATUS.PORTS_FOUND, ports: openPorts };
    }

    if (cspViolations > 0) {
      return inconclusive(REMOTE_PORTS_REASON.PROBE_BLOCKED);
    }

    // Without a trustworthy reference, "nothing found" says nothing.
    if (!baseline.usable) {
      return inconclusive(
        baseline.reason ?? REMOTE_PORTS_REASON.CONTROLS_UNUSABLE,
      );
    }

    const filteredPorts = this.collectPorts(
      results,
      PORT_CLASSIFICATION.FILTERED_OR_OPEN,
    );
    if (filteredPorts.length > 0) {
      return inconclusive(REMOTE_PORTS_REASON.PORTS_FILTERED);
    }

    // Applies in BOTH modes, and it is load-bearing in DROP mode specifically.
    //
    // On a DROP host silence is the closed reading, so it is tempting to let a
    // wholly silent map stand as a clean sheet. It must not. "Closed ports drop"
    // and "the probe never reached the network" produce byte-identical
    // measurements when nothing is listening, so a map with no answer anywhere
    // cannot distinguish a clean DROP host from a blocked one — and the blocked
    // reading is the dangerous one to call clean.
    //
    // Requiring at least one port to have answered is what makes DROP mode safe:
    // it is the proof that the probe can reach the stack at all on this host, so
    // the silence elsewhere is a fact about those ports rather than about the
    // probe. A Windows endpoint with a remote-access tool installed supplies
    // that proof itself; one with nothing listening honestly cannot, and gets an
    // inconclusive rather than a guess.
    const measured = results.filter((result) => result.samples > 0);
    if (measured.length === 0) {
      return inconclusive(REMOTE_PORTS_REASON.NO_SAMPLES);
    }

    return { status: REMOTE_PORTS_STATUS.SCANNED_CLEAN, ports: [] };
  };

  /**
   * Collect the distinct, sorted port numbers holding a given classification.
   * A port can be scanned on more than one probe host, hence the de-duplication.
   *
   * @param {Array<Object>} results - Per-port scan results
   * @param {string} classification - Classification to collect
   * @returns {number[]} Sorted, distinct port numbers
   */
  collectPorts = (results, classification) =>
    [
      ...new Set(
        results
          .filter((result) => result.classification === classification)
          .map((result) => result.port),
      ),
    ].sort((a, b) => a - b);

  /**
   * Create a batch of HTTP requests for port scanning.
   *
   * The cache-busting id is derived from one seed drawn per port rather than a
   * fresh crypto draw per request. A full scan is hundreds of requests, and
   * each draw allocated a typed array and called getRandomValues; the id only
   * has to differ between requests, which an increment gives for free. The
   * `cache: "no-store"` header is what actually defeats the cache.
   *
   * Both trailing parameters are defaulted on purpose. Without them a call that
   * omits either builds `http://undefined:PORT/NaN.png`, which `fetch` rejects
   * as a network error — and `measurePort` records a network error as a
   * *response time sample*. A mis-call would therefore poison the baseline
   * instead of throwing, which is the one failure mode this probe must not
   * have.
   *
   * @param {number} port - Port number
   * @param {string} [host] - Loopback host to probe (literal address)
   * @param {number} [firstRequestId] - Id for the first request in this batch
   * @returns {Promise[]} Array of request promises
   */
  createBatchRequests = (
    port,
    host = this.probeHost,
    firstRequestId = 0,
    timeoutMs = this.timeout,
  ) => {
    const requests = [];
    for (let i = 0; i < this.batchSize; i++) {
      const requestId = (firstRequestId + i) % 10000000;
      const url = `http://${host}:${port}/${requestId}.png`;
      requests.push(this.testHttpConnection(url, timeoutMs));
    }
    return requests;
  };

  /**
   * Summary statistics for a set of response times.
   *
   * @param {number[]} responseTimes - Response times in ms
   * @returns {{avg: number|null, min: number|null, max: number|null, range: number, stdDev: number}} Statistics
   */
  summarise = (responseTimes) => {
    if (responseTimes.length === 0) {
      return { avg: null, min: null, max: null, range: 0, stdDev: 0 };
    }

    const avg = responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length;
    const min = Math.min(...responseTimes);
    const max = Math.max(...responseTimes);
    const variance =
      responseTimes.reduce((sum, time) => sum + Math.pow(time - avg, 2), 0) /
      responseTimes.length;

    return { avg, min, max, range: max - min, stdDev: Math.sqrt(variance) };
  };

  /**
   * Build a per-port result carrying the classification and the measurements it
   * was derived from.
   *
   * @param {Object} params - Result parameters
   * @returns {Object} Per-port scan result
   */
  buildPortResult = ({
    port,
    tool,
    host = this.probeHost,
    classification,
    responseTimes = [],
    timeoutCount = 0,
    errorCount = 0,
    successCount = 0,
    requests = 0,
    via = null,
    timingMinMs,
    timingFlagged,
  }) => {
    const { avg, min, max, stdDev } = this.summarise(responseTimes);

    return {
      port,
      tool,
      host,
      classification,
      accessible: classification === PORT_CLASSIFICATION.OPEN,
      via,
      ...(typeof timingMinMs === "number" && { timingMinMs }),
      ...(typeof timingFlagged === "boolean" && { timingFlagged }),
      averageResponseTime: avg,
      minResponseTime: min,
      maxResponseTime: max,
      stdDev,
      samples: responseTimes.length,
      timeouts: timeoutCount,
      errors: errorCount,
      successes: successCount,
      requests,
    };
  };

  /**
   * Decide whether sampling for a port can stop early.
   *
   * This is a sampling decision, not a verdict: the classification always comes
   * later, from the control-port baseline. Stopping early on a port that answers
   * fast and tight is what keeps the scan inside its time budget.
   *
   * @param {number[]} responseTimes - Collected response times
   * @param {number} batchesDone - Batches collected so far
   * @returns {boolean} Whether to stop sampling this port
   */
  shouldStopSampling = (responseTimes, batchesDone, timeoutCount = 0) => {
    // WebKit no longer forces the full sample budget. That guard existed so
    // Safari's throttled timings could be averaged over more samples, and
    // nothing averages timings any more: a port that answered is closed by
    // kind. It cost Safari four batches at ~20 ms each on every port, 125 ms
    // of a 128 ms scan. A port with any timeout still keeps sampling, so a
    // throttled partial-silence pattern gets its full picture as before.
    // FIELD-VALIDATE on iOS, where every browser is WebKit.
    if (
      batchesDone < this.earlyStopMinBatches ||
      responseTimes.length < this.minSamplesForDecision
    ) {
      return false;
    }

    // Every request so far answered. How fast is irrelevant: phase 1 verdicts
    // compare kind, not magnitude, and phase 2 re-measures timing on its own
    // terms. A port with any timeout keeps sampling so the majority rules in
    // `classify` see a full picture.
    return timeoutCount === 0;
  };

  /**
   * Measure one port. No verdict is formed here — `classify` does that once the
   * control ports have said what closed looks like on this machine.
   *
   * @param {number} port - Port number to probe
   * @param {string|null} tool - Tool the port maps to, null for control ports
   * @param {string} [host] - Loopback host to probe (literal address)
   * @param {number} [timeoutMs] - Per-request abort, defaulting to the floor.
   *   Passed explicitly so calibration and the target sweep can run at different
   *   ceilings, and so the target ceiling can be derived from the host's own
   *   measured baseline rather than fixed for every machine alike.
   * @returns {Promise<Object>} Raw measurements for the port
   */
  measurePort = async (
    port,
    tool,
    host = this.probeHost,
    timeoutMs = this.timeout,
  ) => {
    const responseTimes = [];
    const requestIdSeed = this.drawRandomInt(0, 10000000);
    let timeoutCount = 0;
    let errorCount = 0;
    let successCount = 0;
    let totalRequests = 0;

    for (let batch = 0; batch < this.maxBatches; batch++) {
      // Fire batch of requests in parallel
      const requests = this.createBatchRequests(
        port,
        host,
        requestIdSeed + batch * this.batchSize,
        timeoutMs,
      );
      const responses = await Promise.allSettled(requests);
      totalRequests += this.batchSize;

      responses.forEach((response) => {
        // Reached only when the request promise rejected outright.
        // `testHttpConnection` always resolves, so this needs `fetch` itself to
        // throw synchronously — a malformed URL, or no fetch implementation.
        // Effectively zero in normal operation, which is the point: a non-zero
        // `err` in the field means the probe never left the page.
        if (response.status !== "fulfilled") {
          errorCount++;
          return;
        }
        if (response.value.error === "timeout") {
          timeoutCount++;
          return;
        }
        if (response.value.success) {
          successCount++;
        }
        responseTimes.push(response.value.responseTime);
      });

      // A completed HTTP exchange is proof of a listener on its own; nothing a
      // further batch could add changes that verdict.
      if (successCount > 0) {
        break;
      }

      // Every request so far aborted at the timeout. Enough batches of that
      // and we stop paying for more; `classify` decides what it means.
      if (
        responseTimes.length === 0 &&
        timeoutCount === totalRequests &&
        batch + 1 >= this.filteredOrOpenMinBatches
      ) {
        break;
      }

      if (this.shouldStopSampling(responseTimes, batch + 1, timeoutCount)) {
        break;
      }
    }

    return {
      port,
      tool,
      host,
      responseTimes,
      timeoutCount,
      errorCount,
      successCount,
      requests: totalRequests,
    };
  };

  /**
   * Test HTTP connection to a URL and measure response time.
   *
   * Always resolves. A rejection here would be a synchronous throw from
   * `fetch`, which `measurePort` records separately.
   *
   * @param {string} url - URL to test
   * @param {number} [timeoutMs] - Per-request abort ceiling
   * @returns {Promise<{success: boolean, responseTime: number, error: string|null}>}
   */
  testHttpConnection = async (url, timeoutMs = this.timeout) => {
    return new Promise((resolve) => {
      const startTime = performance.now();
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

      fetch(url, {
        method: "GET",
        mode: "no-cors",
        signal: controller.signal,
        cache: "no-store",
      })
        .then(() => {
          clearTimeout(timeoutId);
          const responseTime = performance.now() - startTime;
          // Release the socket. The promise resolves on headers, and an
          // opaque response's body cannot be read or cancelled directly, so
          // a listener that never closes — Splashtop answers `HTTP/1.0 404`
          // and then holds the connection — would pin the socket until the
          // page dies. Browsers allow six per host, so after two scans every
          // later request queued behind them and read as silent. Aborting
          // after resolution cancels the unread body and closes the socket.
          try {
            controller.abort();
          } catch {
            // Nothing to release.
          }
          resolve({
            success: true,
            responseTime,
            error: null,
          });
        })
        .catch((error) => {
          clearTimeout(timeoutId);
          const responseTime = performance.now() - startTime;

          const errorType =
            error.name === "AbortError" ? "timeout" : "network_error";

          resolve({
            success: false,
            responseTime,
            error: errorType,
          });
        });
    });
  };
}