// TEST STUB ONLY. Stands in for the real src/collectors/Constants.js so
// RemotePorts.js can load in this partial checkout. Do not copy to the repo.
export const Constants = Object.freeze({
  ERROR_CODES: Object.freeze({ NOT_AVAILABLE: "NOT_AVAILABLE" }),
});
