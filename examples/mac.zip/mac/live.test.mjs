/**
 * LIVE test: runs the real RemotePorts scan against this machine's loopback
 * and grades it against what `lsof` says is actually listening.
 *
 * Run:  node --preserve-symlinks --test live.test.mjs
 *
 * Node's fetch is not a browser's, so the absolute timings here are not the
 * SDK's timings. Use harness.html in Chrome for those. What this test does
 * give quickly, with no browser, is: does the classifier see the listeners
 * that exist, and does it stay silent about the ports that are closed.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import RemotePorts, {
  PORT_CLASSIFICATION,
} from "./src/collectors/spoof/RemotePorts.js";

const RUNS = Number(process.env.RUNS ?? 5);

/**
 * Ports bound on IPv4 loopback or all interfaces, keyed by port -> owner.
 *
 * netstat, not lsof: lsof without sudo cannot see root-owned sockets, and
 * macOS Screen Sharing (5900) and the TeamViewer daemon (5938) run as root.
 * The owner name comes from lsof when it is visible, else "root/other".
 */
const groundTruth = () => {
  const bound = new Map();
  const win = process.platform === "win32";
  const ns = execFileSync("netstat", win ? ["-an", "-p", "TCP"] : ["-an", "-p", "tcp"], { encoding: "utf8" });
  const re = win
    ? /^\s*TCP\s+(0\.0\.0\.0|127\.0\.0\.1):(\d+)\s+\S+\s+LISTENING/
    : /^tcp4\s+\d+\s+\d+\s+(\*|127\.0\.0\.1)\.(\d+)\s+\S+\s+LISTEN/;
  ns.split("\n").forEach((line) => {
    const m = line.match(re);
    if (m) bound.set(Number(m[2]), "root/other");
  });
  try {
    const lsof = execFileSync("lsof", ["-iTCP", "-sTCP:LISTEN", "-P", "-n"], { encoding: "utf8" });
    lsof.split("\n").forEach((line) => {
      const m = line.match(/^(\S+)\s.*TCP (\*|127\.0\.0\.1):(\d+) \(LISTEN\)/);
      if (m && bound.has(Number(m[3]))) bound.set(Number(m[3]), m[1]);
    });
  } catch {}
  return bound;
};

/** The "old way": one fetch per port, all concurrent, answered-or-not. */
const oldWayMs = async (ports, timeoutMs) => {
  const t0 = performance.now();
  await Promise.allSettled(
    ports.map((port) => {
      const c = new AbortController();
      const t = setTimeout(() => c.abort(), timeoutMs);
      return fetch(`http://127.0.0.1:${port}/0.png`, {
        mode: "no-cors",
        cache: "no-store",
        signal: c.signal,
      })
        .catch(() => {})
        .finally(() => clearTimeout(t));
    }),
  );
  return performance.now() - t0;
};

test(`live: ${RUNS} real scans against loopback`, async () => {
  const bound = groundTruth();
  const template = new RemotePorts();
  const ratPorts = template.ratPorts.map((e) => e.port);
  const expectedOpen = ratPorts.filter((p) => bound.has(p));

  console.log("\nGround truth (lsof): RAT ports bound right now:");
  expectedOpen.forEach((p) => console.log(`  ${p}  ${bound.get(p)}`));
  if (expectedOpen.length === 0) console.log("  (none)");

  const rows = [];
  for (let i = 0; i < RUNS; i++) {
    const rp = new RemotePorts();
    const payload = await rp.getPorts();
    const byPort = Object.fromEntries(payload.probes.map((p) => [p.p, p.c]));
    rows.push({
      run: i + 1,
      ms: payload.scan.durationMs,
      status: payload.status,
      reason: payload.reason ?? "",
      mode: payload.scan.mode,
      baseline: payload.scan.baselineMs,
      ports: payload.ports.join(","),
      ...byPort,
    });
  }
  console.table(rows);

  const old = [];
  for (let i = 0; i < RUNS; i++) old.push(await oldWayMs(ratPorts, template.timeout));
  const med = (a) => [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)];
  console.log(
    `median scan ${med(rows.map((r) => r.ms)).toFixed(1)} ms` +
      `  vs old way (1 fetch/port) ${med(old).toFixed(1)} ms`,
  );

  // Accuracy. A port reported open that lsof says is unbound is a false
  // positive and fails hard. A bound port never reported open is a miss.
  const falsePositives = new Set();
  const misses = new Set(expectedOpen);
  rows.forEach((r) => {
    ratPorts.forEach((p) => {
      if (r[p] === PORT_CLASSIFICATION.OPEN) {
        if (bound.has(p)) misses.delete(p);
        else falsePositives.add(p);
      }
    });
  });
  console.log(`false positives: [${[...falsePositives]}]  misses: [${[...misses]}]`);

  assert.deepEqual([...falsePositives], [], "ports reported open but not bound");
  assert.deepEqual([...misses], [], "bound RAT ports never reported open");
  rows.forEach((r) =>
    assert.ok(r.ms < template.scanBudgetMs, `run ${r.run} took ${r.ms} ms`),
  );
});
