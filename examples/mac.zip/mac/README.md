# RemotePorts test kit (macOS)

Measures whether the browser can see remote-access tools (AnyDesk, TeamViewer,
VNC / Screen Sharing, Splashtop) listening on this Mac, and how long the scan
takes. Nothing leaves the machine. Results go to ONE local file which you
send back.

## You need
- Node.js 20 or newer. Check with `node --version`. Install from
  https://nodejs.org or `brew install node`.
- Any of Safari, Chrome, Edge, Firefox.

## Steps
1. Unzip this folder anywhere. Open Terminal in it (drag the folder onto the
   Terminal icon, or `cd` to it).
2. Run:  `node serve.mjs`
   It prints a URL like `http://127.0.0.1:8787/harness.html?runs=8&label=SCENARIO`
   and the path of the results file. Leave it running.
3. For EACH scenario below, in EACH browser, open the URL with `SCENARIO`
   replaced by the scenario name. Wait until the tab title says **DONE** and
   a table appears (5 to 20 seconds). Then move on.
4. When finished press Ctrl+C in the Terminal and send back the file
   **harness-report.jsonl** from this folder. No screenshots are needed.

Scenarios (use these exact labels, change the label every time):
- `clean`            nothing remote-access related running, Screen Sharing off
- `anydesk`          AnyDesk open, no session
- `anydesk-session`  AnyDesk with a live session connected from another machine
- `screensharing`    System Settings > General > Sharing > Screen Sharing ON
- `teamviewer`       TeamViewer open (optional: Preferences > "Incoming LAN connections" on)
- `splashtop`        Splashtop Streamer installed and running (optional)

Example: `http://127.0.0.1:8787/harness.html?runs=8&label=anydesk`

Also note in your message: macOS version, Mac model and year, and which
browsers and versions you used. The report records the browser but not the
Mac model.

## Optional checks
- `node --test live.test.mjs` runs the same scan from Node and prints a table.
- `node validate-report.mjs harness-report.jsonl` grades the file you are
  about to send. PASS on every line is the expected outcome.
