/**
 * Tiny static server for harness.html. Run: node serve.mjs
 * Then open http://127.0.0.1:8787/harness.html?runs=5 in Chrome.
 *
 * /truth returns the ports bound on loopback right now (from lsof), so the
 * page can grade the scan against reality.
 */
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { execFile } from "node:child_process";
import { fileURLToPath } from "node:url";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const REPORT = process.env.REPORT ?? path.join(ROOT, "harness-report.jsonl");
// Listening sockets on loopback or all interfaces. netstat sees root/SYSTEM
// owned listeners; lsof without sudo does not.
const NETSTAT_ARGS = process.platform === "win32" ? ["-an", "-p", "TCP"] : ["-an", "-p", "tcp"];
const LISTEN_RE = process.platform === "win32"
  ? /^\s*TCP\s+(0\.0\.0\.0|127\.0\.0\.1):(\d+)\s+\S+\s+LISTENING/
  : /^tcp4\s+\d+\s+\d+\s+(\*|127\.0\.0\.1)\.(\d+)\s+\S+\s+LISTEN/;
const PORT = Number(process.env.PORT ?? 8787);
const TYPES = { ".html": "text/html", ".js": "text/javascript", ".mjs": "text/javascript" };

http
  .createServer((req, res) => {
    const url = new URL(req.url, "http://x");
    if (url.pathname === "/truth") {
      // netstat sees root-owned listeners (Screen Sharing, TeamViewer daemon);
      // lsof without sudo does not.
      execFile("netstat", NETSTAT_ARGS, (err, out) => {
        const bound = {};
        String(out ?? "").split("\n").forEach((line) => {
          const m = line.match(LISTEN_RE);
          if (m) bound[m[2]] = "listening";
        });
        res.writeHead(200, { "content-type": "application/json" });
        res.end(JSON.stringify(bound));
      });
      return;
    }
    if (url.pathname === "/report" && req.method === "POST") {
      let body = "";
      req.on("data", (c) => (body += c));
      req.on("end", () => {
        fs.appendFileSync(REPORT, body + "\n");
        console.log(`saved a result to ${REPORT}`);
        res.writeHead(204);
        res.end();
      });
      return;
    }
    const file = path.normalize(path.join(ROOT, url.pathname));
    if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      res.writeHead(404);
      return res.end("not found");
    }
    res.writeHead(200, {
      "content-type": TYPES[path.extname(file)] ?? "application/octet-stream",
      "cache-control": "no-store",
    });
    fs.createReadStream(file).pipe(res);
  })
  .listen(PORT, "127.0.0.1", () => {
    console.log(`Open in each browser:  http://127.0.0.1:${PORT}/harness.html?runs=8&label=SCENARIO`);
    console.log(`Results are appended to: ${REPORT}`);
    console.log("Press Ctrl+C when finished, then send that file.");
  });
